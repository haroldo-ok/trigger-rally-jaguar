  "illegal operand",ERROR,
  "value does not find in %d bits",WARNING,
  "data size not supported",ERROR,
  "garbage at end of operand",WARNING,
