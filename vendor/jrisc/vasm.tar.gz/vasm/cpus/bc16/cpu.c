/* cpu.c bc16 cpu-description file */
/* (c) in 2021 by Volker Barthelmann */

#include "vasm.h"

char *cpu_copyright="vasm bc16 cpu backend 0.1 (c) in 2021 Volker Barthelmann";
char *cpuname="qnice";

mnemonic mnemonics[]={
#include "opcodes.h"
};

int mnemonic_cnt=sizeof(mnemonics)/sizeof(mnemonics[0]);

int bitsperbyte=8;
int bytespertaddr=4;

static char *skip_reg(char *s,int *reg)
{
  if(*s!='r'&&*s!='R'){
    cpu_error(1);
    return s;
  }
  s++;
  if(*s<'0'||*s>'7'){
    cpu_error(1);
    return s;
  }
  *reg=*s++-'0';
  return s;
}

int parse_operand(char *p,int len,operand *op,int requires)
{
  char *start=p;
  op->type=-1;
  p=skip(p);
  if(requires==OP_REL){
    char *s=p;
    op->type=OP_REL;
    op->offset=parse_expr(&s);
    simplify_expr(op->offset);
    if(s==p)
      return 0;
    else
      return 1;
  }
  if((p[0]=='r'||p[0]=='R')&&p[1]>='0'&&p[1]<='7'&&len==2){
    op->type=OP_REG;
    op->reg=p[1]-'0';
    p+=2;
  }else if(*p=='('&&(p[1]=='r'||p[1]=='R')&&(p[2]>='0'&&p[2]<='7')&&p[3]==')'){
    p++;
    p=skip_reg(p,&op->reg);
    p++;
    if(*p=='+'){
      p=skip(p+1);
      op->type=OP_POSTINC;
    }else  if(*p=='-'){
      p=skip(p+1);
      op->type=OP_PREDEC;
    }else{
      op->type=OP_REGIND;
    }
  }else{
    op->offset=parse_expr(&p);
    op->type=OP_ABS;
  }

  p=skip(p);
  if (p-start < len){
    cpu_error(3);  /* trailing garbage */
    return PO_CORRUPT;
  }
  
  if(requires==op->type)
    return 1;
  if(requires==OP_SRC&&op->type>=OP_REG&&op->type<=OP_ABS&&op->type!=OP_PREDEC)
    return 1;
  if(requires==OP_DST&&op->type>=OP_REG&&op->type<=OP_PREDEC)
    return 1;

  return 0;
}

static taddr reloffset(expr *tree,section *sec,taddr pc)
{
  symbol *sym;
  int btype;
  taddr val;
  simplify_expr(tree);
  if(tree->type==NUM){
    /* should we do it like this?? */
    val=tree->c.val;
  }else{
    btype=find_base(tree,&sym,sec,pc);
    if(btype!=BASE_OK||!LOCREF(sym)||sym->sec!=sec)
      general_error(38);
    else{
      eval_expr(tree,&val,sec,pc);
      val=(val-pc-2)/2;
    }
  }
  return val;
}

static taddr absoffset(expr *tree,section *sec,taddr pc,rlist **relocs,int roffset,int size)
{
  taddr val;
  if(!eval_expr(tree,&val,sec,pc)){
    taddr addend=val;
    symbol *base;
    if(find_base(tree,&base,sec,pc)!=BASE_OK){
      general_error(38);
      return val;
    }
    add_nreloc_masked(relocs,base,addend,REL_ABS,size,roffset,0xFFFF);
    return val;
  }
  if(size==16)
    val&=0xffff;
  else
    val&=((1<<size)-1);
  return val;
}

static int translate(instruction *p,section *sec,taddr pc)
{
  int c=p->code;

  if(mnemonics[c].ext.encoding==ENC_LBRANCH){
    symbol *sym;
    int btype;
    taddr val;
    simplify_expr(p->op[0]->offset);
    btype=find_base(p->op[0]->offset,&sym,sec,pc);
    if(btype==BASE_OK&&LOCREF(sym)&&sym->sec==sec){
      eval_expr(p->op[0]->offset,&val,sec,pc);
      val=(val-pc-2)/2;
      if(val>=-128&&val<=127)
	c-=8;
    }
  }
 
  return c;
}

static unsigned int openc(operand *p)
{
  if(p->type==OP_REG)
    return p->reg|0x10;
  if(p->type==OP_PREDEC)
    return p->reg;
  if(p->type==OP_REGIND)
    return p->reg|0x20;
  if(p->type==OP_POSTINC)
    return p->reg|0x30;
  if(p->type==OP_ABS){
    taddr v;
    simplify_expr(p->offset);
    if(p->offset->type!=NUM)
      cpu_error(0);
    v=p->offset->c.val;
    if(v<0||v>7)
      cpu_error(1,3);
    return (v&7);
  }
  ierror(0);
}

/* Convert an instruction into a DATA atom including relocations,
   if necessary. */
dblock *eval_instruction(instruction *p,section *sec,taddr pc)
{
  dblock *db=new_dblock();
  int opcode,c,enc,osize;
  unsigned int addr;
  unsigned char *d;
  rlist *relocs=0;

  c=translate(p,sec,pc);
  
  db->size=osize=instruction_size(p,sec,pc);
  db->data=mymalloc(db->size);

  opcode=mnemonics[c].ext.opcode;
  enc=mnemonics[c].ext.encoding;

  if(enc==ENC_ARITH){
    opcode|=openc(p->op[0])<<10;
    opcode|=openc(p->op[1])<<4;
  }else if(enc==ENC_THREE||enc==ENC_INDIMM||enc==ENC_INDIDX){
    opcode|=(openc(p->op[2])&7)<<10;
    opcode|=(p->op[0]->reg<<13)|(p->op[1]->reg<<7);
  }else if(enc==ENC_SBRANCH){
    opcode|=reloffset(p->op[0]->offset,sec,pc)<<8;
  }else if(enc==ENC_LBRANCH){
    addr=absoffset(p->op[0]->offset,sec,pc,&relocs,16,16);
    db->data[2]=addr;
    db->data[3]=addr>>8;
  }else if(enc==ENC_PUSH){
    opcode|=(p->op[0]->reg)<<13;
  }

  d=db->data;
  *d++=opcode;
  *d++=opcode>>8;

  db->relocs=relocs;
  return db;
}

/* Create a dblock (with relocs, if necessary) for size bits of data. */
dblock *eval_data(operand *op,size_t bitsize,section *sec,taddr pc)
{
  dblock *new=new_dblock();
  taddr val;
  new->size=(bitsize+7)/8;
  new->data=mymalloc(new->size);
  if(op->type!=OP_ABS)
    ierror(0);
  if(bitsize!=8&&bitsize!=16&&bitsize!=32)
    cpu_error(4);
  val=absoffset(op->offset,sec,pc,&new->relocs,op->reg,bitsize);
  if(bitsize==32){
    new->data[3]=val>>24;
    new->data[2]=val>>16;    
    new->data[1]=val>>8;
    new->data[0]=val;        
  }else if(bitsize==16){
    new->data[1]=val>>8;
    new->data[0]=val;    
  }else
    new->data[0]=val;
  return new;
}                                     


/* Calculate the size of the current instruction; must be identical
   to the data created by eval_instruction. */
size_t instruction_size(instruction *p,section *sec,taddr pc)
{  
  int sz=2;

  int c=translate(p,sec,pc),add=0;

  if(mnemonics[c].ext.encoding==ENC_LBRANCH)
    sz+=2;

  return sz;
}

operand *new_operand()
{
  operand *new=mymalloc(sizeof(*new));
  new->type=-1;
  return new;
}

/* return true, if initialization was successfull */
int init_cpu()
{
  return 1;
}

/* return true, if the passed argument is understood */
int cpu_args(char *p)
{
  return 0;
}

/* parse cpu-specific directives; return pointer to end of
   cpu-specific text */
char *parse_cpu_special(char *s)
{
  return s;
}
