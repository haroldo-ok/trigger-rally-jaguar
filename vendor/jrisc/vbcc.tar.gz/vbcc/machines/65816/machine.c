/*  65816 backend for vbcc
    (c) Volker Barthelmann 2023-2025

*/                                                                             

#include "supp.h"
#include "vbc.h"

#include <math.h>

static char FILE_[]=__FILE__;

/*  Public data that MUST be there.                             */

/* Name and copyright. */
char cg_copyright[]="vbcc 65816 code-generator V0.2 (c) in 2023-2025 by Volker Barthelmann";

/*  Commandline-flags the code-generator accepts:
    0: just a flag
    VALFLAG: a value must be specified
    STRINGFLAG: a string can be specified
    FUNCFLAG: a function will be called
    apart from FUNCFLAG, all other versions can only be specified once */
int g_flags[MAXGF]={0,0,
		    VALFLAG,0,0,
		    0,0,
		    VALFLAG,VALFLAG,0,0,
		    0,0,0,0,
		    0,0,0,
		    0,0,0,0,0,0,
		    0,VALFLAG,0,0,
		    0};

/* the flag-name, do not use names beginning with l, L, I, D or U, because
   they collide with the frontend */
char *g_flags_name[MAXGF]={"std-syntax","no-rax",
			   "volatile-regs","ieee","no-peephole",
			   "cbmascii","const-in-data",
			   "reg-args","int-args","mainargs","no-acc-parm",
			   "snes-muldiv","btmp-zpage","oldfp","mtiny",
			   "glob-acc","msfp4","",
			   "atascii","","nox","mhuge","ptr24","",
			   "iigs","near-threshold","no-near-const","no-delayed-popping",
			   "sc"};

/* the results of parsing the command-line-flags will be stored here */
union ppi g_flags_val[MAXGF];

/*  Alignment-requirements for all types in bytes.              */
zmax align[MAX_TYPE+1];

/*  Alignment that is sufficient for every object.              */
zmax maxalign;

/*  CHAR_BIT for the target machine.                            */
zmax char_bit;

/*  sizes of the basic types (in bytes) */
zmax sizetab[MAX_TYPE+1];

/*  Minimum and Maximum values each type can have.              */
/*  Must be initialized in init_cg().                           */
zmax t_min[MAX_TYPE+1];
zumax t_max[MAX_TYPE+1];
zumax tu_max[MAX_TYPE+1];

/*  Names of all registers. will be initialized in init_cg(),
    register number 0 is invalid, valid registers start at 1 */
char *regnames[MAXR+1];

/*  The Size of each register in bytes.                         */
zmax regsize[MAXR+1];

/*  a type which can store each register. */
struct Typ *regtype[MAXR+1];

/*  regsa[reg]!=0 if a certain register is allocated and should */
/*  not be used by the compiler pass.                           */
int regsa[MAXR+1];

/*  Specifies which registers may be scratched by functions.    */
int regscratch[MAXR+1];

/* specifies the priority for the register-allocator, if the same
   estimated cost-saving can be obtained by several registers, the
   one with the highest priority will be used */
int reg_prio[MAXR+1];

/* an empty reg-handle representing initial state */
struct reg_handle empty_reg_handle={0,0};

/* Names of target-specific variable attributes.                */
char *g_attr_name[]={"__interrupt","__zpage","__nocpr",0};

#define INTERRUPT 1
#define ZPAGE 2
#define NOCOMPRESS 4

/****************************************/
/*  Private data and functions.         */
/****************************************/

#define STDSYNTAX  (g_flags[0]&USEDFLAG)
#define NORAX      (g_flags[1]&USEDFLAG)
#define VOL_GPRS   ((g_flags[2]&USEDFLAG)?g_flags_val[2].l:NUM_GPRS/2)
#define IEEE       (g_flags[3]&USEDFLAG)
#define NOPEEP     (g_flags[4]&USEDFLAG)
#define CBMASCII   (g_flags[5]&USEDFLAG)
#define CONSTINDATA (g_flags[6]&USEDFLAG)
#define GPR_ARGS   ((g_flags[7]&USEDFLAG)?g_flags_val[7].l:0)
#define MAINARGS   (g_flags[9]&USEDFLAG)
#define ACCPARM    (!(g_flags[10]&USEDFLAG))
#define SNESMULDIV (g_flags[11]&USEDFLAG)
#define BIGZPAGE   (g_flags[12]&USEDFLAG)
#define OLDFP      (g_flags[13]&USEDFLAG)
#define TINY       (g_flags[14]&USEDFLAG)
#define GLOBACC    (g_flags[15]&USEDFLAG)
#define MSFP4      (g_flags[16]&USEDFLAG)
//#define NOBANKING  (g_flags[17]&USEDFLAG)
#define ATASCII    (g_flags[18]&USEDFLAG)
//#define LARGE      (g_flags[19]&USEDFLAG)
#define NOX        (g_flags[20]&USEDFLAG)
#define HUGE       (g_flags[21]&USEDFLAG)
#define PTR24      (g_flags[22]&USEDFLAG)
/*#define       (g_flags[23]&USEDFLAG)*/
#define IIGS       (g_flags[24]&USEDFLAG)
#define NEARTHR    (g_flags[25]&USEDFLAG)
#define NONEARCONST (g_flags[26]&USEDFLAG)
#define NODELPOP   (g_flags[27]&USEDFLAG)
#define SC         (g_flags[28]&USEDFLAG)



#define STR_NEAR "near"
#define STR_FAR "fard"
#define STR_HUGE "huged"
#define STR_FAR4 "far4"
#define STR_HUGE4 "huge4"
#define STR_FAR3 "far3"
#define STR_HUGE3 "huge3"


#define PLA (-1)
#define JMPIND (-2)

#define WMODE() do{if(bmode){bmode=0;emit(f,"\ta16\n\trep\t#32\n");}}while(0)
#define BMODE() do{if(!bmode){bmode=1;emit(f,"\tsep\t#32\n\ta8\n");}}while(0)
#define WXMODE() do{if(bxmode){bxmode=0;emit(f,"\tx16\n\trep\t#16\n");}}while(0)
#define BXMODE() do{if(!bxmode){bxmode=1;emit(f,"\tsep\t#16\n\tx8\n");}}while(0)


static void function_top(FILE *,struct Var *,long);
static void function_bottom(FILE *f,struct Var *,long);

#define isreg(x) ((p->x.flags&(REG|DREFOBJ))==REG)
#define isacc(x) (isreg(x)&&(p->x.reg==ra||p->x.reg==rax))
#define isconst(x) ((p->x.flags&(KONST|DREFOBJ))==KONST)

#define iszpage(o) ((((o)->flags&(REG|DREFOBJ))==REG&&(o)->reg>=FIRST_GPR&&(o)->reg<=LAST_PAIR)||(((o)->flags&(VAR|DREFOBJ))==VAR&&(o)->v->tattr&ZPAGE))

/*#define isptr(r) (((r)>=FIRST_PAIR&&(r)<=LAST_PAIR)||(c816&&r==rx))*/
#define isptr(r) ((r)!=ra&&(r)!=rax)

static int q1reg,q2reg,zreg;

static char *ccs[]={"eq","ne","lt","ge","le","gt",""};
static char *logicals[]={"ora","eor","and"};
static char *arithmetics[]={"slw","srw","adc","sbc","mullw","divw","mod"};

/* alignment of basic data-types, used to initialize align[] */
static long malign[MAX_TYPE+1]=  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
/* sizes of basic data-types, used to initialize sizetab[] */
static long msizetab[MAX_TYPE+1]={1,1,2,2,4,8,4,4,4,0,2,3,3,4,4,0,0,0,1,0};
static char *mregnames[MAXR+1+4];

/* Typenames (needed because of HAVE_EXT_TYPES). */
char *typname[]={"strange","char","short","int","long","long long",
                 "float","double","long double","void",
                 "near-pointer","far-pointer3","huge-pointer3","far-pointer4","huge-pointer4",
                 "array","struct","union","enum","function"};


/* used to initialize regtyp[] */
static struct Typ ityp={INT},ctyp={CHAR},ftyp={FLOAT},lltyp={LLONG};

/* macros defined by the backend */
static char *marray[]={"__section(x)=__vattr(\"section(\"#x\")\")",
		       "__65816__=1",
		       "__SIZE_T_INT=1",
		       "__MLARGE=1",
		       "__PTR32=1",
                       "__far=__attr(\"fard\")",
                       "__near=__attr(\"near\")",
                       "__huge=__attr(\"huged\")",
                       "__far3=__attr(\"far3\")",
                       "__huge3=__attr(\"huge3\")",
                       "__far4=__attr(\"far4\")",
                       "__huge4=__attr(\"huge4\")",
		       "__pascal=__attr(\"__pascal__\")",
		       "__WOZFP__",
		       0};

/* special registers */
static int fp,fp1,fp2;
const static int ra=1, rx=2, ry=3, sp1=4,sp2=5,sp=6;
const static int t4=LAST_GPR,t3=LAST_GPR-1,t2=LAST_GPR-2,t1=LAST_GPR-3,t3t4=LAST_PAIR,t1t2=LAST_PAIR;
const static int rax=7;
static long yval;
#define NOVAL 70000

#define REGDUMMY1 MAXR+1
#define REGDUMMY2 MAXR+2
#define REGDUMMY3 MAXR+3

static int pushedacc,pushedx,nopeep,cbmascii,atascii,ieee,ms4,constindata;
static int storedacc,storedx;
static int c02=1,m65,ce02,c816=1,bmode,bxmode,noy,nomod;
static int divbug;
static int m65io;
static int accparm;
static char *jmpinst;
static int pass;
static int libsave;
static struct rpair rp2;
static int hasretval;
static int sc;
static char *jsr="jsl",*rts="\trtl\n";
static int aparm;
static int large,huge,ptr24;
static unsigned long near_threshold=8;
static int snesmuldiv;
int have_int_sizet_65816=1;


enum banktype {nearbank,stackbank,farconst,fardyn};

#define SECLEN 128
char *use_sec;

#define dt(t) (((t)&UNSIGNED)?udt[(t)&NQ]:sdt[(t)&NQ])
static char *sdt[MAX_TYPE+1]={"??","c","s","i","l","ll","f","d","ld","v","p"};
static char *udt[MAX_TYPE+1]={"??","uc","us","ui","ul","ull","f","d","ld","v","p"};

/* perhaps provide version with 8bit int? */
#define ISCHAR(t) ((t&NQ)==CHAR)
#define ISSHORT(t) ((t&NQ)==SHORT||(t&NQ)==INT||(t&NQ)==POINTER)
#define ISNPOINTER(t) ((t&NQ)==POINTER)
#define ISFPOINTER(t) ((t&NQ)==FPOINTER)
#define ISHPOINTER(t) ((t&NQ)==HPOINTER)
#define ISFLPOINTER(t) ((t&NQ)==FLPOINTER)
#define ISHLPOINTER(t) ((t&NQ)==HLPOINTER)
#define ISLPOINTER(t) ((t&NQ)==FLPOINTER||(t&NQ)==HLPOINTER)
#define ISLONG(t) ((t&NQ)==LONG)
#define ISLLONG(t) ((t&NQ)==LLONG)
#define ISSTACK(sc) ((sc)==AUTO||(sc)==REGISTER)

#define ISIDX(r) (r==rx)
#define ISRIDX(op) (isreg(op)&&ISIDX(p->op.reg))
#define ISPREG(op) (isreg(op)&&isptr(p->op.reg))

#define LONGM65(c) ((c)==ASSIGN||(c)==PUSH||(c)==GETRETURN||(c)==SETRETURN||((c)>=LSHIFT&&(c)<=MOD)||((c)>=OR&&(c)<=AND))

/* am */
#define IMM_IND 1
#define GPR_IND 2
#define ABS_IND 3

/* sections */
#define DATA 0
#define BSS 1
#define CODE 2
#define RODATA 3
#define SPECIAL 4

static long stack;
static int stack_valid;
static int section=-1,newobj;
static char *codename="\tsection\ttext\n",
  *dataname="\tsection\tdata\n",
  *bssname="\tsection\tbss\n",
  *rodataname="\tsection\trodata\n";

/* return-instruction */
static char *ret;

/* label at the end of the function (if any) */
static int exit_label;

/* assembly-prefixes for labels and external identifiers */
static char *labprefix="l",*idprefix="_";

/* variables to calculate the size and partitioning of the stack-frame
   in the case of FIXED_SP */
static long frameoffset,pushed,maxpushed,framesize;

/* for 65816 */
static long roff,notpopped,dontpop,stack,stackoffset,fpop;

static long localsize,rsavesize,rscnt;

static void emit_obj(FILE *f,struct obj *p,int t);

/* calculate the actual current offset of an object relativ to the
   stack-pointer; we use a layout like this:
   ------------------------------------------------
   | arguments to this function                   |
   ------------------------------------------------
   | caller-save registers [size=rsavesize]       |
   ------------------------------------------------
   | local variables [size=localsize]             |
   ------------------------------------------------
   | arguments to called functions                |
   ------------------------------------------------
   All sizes will be aligned as necessary.
   In the case of FIXED_SP, the stack-pointer will be adjusted at
   function-entry to leave enough space for the arguments and have it
   aligned to 16 bytes. Therefore, when calling a function, the
   stack-pointer is always aligned to 16 bytes.
   For a moving stack-pointer, the stack-pointer will usually point
   to the bottom of the area for local variables, but will move while
   arguments are put on the stack.

   This is just an example layout. Other layouts are also possible.
*/

static void push(int i)
{
  stackoffset-=i;
}

static void pop(int i)
{
  stackoffset+=i;
}

static long real_offset(struct obj *o)
{
  long off=zm2l(o->v->offset);

  if(off<0) 
    return localsize-off+zm2l(o->val.vmax)+3+(sc!=0)+rscnt-((fp==sp)?stackoffset:0);
  else
    return off+zm2l(o->val.vmax)+1-((fp==sp)?stackoffset:0);
}

/* changes to a special section, used for __section() */
static int special_section(FILE *f,struct Var *v)
{
  char *sec;
  if(v->tattr&ZPAGE){
    emit(f,"\tsection\tzpage,\"adrwz\"\n");
  }else{
    if(!v->vattr) return 0;
    sec=strstr(v->vattr,"section(");
    if(!sec) return 0;
    sec+=strlen("section(");
    emit(f,"\tsection\t");
    while(*sec&&*sec!=')') emit_char(f,*sec++);
    emit(f,"\n");
  }
  if(f) section=SPECIAL;
  return 1;
}

/* switch to section */
static void set_section(FILE *f, Var *v)
{
  int constflag=0;
  if(!constindata&&v->clist) constflag=is_const(v->vtyp);
  if(!special_section(f,v)){
    if(0/*!sec_per_obj*/){
      if(ISFUNC(v->vtyp->flags)){
	if(section!=CODE){emit(f,codename);section=CODE;}
      }
      if(v->clist&&(!constflag||(g_flags[2]&USEDFLAG))){
	if(section!=DATA){emit(f,dataname);section=DATA;}
      }
      if(v->clist&&constflag&&!(g_flags[2]&USEDFLAG)){
	if(section!=RODATA) {emit(f,rodataname);section=RODATA;}
      }
      if(!v->clist){
	if(section!=BSS){emit(f,bssname);if(f) section=BSS;}
      }
    }else{
      char *type="bss",*attr="aurw";int fartype=pointer_varadr(v,1);
      if(ISFUNC(v->vtyp->flags)){ type="text";attr="acrx";}
      else if(IIGS&&fartype==POINTER&&!large&&!huge){ type="zpage";attr="adrwz";}
      else if(constflag) {type="rodata";attr="adr";}
      else if(v->clist) {type="data";attr="adrw";}
      emit(f,"\tsection\t\"DONTMERGE_%s.%s.%s.%ld\",\"%s\"\n",type,fartype==POINTER?"near":((fartype==FPOINTER||fartype==FLPOINTER)?"far":"huge"),v->identifier,v->storage_class==STATIC?(long)zm2l(v->offset):0L,attr);
    }
  }
}

#define chk_coll(x) do{if((x)==r||(x)==r1||(x)==r2) return 0;	\
    if(reg_pair((x),&rp)&&(rp.r1==r||rp.r2==r)) return 0;}while(0)

static int scratch(IC *p,int r,int isnext)
{
  int r1,r2;
  if(!p) return 1;
  if(reg_pair(r,&rp)){
    r1=rp.r1;
    r2=rp.r2;
  }else{
    r1=0;
    r2=0;
  }
  if(!isnext&&isreg(z)&&p->z.reg==r){
    if(p->code==GETRETURN&&(p->q1.reg==ra||p->q1.reg==rax))
      return 0;
    if(!(p->q2.flags&REG))
      return 1;
    if(p->q2.reg==r||p->q2.reg==r1||p->q2.reg==r2)
      return 0;
    if(reg_pair(p->q2.reg,&rp))
      if(rp.r1==r||rp.r2==r)
	return 0;
    return 1;
  }
  while(p){
    if(p->code==LABEL||p->code==CALL)
      return 0;
    if(p->code>=BEQ&&p->code<=BRA)
      return 0;
    if(p->code==FREEREG||p->code==ALLOCREG){
      if(p->q1.reg==r)
	return 1;
      if(reg_pair(p->q1.reg,&rp)&&(rp.r1==r||rp.r2==r))
	return 1;
    }
    if(p->q1.am){
      chk_coll(p->q1.am->base);
      if(p->q1.am->flags!=IMM_IND) chk_coll(p->q1.am->idx);
    }
    if(p->q2.am){
      chk_coll(p->q2.am->base);
      if(p->q2.am->flags!=IMM_IND) chk_coll(p->q2.am->idx);
    }
    if(p->z.am){
      chk_coll(p->z.am->base);
      if(p->z.am->flags!=IMM_IND) chk_coll(p->z.am->idx);
    }
    if(p->q1.flags&REG) chk_coll(p->q1.reg);
    if(p->q2.flags&REG) chk_coll(p->q2.reg);
    if(p->z.flags&REG){
      if(p->z.flags&DREFOBJ)
	chk_coll(p->z.reg);
      else{
	if(p->z.reg==r)
	  return 1;
	if(reg_pair(p->z.reg,&rp)&&(rp.r1==r||rp.r2==r))
	  return 1;
      }
    }

    p=p->next;
  }
  return 1;
}

static int rsavecur;
static int in_isr;

static int get_reg(FILE *f,IC *p,int t)
{
  int r,r1,r2,pass,flag;

  if(ISNPOINTER(t)&&!regs[rx]){
    regs[rx]|=8;
    regused[rx]=1;
    return rx;
  }

  for(pass=0;pass<5;pass++){
    for(r=MAXR;r>sp;r--){
      if(reg_pair(r,&rp)){
	r1=rp.r1;
	r2=rp.r2;
      }else{
	r1=0;
	r2=0;
      }
      if((pass==0||pass==3)&&(!regscratch[r]||in_isr))
	continue;
      if(pass<3){
	if(regs[r]) continue;
	if(r1&&(regs[r1]||regs[r2])) continue;
      }
      if(pass==2&&!(regs[r]&4))
	continue;
      if(p->q1.flags&REG){
	if(p->q1.reg==r||p->q1.reg==r1||p->q1.reg==r2) continue;
	if(r1==0&&reg_pair(p->q1.reg,&rp)&&(rp.r1==r||rp.r2==r)) continue;
      }
      if(p->q2.flags&REG){
	if(p->q2.reg==r||p->q2.reg==r1||p->q2.reg==r2) continue;
	if(r1==0&&reg_pair(p->q2.reg,&rp)&&(rp.r1==r||rp.r2==r)) continue;
      }
      if(p->z.flags&REG){
	if(p->z.reg==r||p->z.reg==r1||p->z.reg==r2) continue;
	if(r1==0&&reg_pair(p->z.reg,&rp)&&(rp.r1==r||rp.r2==r)) continue;
      }
      if(regok(r,t,1)&&r!=rx){
	char preg;
	flag=8;
	if(regs[r]){
	  if(r>=FIRST_BIG&&r<=LAST_BIG)
	    continue;
	  if(r>=FIRST_BIGP&&r<=LAST_BIGP)
	    ierror(0);
	  flag|=2;
	  if(p->code==COMPARE||p->code==TEST||bmode)
	    ierror(0);
	  if(regs[ra]){
	    preg='y';
	    yval=NOVAL;
	  }else
	    preg='a';
	  if(msizetab[t&NQ]>2){
	    emit(f,"\tld%c\t%s+2\n",preg,mregnames[r]);
	    emit(f,"\tph%c\n",preg);
	    push(2);
	  }
	  emit(f,"\tld%c\t%s\n",preg,mregnames[r]);
	  emit(f,"\tph%c\n",preg);
	  push(2);
	  if(regs[ra])
	    emit(f,"\ttya\n");
	}
	if(r1){
	  regs[r1]|=flag;
	  regs[r2]|=flag;
	}
	regs[r]|=flag;
	regused[r]=1;
	regused[r1]=1;
	regused[r2]=1;
	/*emit(f,"; p=%p r=%s\n",(void*)p,mregnames[r]);*/
	return r;
      }
    }
  }
  pric2(stdout,p);
  ierror(0);
}

static void get_acc(FILE *f, IC *p,int t)
{
  int r;
  if(isacc(z)&&!fpop&&p->code!=GETRETURN) return;
  t&=NQ;
  if((regs[ra]||regs[rax])&&(!scratch(p,ra,0)||fpop)&&!pushedacc){
    if(storedacc)
      pushedacc=storedacc;
    else if((regs[t1]&&regs[t2]&&regs[t3]&&regs[t4]&&p->code!=PUSH)){
      if(bmode) ierror(0);
      emit(f,"\tpha\n");
      push(2);
      pushedacc=-1;
    }else{
      if(bmode) ierror(0);
      r=get_reg(f,p,INT);
      if(!r) ierror(0);
      emit(f,"\tsta\t%s\n",mregnames[r]);
      pushedacc=r;
    }
  }
}

static int cmp_get_acc(FILE *f,IC *p,IC *branch)
{
  if(!regs[ra]&&!regs[rax])
    return 0;
  if(branch==0&&pushedacc)
    return 0;
  if(branch&&isreg(q1)&&(p->q1.reg==ra||p->q1.reg==rax))
    if(branch->code==BEQ||branch->code==BNE||(p->typf&UNSIGNED))
      return 0;
  if(scratch(p,ra,0))
    return 0;
  if(bmode) ierror(0);
  if(!regs[rx]&&!regs[rax]){
    emit(f,"\ttax\n");
    pushedacc=rx;
  }else{
    emit(f,"\tpha\n");
    push(2);
    pushedacc=-1;
  }
  return pushedacc;
}

static void reload_acc_opt(FILE *f,IC *p)
{
  if(pushedacc==0) return;
  if(pushedacc>0){
    while(p){
      if(p->code!=FREEREG) break;
      if(p->q1.reg==ra||p->q1.reg==rax){
	pushedacc=0;
	return;
      }
      p=p->next;
    }
  }
  if(pushedacc==-1)
    {emit(f,"\tpla\n");pop(2);}
  else if(pushedacc==rx)
    emit(f,"\ttxa\n");
  else if(pushedacc==ry)
    emit(f,"\ttya\n");
  else if(pushedacc){
    emit(f,"\tlda\t%s\n",mregnames[pushedacc]);
    regs[pushedacc]&=~8;
  }
  pushedacc=0;
}

static void reload_acc(FILE *f)
{
  reload_acc_opt(f,0);
}

static int longaddr(obj *o)
{
  int t;
  if(o->am)
    t=o->am->dt&NQ;
  else if(o->flags&(DREFOBJ|KONST))
    t=o->dtyp&NQ;
  else if(o->flags&REG)
    t=0;
  else
    t=pointer_varadr(o->v,1)&NQ;
  return t==POINTER?0:t;
}

typedef enum {LDX=1, LDY=2, STX=4, STY=8, STZ=16, CPX=32, INC=64} ind_t;

static int indirect(obj *o,ind_t type)
{
  if(o->flags&VARADR) return 0;
  if((o->flags&(KONST|DREFOBJ))==KONST) return 0;
  if(longaddr(o)) return 1;
  if(o->am){
    if(o->am->flags==ABS_IND&&o->am->idx==rx&&!(type&(LDX|STX|STY|CPX)))
      return 0;
    //    else if(!nox&&o->am->flags==IMM_IND&&o->am->base==rx)
    //return 0;
    else
      return 1;
  }
  if((o->flags&(DREFOBJ|REG))==(REG|DREFOBJ)&&o->reg==rx&&!(type&(LDX|STX|STY|CPX)))
    return 0;
  if((o->flags&(DREFOBJ|KONST))==DREFOBJ)
    return 1;
  if(o->flags&KONST)
    return 0;
  if((o->flags&(REG|VAR))!=VAR){
    if((o->flags&REG)&&(o->reg==ra||ISIDX(o->reg)||o->reg==rax))
      return 1;
    return 0;
  }
  if(ISSTACK(o->v->storage_class))
    return 1;
  return 0;
}


static void convfloat(void)
{
}  

static void sety(FILE *f,long val)
{
  if(yval==val)
    return;
  if(val-yval==1)
    emit(f,"\tiny\n");
  else if(yval-val==1)
    emit(f,"\tdey\n");
  else{
    emit(f,"\tldy\t#%ld\n",val);
    if(val<0||val>65535)
      ierror(0);
  }
  yval=val;
}

static void cnv_fp(void)
{
  double d,mant;
  int exp;
  unsigned long t;

  if(ieee){
    vfloat=zld2zf(vldouble);
    memcpy((void*)&vmax,(void*)&vfloat,4);
  }else{
    d=zld2d(vldouble);
    mant=frexp(d,&exp);
    if(ms4){
      if(mant>=0)
	t=((unsigned long)(mant*(65536.*256.)))&0x7fffff;
      else
	t=(((unsigned long)((-mant)*(65536.*256.)))&0x7fffff)|0x800000;
      exp=(exp+128)&255;
      if(d==0) exp=0;
      t=exp|((t&0xff0000)>>8)|((t&0xff00)<<8)|((t&0xff)<<24);
      vmax=l2zm((long)t);
    }else{
      exp=(exp+127)&255;
      t=((unsigned long)(mant*8388608))&0xffffff;
      t|=((long)exp)<<24;
      
      t=((t&0xff)<<24)|((t&0xff00)<<8)|((t&0xff0000)>>8)|((t&0xff000000)>>24);
      vmax=l2zm((long)t);
      if(mant==0&&d==0) vmax=Z0;
    }
  }
}

static void emit_ieee(FILE *f,union atyps *p,int t)
{
  unsigned char *ip=(unsigned char *)&p->vdouble;
  emit(f,"0x%02x%02x,0x%02x%02x",ip[1],ip[0],ip[3],ip[2]);
  if(t==DOUBLE||t==LDOUBLE)
    emit(f,",0x%02x%02x,0x%02x%02x",ip[5],ip[4],ip[7],ip[6]);
  emit(f,"\n");
}

static void emit_lobyte(FILE *f,obj *o,int t)
{
  if(o->flags&KONST){
    if(o->flags&DREFOBJ){
      if(!ISNPOINTER(o->dtyp)) emit(f,">");
      eval_const(&o->val,o->dtyp);
       emit(f,"%ld",zm2l(vmax));
    }else{
      eval_const(&o->val,t);
      if(ISFLOAT(t)) cnv_fp();
      if(!bmode)
	emit(f,"#%ld",zm2l(vmax)&65535);
      else
	emit(f,"#%ld",zm2l(vmax)&255);
    }
  }else if(o->flags&VARADR){
    emit(f,"#<");
    emit_obj(f,o,t);
  }else if((o->flags&(REG|DREFOBJ))==REG){
    emit(f,"%s",mregnames[o->reg]);
  }else{
    if((o->flags&(DREFOBJ|KONST))==DREFOBJ&&((o->flags&(VAR|REG))!=VAR||!ISSTACK(o->v->storage_class))) noy=1;
    emit_obj(f,o,t);
    noy=0;
  }
}

static void emit_hibyte(FILE *f,obj *o,int t)
{
  if(o->flags&KONST){
    if(o->flags&DREFOBJ){
      eval_const(&o->val,o->dtyp);
      emit(f,"%ld",zm2l(vmax)+1);
    }else{
      eval_const(&o->val,t);
      if(ISFLOAT(t)) cnv_fp();
      emit(f,"#%d",(int)((zm2l(vmax)>>8)&255));
    }
  }else if(o->flags&VARADR){
    emit(f,"#<");
    emit_obj(f,o,t);
  }else if((o->flags&(REG|DREFOBJ))==REG){
    emit(f,"%s+1",mregnames[o->reg]);
  }else{
    int xoff=((o->flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&o->reg==rx);
    if(o->flags&VARADR)
      emit(f,"#");
    if(xoff||!(o->flags&DREFOBJ))
      o->val.vmax=zmadd(o->val.vmax,Z1);
    emit_obj(f,o,t);
    if(xoff||!(o->flags&DREFOBJ))
      o->val.vmax=zmsub(o->val.vmax,Z1);
  }
}

static void emit_byte3(FILE *f,obj *o,int t)
{
  if(o->flags&KONST){
    if(o->flags&DREFOBJ){
      eval_const(&o->val,o->dtyp);
      emit(f,"%ld",zm2l(vmax)+2);
    }else{
      eval_const(&o->val,t);
      if(ISFLOAT(t)) cnv_fp();
      if(!bmode)
	emit(f,"#%ld",(zm2l(vmax)>>16)&65535);
      else
	emit(f,"#%d",(int)((zm2l(vmax)>>16)&255));
    }
  }else if((o->flags&(REG|DREFOBJ))==REG){
    emit(f,"%s+2",mregnames[o->reg]);
  }else if(o->flags&VARADR){
    emit(f,"#^(");emit_obj(f,o,t);emit(f,")");
  }else{
    int xoff=((o->flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&o->reg==rx);
    if(xoff||!(o->flags&DREFOBJ))
      o->val.vmax=zmadd(o->val.vmax,l2zm(2L));
    emit_obj(f,o,t);
    if(xoff||!(o->flags&DREFOBJ))
      o->val.vmax=zmsub(o->val.vmax,l2zm(2L));
  }
}

static void emit_byte4(FILE *f,obj *o,int t)
{
  if(o->flags&KONST){
    if(o->flags&DREFOBJ){
      eval_const(&o->val,o->dtyp);
      emit(f,"%ld",zm2l(vmax)+3);
    }else{
      eval_const(&o->val,t);
      if(ISFLOAT(t)) cnv_fp();
      emit(f,"#%d",(int)((zm2l(vmax)>>24))&255);
    }
  }else if((o->flags&(REG|DREFOBJ))==REG){
    emit(f,"%s+3",mregnames[o->reg]);
  }else{
    int xoff=((o->flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&o->reg==rx);
    if(xoff||!(o->flags&DREFOBJ))
      o->val.vmax=zmadd(o->val.vmax,l2zm(3L));
    emit_obj(f,o,t);
    if(xoff||!(o->flags&DREFOBJ))
      o->val.vmax=zmsub(o->val.vmax,l2zm(3L));
  }
}

static int amreload,amreloaded,amcmpreload;

static void do_amreload(FILE *f)
{
  if(amreload){
    if(amcmpreload) emit(f,"\tphp\n");
    emit(f,"\ttyx\n");
    if(amcmpreload) emit(f,"\tplp\n");
    amreloaded=1;
  }else
    amreloaded=0;
  amreload=0;
}

static void do_amload(FILE *f,obj *o)
{
  char *r="y";
  amreload=0;
  if(o->am->flags==GPR_IND||o->am->flags==ABS_IND){
    if(o->am->flags==ABS_IND&&!ISNPOINTER(o->am->dt)){
      if(regs[rx]&&o->am->idx!=rx){emit(f,"\ttxy\n");amreload=1;}
      r="x";
    }
    if(o->am->idx==ra)
      emit(f,"\tta%s\n",r);
    else{
      if(ISIDX(o->am->idx)){
	if(o->am->flags==GPR_IND){
	  emit(f,"\ttxy\n");
	}
      }else{
	if(o->am->idx==ra)
	  emit(f,"\tta%s\n",r);
	else
	  emit(f,"\tld%s\t%s\n",r,mregnames[o->am->idx]);
      }
    }
    if(r[0]=='y') yval=NOVAL;
  }else
    ierror(0);
}
static void do_lobyte(FILE *f,char *s,obj *o,int type)
{
  if(o->am){
    if(o->am->flags==IMM_IND){
      if(!ISIDX(o->am->base)) sety(f,o->am->offset);
    }else{
      do_amload(f,o);
    }
  }else if((o->flags&(DREFOBJ|KONST))==DREFOBJ){
    if((o->flags&(VAR|REG))==VAR&&ISSTACK(o->v->storage_class)) sety(f,0);
  }else if((o->flags&(VAR|REG|VARADR))==VAR&&ISSTACK(o->v->storage_class)){
    if(fp!=sp)
      sety(f,(int)real_offset(o));
  }
  emit(f,"\t%s\t",s);
  emit_lobyte(f,o,type);
  emit(f,"\n");
  do_amreload(f);
}

static void do_hibyte(FILE *f,char *s,obj *o,int type)
{
  int ami=0;
  if(o->am){
    if(o->am->flags==IMM_IND){
      if(ISIDX(o->am->base)){
	o->am->offset++;ami=1;
      }else
	sety(f,o->am->offset+1);
    }else{
      do_amload(f,o);
      if(o->am->flags==GPR_IND){
	emit(f,"\tiny\n");
      }else{
	o->am->offset++;ami=1;
      }
    }
  }else  if((o->flags&(DREFOBJ|KONST))==DREFOBJ){
    if(!(o->flags&REG)||o->reg!=rx) sety(f,1);
  }else if((o->flags&(VAR|REG|VARADR))==VAR&&ISSTACK(o->v->storage_class)){
    if(fp!=sp)
      sety(f,(int)real_offset(o)+1);
  }
  emit(f,"\t%s\t",s);
  emit_hibyte(f,o,type);
  emit(f,"\n");
  do_amreload(f);
  if(ami) o->am->offset--;
}

static void do_byte3(FILE *f,char *s,obj *o,int type)
{
  int ami=0;
  if(o->am){
    if(o->am->flags==IMM_IND){
      if(ISIDX(o->am->base)){
	o->am->offset+=2;ami=1;
      }else
	sety(f,o->am->offset+2);
    }else{
      do_amload(f,o);
      if(o->am->flags==GPR_IND){
	emit(f,"\tiny\n\tiny\n");
      }else{
	o->am->offset+=2;ami=1;
      }
    }
  }else  if((o->flags&(DREFOBJ|KONST))==DREFOBJ){
    if(!(o->flags&REG)||o->reg!=rx) sety(f,2);
  }else if((o->flags&(VAR|REG|VARADR))==VAR&&ISSTACK(o->v->storage_class)){
    if(fp!=sp)
      sety(f,(int)real_offset(o)+2);
  }
  emit(f,"\t%s\t",s);
  emit_byte3(f,o,type);
  emit(f,"\n");
  do_amreload(f);
  if(ami) o->am->offset-=2;
}

static void do_byte4(FILE *f,char *s,obj *o,int type)
{
  int ami=0;
  if(o->am){
    if(o->am->flags==IMM_IND){
      if(ISIDX(o->am->base)){
	o->am->offset+=3;ami=1;
      }else
	sety(f,o->am->offset+3);
    }else{
      do_amload(f,o);
      if(o->am->flags==GPR_IND){
	emit(f,"\tiny\n\tiny\n\tiny\n");
      }else{
	o->am->offset+=3;ami=1;
      }
    }
  }else  if((o->flags&(DREFOBJ|KONST))==DREFOBJ){
    if(!(o->flags&REG)||o->reg!=rx) sety(f,3);
  }else if((o->flags&(VAR|REG|VARADR))==VAR&&ISSTACK(o->v->storage_class)){
    if(fp!=sp)
      sety(f,(int)real_offset(o)+3);
  }
  emit(f,"\t%s\t",s);
  emit_byte4(f,o,type);
  emit(f,"\n");
  do_amreload(f);
  if(ami) o->am->offset-=3;
}

static void load_lobyte(FILE *f,obj *o,int t)
{
  if((o->flags&(REG|DREFOBJ))==REG){
    if(o->reg==ra||o->reg==rax)
      return;
    if(o->reg==rx){
      emit(f,"\ttxa\n");
      return;
    }
  }
  do_lobyte(f,"lda",o,t);
}

static void load_hibyte(FILE *f,obj *o,int t)
{
  if((o->flags&(REG|DREFOBJ))==REG&&(o->reg==rx||o->reg==rax))
    emit(f,"\ttxa\n");
  else
    do_hibyte(f,"lda",o,t);
}

static void load_byte3(FILE *f,obj *o,int t)
{
  if((o->flags&(REG|DREFOBJ))==REG&&(o->reg==rx||o->reg==rax))
    emit(f,"\ttxa\n");
  else
    do_byte3(f,"lda",o,t);
}

static void store_lobyte(FILE *f,obj *o,int t)
{
  if((o->flags&(REG|DREFOBJ))==REG){
    if(o->reg==ra||o->reg==rax)
      return;
    if(o->reg==rx){
      emit(f,"\ttax\n");
      return;
    }
    if(o->reg==ry){
      emit(f,"\ttay\n");
      return;
    }
  }
  do_lobyte(f,"sta",o,t);
}

static void store_hibyte(FILE *f,obj *o,int t)
{
  ierror(0);
  if((o->flags&(REG|DREFOBJ))==REG&&(o->reg==rx||o->reg==rax))
    emit(f,"\ttax\n");
  else
    do_hibyte(f,"sta",o,t);
}

static void store_byte3(FILE *f,obj *o,int t)
{
  if((o->flags&(REG|DREFOBJ))==REG&&(o->reg==rx||o->reg==rax))
    emit(f,"\ttax\n");
  else
    do_byte3(f,"sta",o,t);
}

static void load_acc(FILE *f,obj *o,int type)
{
  long sz;
  if((o->flags&(REG|DREFOBJ))==REG){
    if(o->reg==ra||o->reg==rax)
      return;
    if(o->reg==rx){
      emit(f,"\ttxa\n");
      return;
    }
  }
  sz=zm2l(sizetab[type&NQ]);
  if(sz>2){
    if(indirect(o,LDX)){
      if(sz==3&&is_volatile_obj(o)) BMODE();
      load_byte3(f,o,type);
      emit(f,"\ttax\n");
      WMODE();
    }else{
      if(sz==3&&is_volatile_obj(o)) BXMODE();
      do_byte3(f,"ldx",o,type);
      WXMODE();
    }
  }
  if(ISCHAR(type)&&is_volatile_obj(o)) BMODE();
  load_lobyte(f,o,type);
}

static void store_acc(FILE *f,obj *o,int type)
{
  if((o->flags&REG)&&(o->reg==ra||o->reg==rax))
    return;
  if(((o->flags&(REG|DREFOBJ))==REG)&&o->reg==rx){
    emit(f,"\ttax\n");
    return;
  }
  if(ISCHAR(type)/*&&(o->flags&(REG|DREFOBJ))!=REG*/) BMODE();
  store_lobyte(f,o,type);
  if(zm2l(sizetab[type&NQ])>2){
    if(indirect(o,STX)){
      /*TODO: save accu */
      emit(f,"\ttxa\n");
      store_byte3(f,o,type);
    }else
      do_byte3(f,"stx",o,type);
  }
}

static void load_reg(FILE *f,int r,struct obj *o,int type)
{
  static obj ro;int sz;
  if((r==rx&&!indirect(o,LDX))||(r==ry&&!indirect(o,LDY))){
    static char ldr[4]="ldr";
    if((o->flags&(REG|DREFOBJ))==REG&&r==o->reg) return;
    ldr[2]=mregnames[r][0];
    do_lobyte(f,ldr,o,type);
    return;
  }
  ro.flags=REG;
  ro.reg=r;
  load_lobyte(f,o,type);
  store_lobyte(f,&ro,type);
  sz=zm2l(sizetab[type&NQ]);
  if(sz<=2) return;
  if((o->flags&(REG|DREFOBJ))==REG&&r==rax){
    do_byte3(f,"stx",&ro,type);
  }else{
    if(sz==3&&((type&VOLATILE)||(o->dtyp&VOLATILE))) BMODE();
    load_byte3(f,o,type);
    store_byte3(f,&ro,type);
    WMODE();
  }
}

static void store_reg(FILE *f,int r,struct obj *o,int type)
{
  static obj ro;
  if(ISIDX(r)){
    if((o->flags&(REG|DREFOBJ))==REG){
      if(o->reg==r)
	return;
      if(o->reg==ra){
	emit(f,"\tt%sa\n",mregnames[r]);
	return;
      }
    }
    if((r==ry&&!indirect(o,STY))||(r==rx&&!indirect(o,STX))){
      static char str[4]="str";
      str[2]=mregnames[r][0];
      do_lobyte(f,str,o,type);
      return;
    }
  }
  ro.flags=REG;
  ro.reg=r;
  if(r!=ra&&r!=rax)
    load_acc(f,&ro,type);
  store_acc(f,o,type);
}

static struct fpconstlist {
  struct fpconstlist *next;
  int label;
  int t;
  union atyps val;
} *firstfpc;

static int addfpconst(struct obj *o,int t)
{
  struct fpconstlist *p=firstfpc;
  t&=NQ;
  if(t==LDOUBLE) t=DOUBLE;
  for(p=firstfpc;p;p=p->next){
    if(t==p->t){
      eval_const(&p->val,t);
      if(t==FLOAT&&ieee&&zldeqto(vldouble,zf2zld(o->val.vfloat))) return p->label;
      if(t==FLOAT&&!ieee&&zldeqto(vldouble,zf2zld(o->val.vfloat))) return p->label;
      if(t==DOUBLE&&zldeqto(vldouble,zd2zld(o->val.vdouble))) return p->label;
      if(t==LONG&&zmeqto(vmax,zl2zm(o->val.vlong))) return p->label;
      if(t==LLONG&&zmeqto(vmax,zll2zm(o->val.vllong))) return p->label;
    }
  }
  p=mymalloc(sizeof(struct fpconstlist));
  p->next=firstfpc;
  p->t=t;
  p->label=++label;
  p->val=o->val;
  firstfpc=p;
  return p->label;
}

/* generate code to load the address of a local variable into register r */
static void load_laddr(FILE *f,int r,struct obj *o)
{
  long l=real_offset(o);
  /* assumes acc is available */
  //if(r!=rx&&r!=ry&&!reg_pair(r,&rp)) ierror(0);
  if(l<0) ierror(0);
  if(r==rx&&fp==sp&&l<=4){
    emit(f,"\ttsx\n");
    while(l--) emit(f,"\tinx\n");
    return;
  }
  if(fp==sp)
    emit(f,"\ttsc\n");
  else
    emit(f,"\tlda\t%s\n",mregnames[fp]);
  if(l==1) emit(f,"\tina\n");
  else if(l==2) emit(f,"\tina\n\tina\n");
  else if(l==3&&optsize)  emit(f,"\tina\n\tina\n\tina\n");
  else if(l!=0) emit(f,"\tclc\n\tadc\t#%ld\n",l);
  if(r==rx)
    emit(f,"\ttax\n");
  else if(r==ry)
    emit(f,"\ttay\n");
  else if(r!=ra)
    emit(f,"\tsta\t%s\n",mregnames[r]);
}

/* get the banktype of the address of o */
enum banktype get_bt(struct obj *o)
{
  int l;
  if((o->flags&(DREFOBJ|KONST|VARADR))==DREFOBJ){
    if(longaddr(o)) return fardyn;
    return nearbank;
  }
  if(o->flags&REG) return stackbank; /* TODO: check? */
  if(o->flags&KONST) return farconst;
  if(o->flags&VAR){
    if(o->v->storage_class==AUTO||o->v->storage_class==REGISTER)
      return stackbank;
    l=longaddr(o);
    if(l) return farconst; else return nearbank;
  }
  ierror(0);
}

/* load bank of address of obj o */
static void load_abank(FILE *f,obj *o)
{
  if(o->flags&DREFOBJ){
    o->flags&=~DREFOBJ;
    load_byte3(f,o,FPOINTER);
    o->flags|=DREFOBJ;
  }else if(o->flags&REG){
    emit(f,"\tlda\t#^%s\n",mregnames[o->reg]);
  }else if(o->flags&VAR){
    if(o->v->storage_class==AUTO||o->v->storage_class==REGISTER){
      emit(f,"\tlda\t#0\n");
    }else{
      if(o->flags&VARADR) ierror(0);
      o->flags|=VARADR;
      load_byte3(f,o,FPOINTER);
      o->flags&=~VARADR;
    }
  }else
    ierror(0);
}

/* generate code to load the 16bit address of an operand into register r */
static void load_address(FILE *f,int r,struct obj *o,int t)
{
  if(o->flags&DREFOBJ){
    if((o->flags&REG)&&o->reg==r) return;
    o->flags&=~DREFOBJ;
    load_reg(f,r,o,POINTER);
    o->flags|=DREFOBJ;
  }else if((o->flags&(REG|DREFOBJ))==REG){
    emit(f,"\tlda\t#<%s\n",mregnames[o->reg]);
    emit(f,"\tsta\t%s\n",mregnames[r]);
  }else if(o->flags&VAR){
    if(ISSTACK(o->v->storage_class)){
      load_laddr(f,r,o);
    }else{
      o->flags|=VARADR;
      load_reg(f,r,o,POINTER);
      o->flags&=~VARADR;
    }
  }else if((o->flags&(KONST|DREFOBJ))==KONST){
    int l=addfpconst(o,t);
    if(!ieee) ierror(0);
    emit(f,"\tlda\t#<%s%d\n",labprefix,l);
    emit(f,"\tsta\t%s\n",mregnames[r]);
  }else
    ierror(0);
}

/* generate code to push the 32bit address of an operand into register r */
static void push_address(FILE *f,struct obj *o,int t)
{
  if(o->flags&DREFOBJ){
    if(o->flags&REG){
      if(ISNPOINTER(o->dtyp))
	emit(f,"\tpea\t#^__DBR_init\n");
      else
	emit(f,"\tpei\t(%s+2)\n",mregnames[o->reg]);
      emit(f,"\tpei\t(%s)\n",mregnames[o->reg]);
      push(4);dontpop+=4;
    }else{
      if((o->dtyp&NQ)==POINTER){
	emit(f,"\tpea\t#^__DBR_init\n");
      }else{
	load_byte3(f,o,INT);
	emit(f,"\tpha\n");
      }
      push(2);dontpop+=2;
      load_lobyte(f,o,INT);
      emit(f,"\tpha\n");
      push(2);dontpop+=2;
    }
  }else if((o->flags&(REG|DREFOBJ))==REG){
    emit(f,"\tpea\t#^%s+2\n",mregnames[o->reg]);
    emit(f,"\tpea\t#<%s\n",mregnames[o->reg]);
    push(4);dontpop+=4;
  }else if(o->flags&VAR){
    if(ISSTACK(o->v->storage_class)){
      emit(f,"\tpea\t#0\n");
      load_laddr(f,ra,o);
      emit(f,"\tpha\n");
    }else{
      nomod=1;
      emit(f,"\tpea\t#^");emit_obj(f,o,t);emit(f,"\n");
      emit(f,"\tpea\t#<");emit_obj(f,o,t);emit(f,"\n");
      nomod=0;
    }
    push(4);dontpop+=4;
  }else if((o->flags&(KONST|DREFOBJ))==KONST){
    int l=addfpconst(o,t);
    if(!ieee) ierror(0);
    //if(!reg_pair(r,&rp)) ierror(0);
    emit(f,"\tpea\t#^%s%d\n",labprefix,l);
    emit(f,"\tpea\t#<%s%d\n",labprefix,l);
    push(4);dontpop+=4;
  }else
    ierror(0);
}

/*  Yields log2(x)+1 or 0. */
static long pof2(zumax x)
{
  zumax p;int ln=1;
  p=ul2zum(1L);
  while(ln<=32&&zumleq(p,x)){
    if(zumeqto(x,p)) return ln;
    ln++;p=zumadd(p,p);
  }
  return 0;
}

static void incmem(FILE *f,obj *o,int t,int op,int x)
{
  int i,reg=0;
  char *s;
  if((o->flags&(REG|DREFOBJ))==REG&&(ISIDX(o->reg)||o->reg==ra||o->reg==rax)){
    static char buf[4]="   ";
    reg=o->reg;s=buf;
    if(op==ADD){s[0]='i';s[1]='n';}else{s[0]='d';s[1]='e';}
    s[2]=mregnames[o->reg][0];
  }else if(op==ADD)
    s="inc";
  else if(op==SUB)
    s="dec";
  else if(op==LSHIFT)
    s="asl";
  else if(op==RSHIFT&&(t&UNSIGNED))
    s="lsr";
  else if(op==RSHIFT){
    if(!bmode)
      s="cmp\t#32768\n\tror";
    else
      s="cmp\t#128\n\tror";
  }else
    ierror(0);
  if(ISCHAR(t)||ISSHORT(t)){
    if(ISCHAR(t)/*&&(o->flags&(REG|DREFOBJ))!=REG*/) BMODE();
    for(i=0;i<x;i++){
      if(reg){
	emit(f,"\t%s\n",s);
      }else{
	emit(f,"\t%s\t",s);
	emit_obj(f,o,t);
	emit(f,"\n");
      }
    }
    if(bmode==1) WMODE();
  }else{
    for(i=0;i<x;i++){
      if(op==SUB){
	ierror(0);
      }else if(op==ADD){
	if(!reg){
	  emit(f,"\tinc\t");
	  emit_lobyte(f,o,t);
	  emit(f,"\n");
	}else
	  emit(f,"\t%s\n",s);
	emit(f,"\tbne\t%s%d\n",labprefix,++label);
	if(!reg){
	  emit(f,"\tinc\t");
	  emit_byte3(f,o,t);
	  emit(f,"\n");
	}else
	  emit(f,"\tinx\n");
	emit(f,"%s%d:\n",labprefix,label);
      }else if(op==LSHIFT){
	emit(f,"\tasl\t");
	emit_lobyte(f,o,t);
	emit(f,"\n");
	if(ISLONG(t))
	  do_byte3(f,"rol",o,t);
      }else if(op==RSHIFT&&(t&UNSIGNED)){
	/*emit(f,"\tclc\n");
	  emit(f,"\tror\t");*/
	if(ISLONG(t)){
	  do_byte3(f,"lsr",o,t);
	  do_lobyte(f,"ror",o,t);
	}else
	  do_lobyte(f,"lsr",o,t);
      }else if(op==RSHIFT){
	if(ISLONG(t)){
	  load_byte3(f,o,t);
	  emit(f,"\tcmp\t#32768\n");
	  do_byte3(f,"ror",o,t);
	  do_lobyte(f,"ror",o,t);
	}else{
	  load_acc(f,o,t);
	  emit(f,"\tcmp\t#32768\n");
	  do_lobyte(f,"ror",o,t);
	}
      }else{
	printf("op=%d\n",op);
	ierror(0);
      }
    }
  }
}

static void preload_obj(FILE *f,IC *p,obj *o)
{
  int r,pa=0,px=0;long of;

  if(is_volatile_ic(p))
    emit(f,"; volatile barrier\n");


  if((o->flags&(VAR|REG))==VAR&&ISSTACK(o->v->storage_class)){
    long sz;
    if(o==&p->q1) sz=zm2l(sizetab[q1typ(p)&NQ]);
    else if(o==&p->q2) sz=zm2l(sizetab[q2typ(p)&NQ]);
    else sz=zm2l(sizetab[ztyp(p)&NQ]);
    if(sz>8) sz=8;
    of=real_offset(o);
    if(of>255-sz){
      int dt;
      if(large){
	if(ptr24) dt=FPOINTER; else dt=FLPOINTER;
      }else if(huge){
	if(ptr24) dt=HPOINTER; else dt=HLPOINTER;
      }else
	dt=POINTER;
      r=get_reg(f,p,dt);
      if((regs[ra]||regs[rax])){
	if((p->q1.flags&REG)&&(p->q1.reg==ra||p->q1.reg==rax)) pa=1;
	if((p->q2.flags&REG)&&(p->q2.reg==ra||p->q2.reg==rax)) pa=1;
	if((p->z.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&(p->q2.reg==ra||p->q2.reg==rax)) pa=1;
	if(pa) emit(f,"\tsta\t%s\n",mregnames[t1]);
      }
      if(!pa){
	if(o->flags&DREFOBJ){
	  if(p->code==GETRETURN&&(p->q1.reg==ra)){
	    emit(f,"\tsta\t%s\n",mregnames[t1]);
	    pa=1;
	  }else if(r!=rx)
	    get_acc(f,p,INT);
	}else{
	  if(p->code==GETRETURN&&(p->q1.reg==ra)){
	    emit(f,"\tsta\t%s\n",mregnames[t1]);
	    pa=1;
	  }else if(r!=rx){
	    cmp_get_acc(f,p,0);
	    of=real_offset(o);
	  }
	}
      }
      if(r==rx){
	emit(f,"\ttsx\n");
	if(o->flags&DREFOBJ){
	  get_acc(f,p,INT);
	  if((o->dtyp&NQ)==POINTER){
	    emit(f,"\tlda\t!%ld,x\n",of);
	    emit(f,"\ttax\n");
	  }else{
	    r=get_reg(f,p,(o->dtyp&NQ));
	    emit(f,"\tlda\t!%ld,x\n",of);
	    emit(f,"\tsta\t%s\n",mregnames[r]);
	    emit(f,"\tlda\t!%ld,x\n",of+2);
	    emit(f,"\tsta\t%s+2\n",mregnames[r]);
	  }
	}else{
	  struct AddressingMode *am;
	  o->am=am=mymalloc(sizeof(*am));
	  am->flags=IMM_IND;
	  am->base=r;
	  am->offset=of;
	  am->dt=dt;
	  o->dtyp=dt;
	  o->flags|=DREFOBJ;
	}
	o->flags|=REG;
	o->reg=r;
      }else{
	emit(f,"\ttsc\n");
	emit(f,"\tclc\n");
	emit(f,"\tadc\t#%ld\n",of);
	emit(f,"\tsta\t%s\n",mregnames[r]);
	if(dt!=POINTER) emit(f,"\tstz\t%s+2\n",mregnames[r]); 
	o->flags|=REG;
	o->reg=r;
	if(o->flags&DREFOBJ){
	  if((o->dtyp&NQ)==POINTER){
	    emit(f,"\tlda\t(%s)\n",mregnames[r]);
	    emit(f,"\tsta\t%s\n",mregnames[r]);
	  }else{
	    int r2=get_reg(f,p,o->dtyp&NQ);
	    emit(f,"\tlda\t[%s]\n",mregnames[r]);
	    emit(f,"\tsta\t%s\n",mregnames[r2]);
	    sety(f,2);
	    emit(f,"\tlda\t[%s],y\n",mregnames[r]);
	    emit(f,"\tsta\t%s+2\n",mregnames[r2]);
	    if(regs[r]&8) regs[r]&=~8;
	    r=r2;
	  }
	}else{
	  o->flags|=DREFOBJ;
	  o->dtyp=dt;
	}
      }
      if(pa){ emit(f,"\tlda\t%s\n",mregnames[t1]); pa=0;}
    }
  }

  if(o->am&&(o->am->base==rax||o->am->base==ra)){
    r=get_reg(f,p,o->am->dt);
    if(o->am->base==ra&&r==rx)
      emit(f,"\ttax\n");
    else
      emit(f,"\tsta\t%s\n",mregnames[r]);
    if(o->am->base==rax)
      emit(f,"\tstx\t%s+2\n",mregnames[r]);
    o->am->base=r;
    return;
  }

  if(((p->code!=ASSIGN&&p->code!=PUSH)||ISSCALAR(p->typf)||zm2l(sizetab[p->typf&NQ])<=4)&&(o->flags&(DREFOBJ|KONST))==DREFOBJ&&(!(o->flags&REG)||!isptr(o->reg))&&((o->flags&(VAR|REG))!=VAR||(!(o->v->tattr&ZPAGE)&&(!ISNPOINTER(o->dtyp)||!ISSTACK(o->v->storage_class))))){
    if(p->code==GETRETURN&&(p->q1.reg==ra||p->q1.reg==rax)){
      emit(f,"\tsta\t%s\n",mregnames[t1]);
      pa=1;
    }else if(p->q1.reg!=ra||!ISNPOINTER(o->dtyp))
      cmp_get_acc(f,p,0);
    r=get_reg(f,p,o->dtyp);
    o->flags&=~DREFOBJ;
    load_reg(f,r,o,o->dtyp);
    o->flags|=REG|DREFOBJ;
    o->reg=r;
    if(pa){ emit(f,"\tlda\t%s\n",mregnames[t1]); pa=0;}
  }
}

static void copy_reg(FILE *f,int s,int d,int t)
{
  if(s==rx)
    emit(f,"\ttxa\n");
  else
    emit(f,"\tlda\t%s\n",mregnames[s]);
  if(d==rx)
    emit(f,"\ttax\n");
  else
    emit(f,"\tsta\t%s\n",mregnames[d]);
  if(!ISNPOINTER(t)){
    emit(f,"\tlda\t%s+2\n",mregnames[s]);
    emit(f,"\tsta\t%s+2\n",mregnames[d]);
  }
}

static void preload(FILE *f,IC *p)
{
  int r,t,mra=regs[ra],mrax=regs[rax];
  int bq1=-1,bq2=-1,bz=-1,sb=-1,c=p->code,bcopy=0;

  if(c==ASSIGN||c==PUSH){
    unsigned long sz=zum2ul(p->q2.val.vmax);
    if(sz>4||(sz==3&&(p->typf2&NU)==(UNSIGNED|CHAR))) bcopy=1;
  }

  if(((p->q1.flags&DREFOBJ)&&p->q1.am&&(p->q1.am->flags==GPR_IND||p->q1.am->flags==ABS_IND)&&p->q1.am->idx==ra)||
     ((p->q2.flags&DREFOBJ)&&p->q2.am&&(p->q2.am->flags==GPR_IND||p->q2.am->flags==ABS_IND)&&p->q2.am->idx==ra)||
     ((p->z.flags&DREFOBJ)&&p->z.am&&(p->z.am->flags==GPR_IND||p->z.am->flags==ABS_IND)&&p->z.am->idx==ra)
     ){
    if(pushedacc>0)
      r=pushedacc;
    else{
      r=get_reg(f,p,INT);
      emit(f,"\tsta\t%s\n",mregnames[r]);
    }
    pushedacc=r;
    if((p->q1.flags&DREFOBJ)&&p->q1.am&&(p->q1.am->flags==GPR_IND||p->q1.am->flags==ABS_IND)&&p->q1.am->idx==ra)
      p->q1.am->idx=r;
    if((p->q2.flags&DREFOBJ)&&p->q2.am&&(p->q2.am->flags==GPR_IND||p->q2.am->flags==ABS_IND)&&p->q2.am->idx==ra)
      p->q2.am->idx=r;
    if((p->z.flags&DREFOBJ)&&p->z.am&&(p->z.am->flags==GPR_IND||p->z.am->flags==ABS_IND)&&p->z.am->idx==ra)
      p->z.am->idx=r;
  }

  if(c==GETRETURN&&p->q1.reg==ra&&!regs[ra])
    regs[ra]=1;

  if(c==GETRETURN&&p->q1.reg==rax&&!regs[rax])
    regs[rax]=1;

  if(isacc(q2)){
    static obj o;
    int t=q2typ(p);
    r=get_reg(f,p,t);
    o.flags=REG;
    o.reg=r;
    store_acc(f,&o,t);
    p->q2.reg=r;
    if(!pushedacc){
      storedacc=r;
    }
  }

  if((c==ADDI2P||c==SUBIFP)&&ISRIDX(q2)){
    static obj o;
    if(p->q2.reg==rx){
      if(pushedx>0) r=pushedx;
      else if(storedx>0) r=storedx;
      else r=get_reg(f,p,INT);
    }else
      r=get_reg(f,p,INT);
    o.flags=REG;
    o.reg=r;
    store_reg(f,p->q2.reg,&o,INT);
    p->q2.reg=r;
    storedx=r;
  }

  if(c!=ADDRESS){
    if(!bcopy||((p->q1.flags&(DREFOBJ|VAR|REG))==(VAR|DREFOBJ)&&ISSTACK(p->q1.v->storage_class)&&real_offset(&p->q1)>255))
      preload_obj(f,p,&p->q1);
    if((p->q1.flags&(DREFOBJ|VAR|REG))==(DREFOBJ|VAR|REG)&&
       (p->q2.flags&(DREFOBJ|VAR|REG))==(DREFOBJ|VAR)&&
       p->q1.v==p->q2.v&&zmeqto(p->q1.val.vmax,p->q2.val.vmax)){
      p->q2.flags|=REG;
      p->q2.reg=p->q1.reg;
    }
    if((p->q1.flags&(DREFOBJ|VAR|REG))==(DREFOBJ|VAR|REG)&&
       (p->z.flags&(DREFOBJ|VAR|REG))==(DREFOBJ|VAR)&&
       p->q1.v==p->z.v&&zmeqto(p->q1.val.vmax,p->z.val.vmax)){
      p->z.flags|=REG;
      p->z.reg=p->q1.reg;
    }
  }

  preload_obj(f,p,&p->q2);
  if((p->q2.flags&(DREFOBJ|VAR|REG))==(DREFOBJ|VAR|REG)&&
     (p->z.flags&(DREFOBJ|VAR|REG))==(DREFOBJ|VAR)&&
     p->q2.v==p->z.v){
    p->z.flags|=REG;
    p->z.reg=p->q2.reg;
  }

  if(!bcopy||((p->z.flags&(DREFOBJ|VAR|REG))==(DREFOBJ|VAR)&&ISSTACK(p->z.v->storage_class)&&real_offset(&p->z)>255))
    preload_obj(f,p,&p->z);


  if(c!=CONVERT&&isreg(z)&&zm2l(sizetab[ztyp(p)&NQ])>2){
    r=0;
    if(p->q1.am&&p->q1.am->base==p->z.reg){
      t=p->q1.am->dt;
      r=get_reg(f,p,t);
      cmp_get_acc(f,p,0);
      copy_reg(f,p->z.reg,r,t);
      p->q1.am->base=p->q1.reg=r;
    }else if(!p->q1.am&&(p->q1.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&p->q1.reg==p->z.reg){
      t=p->q1.dtyp;
      r=get_reg(f,p,t);
      cmp_get_acc(f,p,0);
      copy_reg(f,p->z.reg,r,t);
      p->q1.reg=r;
    }
    if(p->q2.am&&p->q2.am->base==p->z.reg){
      if(r==0){
	t=p->q2.am->dt;
	r=get_reg(f,p,t);
	cmp_get_acc(f,p,0);
	copy_reg(f,p->z.reg,r,t);
      }
      p->q2.am->base=p->q2.reg=r;
    }else if(!p->q2.am&&(p->q2.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&p->q2.reg==p->z.reg){
      if(r==0){
	t=p->q2.dtyp;
	r=get_reg(f,p,t);
	cmp_get_acc(f,p,0);
	copy_reg(f,p->z.reg,r,t);
      }
      p->q2.reg=r;
    }
  }
  if(isacc(z)){
    if(isacc(q2)){
      if(p->q2.reg==rax){
	ierror(0);
	r=get_reg(f,p,INT);
	if(!reg_pair(r,&rp)) ierror(0);
	emit(f,"\tsta\t%s\n",mregnames[rp.r1]);
	emit(f,"\tstx\t%s\n",mregnames[rp.r2]);
	storedacc=rp.r1;
	storedx=rp.r2;
      }else{
	r=get_reg(f,p,INT);
	emit(f,"\tsta\t%s\n",mregnames[r]);
	storedacc=r;
      }
      p->q2.reg=r;
      if(isacc(q1))
	p->q1.reg=r;
    }
  }
 
  reload_acc(f);

  regs[ra]=mra;
  regs[rax]=mrax;
}


/* compare if two objects are the same */
static int compare_objects(struct obj *o1,struct obj *o2)
{
  if((o1->flags&(REG|DREFOBJ))==REG&&(o2->flags&(REG|DREFOBJ))==REG&&o1->reg==o2->reg)
    return 1;
  if(o1->flags==o2->flags){
    if(o1->am){
      if(o2->am){
	if(o1->am->flags!=o2->am->flags||o1->am->base!=o2->am->base||
	   o1->am->idx!=o2->am->idx||o1->am->offset!=o2->am->offset)
	  return 0;
	else
	  return 1;
      }else
	return 0;
    }else if(o2->am)
      return 0;
    if(!(o1->flags&VAR)||(o1->v==o2->v&&zmeqto(o1->val.vmax,o2->val.vmax))){
      if(!(o1->flags&REG)||o1->reg==o2->reg){
        return 1;
      }
    }
  }
  return 0;
}

/* save the result (in zreg) into p->z */
void save_result(FILE *f,struct IC *p)
{
  ierror(0);
}

/* prints an object */
static void emit_obj(FILE *f,struct obj *p,int t)
{
  if(p->am){
    if(p->am->flags==IMM_IND){
      if(p->am->base==rx)
	emit(f,"!%ld,%s",p->am->offset,mregnames[p->am->base]);
      else{
	if(!ISNPOINTER(p->am->dt))
	  emit(f,"[%s],y ;am(%ld)",mregnames[p->am->base],p->am->offset);
	else
	  emit(f,"(%s),y ;am(%ld)",mregnames[p->am->base],p->am->offset);
      }
    }else if(p->am->flags==GPR_IND){
      if(!ISNPOINTER(p->am->dt))
	emit(f,"[%s],y ;am(%s)",mregnames[p->am->base],mregnames[p->am->idx]);
      else
	emit(f,"(%s),y ;am(%s)",mregnames[p->am->base],mregnames[p->am->idx]);
    }else if(p->am->flags==ABS_IND){
      /*if(ISIDX(p->am->idx)) emit(f,"!");*/
      if(!ISNPOINTER(p->am->dt)) emit(f,">"); else emit(f,"!");
      emit(f,"%ld",p->am->offset);
      if(p->am->v){
	Var *v=p->am->v;
	if(v->storage_class==EXTERN)
	  emit(f,"+%s%s",idprefix,v->identifier);
	else
	  emit(f,"+%s%ld",labprefix,zm2l(v->offset));
      }
      if(ISIDX(p->am->idx))
	emit(f,",%s ;am(%s)",mregnames[p->am->idx],mregnames[p->am->idx]);
      else if(ISNPOINTER(p->am->dt))
	emit(f,",y ;am(%s)",mregnames[p->am->idx]);
      else
	emit(f,",x ;am(%s)",mregnames[p->am->idx]);
    }else
      ierror(0);
    return;
  }
  if((p->flags&(KONST|DREFOBJ))==(KONST|DREFOBJ)){
    if(!ISNPOINTER(p->dtyp)) emit(f,">");
    emitval(f,&p->val,p->dtyp&NU);
    return;
  }
  if((p->flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&p->reg==rx){
    emit(f,"!%ld,x",zm2l(p->val.vmax));
    return;
  }
  if(p->flags&DREFOBJ) emit(f,ISNPOINTER(p->dtyp)?"(":"[");
  if(p->flags&REG){
    emit(f,"%s",mregnames[p->reg]);
  }else if(p->flags&VAR) {
    if(ISSTACK(p->v->storage_class)){
      if(fp==sp)
	emit(f,"%ld,s",(long)real_offset(p));
      else{
	if(large||huge)
	  emit(f,"[%s],y",mregnames[fp]);
	else
	  emit(f,"(%s),y",mregnames[fp]);
      }
    }else{
      if(!(p->flags&VARADR)&&pointer_varadr(p->v,1)!=POINTER&&!nomod) emit(f,">");
      if(!zmeqto(l2zm(0L),p->val.vmax)){emitval(f,&p->val,MAXINT);emit(f,"+");}
      if(p->v->storage_class==STATIC){
        emit(f,"%s%ld",labprefix,zm2l(p->v->offset));
      }else{
        emit(f,"%s%s",idprefix,p->v->identifier);
      }
    }
  }
  if(p->flags&KONST){
    if(/*ieee&&((t&NQ)==DOUBLE||(t&NQ)==LDOUBLE)*/ISFLOAT(t))
      emit(f,"%s%d",labprefix,addfpconst(p,t));
    else
      emitval(f,&p->val,t&NU);
  }
  if(p->flags&DREFOBJ) emit(f,"%c%s",ISNPOINTER(p->dtyp)?')':']',noy==0?",y":(noy==1?"":",z"));
}

/*  Test if there is a sequence of FREEREGs containing FREEREG reg.
    Used by peephole. */
static int exists_freereg(struct IC *p,int reg)
{
  while(p&&(p->code==FREEREG||p->code==ALLOCREG)){
    if(p->code==FREEREG&&p->q1.reg==reg) return 1;
    p=p->next;
  }
  return 0;
}

/* search for possible addressing-modes */
static void peephole(struct IC *p)
{
  int c,c2,r;struct IC *p2,*free_base,*use;struct AddressingMode *am;

  for(;p;p=p->next){
    c=p->code;
    if(c!=FREEREG&&c!=ALLOCREG&&(c!=SETRETURN||!isreg(q1)||p->q1.reg!=p->z.reg)) exit_label=0;
    if(c==LABEL) exit_label=p->typf;

    /* Try const(reg) */
    if((c==ADDI2P||c==SUBIFP)&&isreg(z)&&(p->q2.flags&(KONST|DREFOBJ))==KONST){
      int base;zmax of;struct obj *o;IC *dub=0;
      eval_const(&p->q2.val,p->typf);
      if(c==SUBIFP) of=zmsub(l2zm(0L),vmax); else of=vmax;
      if(zmleq(Z0,of)&&zmleq(of,l2zm(65535L))){
	r=p->z.reg;
	if(isreg(q1)&&isptr(p->q1.reg)) base=p->q1.reg; else base=r;
	o=0;free_base=0;
	for(p2=p->next;p2;p2=p2->next){
	  c2=p2->code;
	  if(c2==CALL||c2==LABEL||(c2>=BEQ&&c2<=BRA)) break;
	  if(c2==FREEREG&&p2->q1.reg==p->z.reg) free_base=p2;
	  if(c2!=FREEREG&&(p2->q1.flags&(REG|DREFOBJ))==REG&&p2->q1.reg==r) break;
	  if(c2!=FREEREG&&(p2->q2.flags&(REG|DREFOBJ))==REG&&p2->q2.reg==r) break;
	  if(c2!=CALL&&(c2<LABEL||c2>BRA)/*&&c2!=ADDRESS*/){
	    int t,mc;
	    if((c2==ASSIGN|c2==PUSH)&&(p2->typf&NQ)==CHAR&&!zmeqto(p2->q2.val.vmax,Z1))
	      mc=1;
	    else
	      mc=0;
	    if(!o&&(c2==ADD||c2==SUB||c2==AND||c2==OR||c2==XOR)&&/*(p2->typf&NQ)==CHAR&&*/!p2->q1.am&&!p2->z.am&&
	       (p2->q1.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&
	       p2->q1.flags==p2->z.flags&&p2->q1.reg==r&&p2->z.reg==r){
	      o=&p2->q1;use=p2;
	      dub=p2;
	      continue;
	    }
	    if(!p2->q1.am&&(p2->q1.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&p2->q1.reg==r){
	      if(o||mc) break;
	      t=q1typ(p2)&NQ;
	      if(t>POINTER||ISFLOAT(t)) break;
	      if(m65&&ISLONG(t)) break;
	      o=&p2->q1;use=p2;
	    }
	    if(!p2->q2.am&&(p2->q2.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&p2->q2.reg==r){
	      if(o||mc) break;
	      t=q2typ(p2)&NQ;
	      if(t>POINTER||ISFLOAT(t)) break;
	      if(m65&&ISLONG(t)) break;
	      o=&p2->q2;use=p2;
	    }
	    if(!p2->z.am&&(p2->z.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&p2->z.reg==r){
	      if(o||mc) break;
	      t=ztyp(p2)&NQ;
	      if(t>POINTER||ISFLOAT(t)) break;
	      if(m65&&ISLONG(t)) break;
	      o=&p2->z;use=p2;
	    }
	  }
	  if(c2==FREEREG||(p2->z.flags&(REG|DREFOBJ))==REG){
	    int m;
	    if(c2==FREEREG)
	      m=p2->q1.reg;
	    else{
	      m=p2->z.reg;
	      if(o==&p->q1||o==&p->q2) break;
	    }
	    if(m==r){
	      if(o){
		o->am=am=mymalloc(sizeof(*am));
		am->flags=IMM_IND;
		am->base=base;
		am->offset=(int)zm2l(of);
		am->dt=o->dtyp;
		if(ISPREG(q1)){
		  p->code=c=NOP;p->q1.flags=p->q2.flags=p->z.flags=0;
		}else{
		  p->code=c=ASSIGN;p->q2.flags=0;
		  p->typf=p->typf2;p->q2.val.vmax=sizetab[p->typf2&NQ];
		}
	      }
	      if(dub){
		dub->z=*o;
		dub->z.am=mymalloc(sizeof(*am));
		*dub->z.am=*o->am;
	      }
	      if(free_base) move_IC(use,free_base);
	      break;
	    }
	    if(c2!=FREEREG&&m==base) break;
	    continue;
	  }
        }
      }
    }
    /* Try reg,reg */
    if(c==ADDI2P&&((p->typf&NQ)==INT||(p->typf&NQ)==SHORT)&&((!ISHPOINTER(p->typf2)&&(p->q1.flags&VARADR))||(p->typf&UNSIGNED))&&isreg(q2)/*&&p->q2.reg!=ra*/&&ISPREG(z)&&(ISPREG(q1)||p->q2.reg!=p->z.reg)){
      int base,idx,ind;struct obj *o;IC *free_idx,*dub=0;
      r=p->z.reg;idx=p->q2.reg;
      if(ISPREG(q1)) base=p->q1.reg; else base=r;
      if((p->q1.flags&VARADR)||(p->q1.flags&(KONST|DREFOBJ))==KONST){
	/*if(!ISNPOINTER(p->typf)) continue;*/
	ind=0;
      }else
	ind=1;
      o=0;free_base=free_idx=use=0;
      for(p2=p->next;p2;p2=p2->next){
        c2=p2->code;
        if(c2==CALL||c2==LABEL||(c2>=BEQ&&c2<=BRA)) break;
	if(c2==FREEREG&&p2->q1.reg==p->z.reg) free_base=p2;
	if(c2==FREEREG&&p2->q1.reg==p->q2.reg) free_idx=p2;
        if(c2!=FREEREG&&(p2->q1.flags&(REG|DREFOBJ))==REG&&p2->q1.reg==r) break;
        if(c2!=FREEREG&&(p2->q2.flags&(REG|DREFOBJ))==REG&&p2->q2.reg==r) break;
        if((p2->z.flags&(REG|DREFOBJ))==REG&&idx!=r){
	  if(p2->z.reg==idx) break;
	  if(reg_pair(p2->z.reg,&rp)){
	    if(rp.r1==idx) break;
	    if(rp.r2==idx) break;
	  }
	}

        if(c2!=CALL&&(c2<LABEL||c2>BRA)/*&&c2!=ADDRESS*/){
	  if(!o&&(c2==ADD||c2==SUB||c2==AND||c2==OR||c2==XOR)&&/*(p2->typf&NQ)==CHAR&&*/!p2->q1.am&&!p2->z.am&&
	     (p2->q1.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&
	     p2->q1.flags==p2->z.flags&&p2->q1.reg==r&&p2->z.reg==r){
	    o=&p2->q1;use=p2;
	    dub=p2;
	    continue;
	  }
          if(!p2->q1.am&&(p2->q1.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&p2->q1.reg==r){
            if(o||base==rx||(ind&&(q1typ(p2)&NQ)>INT)) break;
	    if(ieee&&ISFLOAT(q1typ(p2))) break;
            o=&p2->q1;use=p2;
          }
          if(!p2->q2.am&&(p2->q2.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&p2->q2.reg==r){
            if(o||base==rx||(ind&&(q2typ(p2)&NQ)>INT)) break;
	    if(ieee&&ISFLOAT(q2typ(p2))) break;
            o=&p2->q2;use=p2;
          }
          if(!p2->z.am&&(p2->z.flags&(REG|DREFOBJ))==(REG|DREFOBJ)&&p2->z.reg==r){
            if(o||base==rx||(ind&&(ztyp(p2)&NQ)>INT)) break;
	    if(ieee&&ISFLOAT(ztyp(p2))) break;
            o=&p2->z;use=p2;
          }
        }
	
        if(c2==FREEREG||(p2->z.flags&(REG|DREFOBJ))==REG){
          int m;
          if(c2==FREEREG)
            m=p2->q1.reg;
          else
            m=p2->z.reg;
          if(m==r){
            if(o){
              o->am=am=mymalloc(sizeof(*am));
	      am->idx=idx;
	      am->dt=o->dtyp;
	      if(ind){
		am->flags=GPR_IND;
		am->base=base;
		if(ISPREG(q1)){
		  p->code=c=NOP;p->q1.flags=p->q2.flags=p->z.flags=0;
		}else{
		  p->code=c=ASSIGN;p->q2.flags=0;
		  p->typf=p->typf2;p->q2.val.vmax=sizetab[p->typf2&NQ];
		}
	      }else{
		am->flags=ABS_IND;
		am->base=0;
		eval_const(&p->q1.val,MAXINT);
		am->offset=zm2l(vmax);
		if(p->q1.flags&VARADR)
		  am->v=p->q1.v;
		else
		  am->v=0;
		p->code=c=NOP;p->q1.flags=p->q2.flags=p->z.flags=0;
	      }
	      if(dub){
		dub->z=*o;
		dub->z.am=mymalloc(sizeof(*am));
		*dub->z.am=*o->am;
	      }
	      if(free_idx) move_IC(use,free_idx);
	      if(free_base) move_IC(use,free_base);
            }
            break;
          }
          if(c2!=FREEREG&&m==base) break;
          continue;
        }
      }
    }
  }
}

static int fattr(type *p,char *s)
{
  if(p->attr&&strstr(p->attr,s))
    return 1;
  if(p->next)
    return fattr(p->next,s);
  else
    return 0;
}

static void pr(FILE *f,struct IC *p)
{
  int r;

  WMODE();

  for(r=1;r<=MAXR;r++){
    if(regs[r]&8)
      regs[r]&=~8;
  }
  for(r=FIRST_GPR;r<=LAST_GPR;r++){
    int ta=0;
    if(regs[r]&2){
      if(regs[ra]&&!pushedacc){
	emit(f,"\ttay\n");
	yval=NOVAL;
	ta=1;
      }
      emit(f,"\tpla\n");pop(2);
      emit(f,"\tsta\t%s\n",mregnames[r]);
      regs[r]&=~2;
    }
    if(ta)
      emit(f,"\ttya\n");
  }
  if(pushedx){
    emit(f,"\tldx\t%s\n",mregnames[pushedx]);
    pushedx=0;
  }

  reload_acc_opt(f,p->next);

  storedacc=0;
  storedx=0;
}

struct cmplist {struct cmplist *next;int from,to,mode;} *first_cmplist;

static void add_cmplist(int from, int to, int mode)
{
  struct cmplist *new;
  new=mymalloc(sizeof(*new));
  new->next=first_cmplist;
  new->from=from;
  new->to=to;
  new->mode=mode;
  first_cmplist=new;
}

static void incsp(FILE *f,long of,IC *p)
{
  static IC dummy;
  if(of==0) return;
  if(of==-2){emit(f,"\tphy\n");return;}
  else if(of==-4){emit(f,"\tphy\n\tphy\n");return;}
  else if(of==-6){emit(f,"\tphy\n\tphy\n\tphy\n");return;}
  else if(of==-8){emit(f,"\tphy\n\tphy\n\tphy\n\tphy\n");return;}
  else if(of==2){emit(f,"\tply\n");yval=NOVAL;return;}
  else if(of==4){emit(f,"\tply\n\tply\n");yval=NOVAL;return;}
  else if(of==6){emit(f,"\tply\n\tply\n\tply\n");yval=NOVAL;return;}
  else if(of==8){emit(f,"\tply\n\tply\n\tply\n\tply\n");yval=NOVAL;return;}
  get_acc(f,p==0?&dummy:p,CHAR);
  emit(f,"\ttsc\n");
  if(of==1) emit(f,"\tinc\n");
  else if(of==-1) emit(f,"\tdec\n");
  else emit(f,"\tclc\n\tadc\t#%ld\n",of);
  emit(f,"\ttcs\n");
}

/* generates the function entry code */
static void function_top(FILE *f,struct Var *v,long offset)
{
  int i,of,storeda=0;
  rsavesize=0;
  hasretval=0;

  if(!optsize||(v->tattr&NOCOMPRESS)) emit(f,";vcprmin=10000\n");
  for(i=FIRST_GPR;i<=LAST_GPR;i++){
    if((regused[i]&&(in_isr||!regscratch[i]))||(in_isr&&function_calls&&regscratch[i]&&!regsa[i])||i==fp1||i==fp2){
      rsavesize+=2;
    }
  }
  rscnt=rsavesize;

  set_section(f,v);

  emit(f,"\ta16\n\tx16\n");
  if(v->storage_class==EXTERN){
    if((v->flags&(INLINEFUNC|INLINEEXT))!=INLINEFUNC)
      emit(f,"\tglobal\t%s%s\n",idprefix,v->identifier);
    emit(f,"%s%s:\n",idprefix,v->identifier);
  }else
    emit(f,"%s%ld:\n",labprefix,zm2l(v->offset));

  offset=localsize;

  if(in_isr){
    emit(f,"\tphp\n");
    emit(f,"\trep\t#48\n");
    emit(f,"\tpha\n");
    emit(f,"\tphx\n");
    emit(f,"\tphy\n");
    emit(f,"\tpei\t(%s)\n",mregnames[t1]);
    emit(f,"\tpei\t(%s)\n",mregnames[t2]);
    emit(f,"\tpei\t(%s)\n",mregnames[t3]);
    emit(f,"\tpei\t(%s)\n",mregnames[t4]);
  }

  if(MAINARGS&&v->storage_class==EXTERN&&!strcmp(v->identifier,"main")&&v->vtyp->exact->count>1)
    emit(f,"\t%s\tinitmainargs\n",jsr);

  yval=NOVAL;
  of=localsize;

  for(i=FIRST_GPR;i<=LAST_GPR;i++){
    if((regused[i]&&(in_isr||!regscratch[i]))||(in_isr&&function_calls&&regscratch[i]&&!regsa[i])||i==fp1||i==fp2){
      emit(f,"\tpei\t(%s)\n",mregnames[i]);
    }
  }

  if((vlas||offset>8)&&aparm){
    emit(f,"\tsta\t%s\n",mregnames[t1]);
    storeda=1;
  }
  incsp(f,-offset,0);

  if(vlas){
    emit(f,"\ttsc\n");
    emit(f,"\tsta\t%s\n",mregnames[fp]);
    emit(f,"\tstz\t%s+2\n",mregnames[fp]);
  }

  if(storeda)
    emit(f,"\tlda\t%s\n",mregnames[t1]);
}

/* generates the function exit code */
static void function_bottom(FILE *f,struct Var *v,long offset)
{
  int i,of,ar;
  struct cmplist *p;

  i=freturn(v->vtyp->next);
  if(hasretval&&(i==ra||i==rax)) ar=i; else ar=0;

  offset=localsize;
  of=localsize+((fp==sp)?notpopped:0);
  if(ar&&of!=0&&of!=2&&of!=4&&of!=6&&of!=8&&!pushedacc){
    pushedacc=ry;
    emit(f,"\ttay\n");
  }
  incsp(f,of,0);
  of=offset=notpopped=0;

  if(ar==rax&&!pushedacc&&rscnt>0){
    pushedacc=ry;
    emit(f,"\ttay\n");
  }
  for(i=LAST_GPR;i>=FIRST_GPR;i--){
    if((regused[i]&&(in_isr||!regscratch[i]))||(in_isr&&function_calls&&regscratch[i]&&!regsa[i])||i==fp1||i==fp2){
      emit(f,"\tpl%c\n",ar==rax?'a':'x');
      emit(f,"\tst%c\t%s\n",ar==rax?'a':'x',mregnames[i]);
    }
  }

#if 0
  if(rsavesize>0){
    if(ar==rax&&!pushedacc){
      pushedacc=ry;
      emit(f,"\ttay\n");
    }
  }
#endif

  reload_acc(f);

  if(in_isr){
    emit(f,"\tpla\n\tsta\t%s\n",mregnames[t4]);
    emit(f,"\tpla\n\tsta\t%s\n",mregnames[t3]);
    emit(f,"\tpla\n\tsta\t%s\n",mregnames[t2]);
    emit(f,"\tpla\n\tsta\t%s\n",mregnames[t1]);
    emit(f,"\tply\n");
    emit(f,"\tplx\n");
    emit(f,"\tpla\n");
    emit(f,"\tplp\n");
  }
  emit(f,ret);

  for(p=first_cmplist;p;){
    struct cmplist *m;
    emit(f,"%s%d:\n",labprefix,p->from);
    if(p->mode==JMPIND){
      /* indirect call */
      emit(f,"\tjmp\t[%s]\n",mregnames[p->to]);
    }else{
      pushedacc=p->mode;
      reload_acc(f);
      emit(f,"\t%s\t%s%d\n",jmpinst,labprefix,p->to);
    }
    m=p;
    p=p->next;
    free(m);
  }
  first_cmplist=0;
  pushedacc=0;
}

/****************************************/
/*  End of private data and functions.  */
/****************************************/

/*  Does necessary initializations for the code-generator. Gets called  */
/*  once at the beginning and should return 0 in case of problems.      */
int init_cg(void)
{
  int i;
  /*  Initialize some values which cannot be statically initialized   */
  /*  because they are stored in the target's arithmetic.             */
  maxalign=l2zm(1L);
  char_bit=l2zm(8L);
  stackalign=l2zm(2L);

  if(IEEE){
    ieee=1;
    msizetab[DOUBLE]=msizetab[LDOUBLE]=l2zm(8L);
  }

  if(MSFP4){
    ms4=1;
    marray[13]="__MSFP4__";
  }

  if(HUGE) {huge=1;have_int_sizet_65816=0;}
  else if(!TINY) large=1;
  if(PTR24) ptr24=1;

  if(NEARTHR) near_threshold=g_flags_val[25].l;

  if(SNESMULDIV) snesmuldiv=1;

  mregnames[0]=regnames[0]="noreg";
  mregnames[REGDUMMY1]=mymalloc(MAXI+8);
  mregnames[REGDUMMY2]=mymalloc(MAXI+8);
  mregnames[REGDUMMY3]=mymalloc(MAXI+8);

  for(i=FIRST_GPR;i<=LAST_GPR;i++){
    regnames[i]=mymalloc(10);
    sprintf(regnames[i],"r%d",i-FIRST_GPR);
    mregnames[i]=regnames[i];
    regsize[i]=l2zm(2L);
    regtype[i]=&ityp;
  }
  for(i=FIRST_PAIR;i<=LAST_PAIR;i++){
    int sr=(i-FIRST_PAIR)*2+FIRST_GPR;
    regnames[i]=mymalloc(10);
    sprintf(regnames[i],"%s/%s",mregnames[sr],mregnames[sr+1]);
    mregnames[i]=regnames[sr];
    regsize[i]=l2zm(4L);
    regtype[i]=&ftyp;
  }
  for(i=FIRST_BIG;i<=LAST_BIG;i++){
    regnames[i]=mymalloc(10);
    sprintf(regnames[i],"btmp%d",i-FIRST_BIG);
    mregnames[i]=regnames[i];
    regsize[i]=msizetab[FLOAT];
    regtype[i]=&ftyp;
    regsa[i]=0;
    regscratch[i]=1;
  }
  for(i=FIRST_BIGP;i<=LAST_BIGP;i++){
    int sr=(i-FIRST_BIGP)*2+FIRST_BIG;
    regnames[i]=mymalloc(20);
    sprintf(regnames[i],"%s/%s",mregnames[sr],mregnames[sr+1]);
    mregnames[i]=regnames[sr];
    regsize[i]=msizetab[LLONG];
    regtype[i]=&lltyp;
    regsa[i]=0;
    regscratch[i]=1;
  }

  mregnames[ra] = regnames[ra] = "a";
  mregnames[rx] = regnames[rx] = "x";
  mregnames[ry] = regnames[ry] = "y";
  regsize[ra]=regsize[rx]=regsize[ry]=l2zm(2L);
  regtype[ra]=regtype[rx]=regtype[ry]=&ityp;
  mregnames[sp]=regnames[sp] = "s";
  mregnames[sp1]=regnames[sp1] = "s";
  mregnames[sp2]=regnames[sp2] = "s";

  mregnames[rax]=regnames[rax] = "a/x";
  regsize[rax]=l2zm(4L);
  regtype[rax]=&ftyp;
  regsize[sp]=l2zm(2l);
  regtype[sp]=&ityp;

  reg_prio[ra]=reg_prio[rax]=100;
  reg_prio[rx]=50;

  /*  Use multiple ccs.   */
  multiple_ccs=0;

  short_push=0;

  static_cse=0;

  dref_cse=1;

  /*prefer_statics=1; TODO */


  if(optsize){
    clist_copy_stack=2;
    clist_copy_pointer=2;
    clist_copy_static=2;
  }else if(optspeed){
    clist_copy_stack=64;
    clist_copy_pointer=64;
    clist_copy_static=64;
  }else{
    clist_copy_stack=8;
    clist_copy_pointer=8;
    clist_copy_static=8;
  }

  /*  Initialize the min/max-settings. Note that the types of the     */
  /*  host system may be different from the target system and you may */
  /*  only use the smallest maximum values ANSI guarantees if you     */
  /*  want to be portable.                                            */
  /*  That's the reason for the subtraction in t_min[INT]. Long could */
  /*  be unable to represent -2147483648 on the host system.          */
  t_min[CHAR]=l2zm(-128L);
  t_min[SHORT]=l2zm(-32768L);
  t_min[LONG]=zmsub(l2zm(-2147483647L),l2zm(1L));
  t_min[INT]=t_min(SHORT);
  t_min[LLONG]=zmlshift(l2zm(1L),l2zm(63L));
  t_min[MAXINT]=t_min(LLONG);
  t_max[CHAR]=ul2zum(127L);
  t_max[SHORT]=ul2zum(32767UL);
  t_max[LONG]=ul2zum(2147483647UL);
  t_max[INT]=t_max(SHORT);
  t_max[LLONG]=zumrshift(zumkompl(ul2zum(0UL)),ul2zum(1UL));
  t_max[MAXINT]=t_max(LLONG);
  tu_max[CHAR]=ul2zum(255UL);
  tu_max[SHORT]=ul2zum(65535UL);
  tu_max[LONG]=ul2zum(4294967295UL);
  tu_max[INT]=t_max(UNSIGNED|SHORT);
  tu_max[LLONG]=zumkompl(ul2zum(0UL));
  tu_max[MAXINT]=t_max(UNSIGNED|LLONG);
  
  /*  Reserve a few registers for use by the code-generator.      */
  /*  This is not optimal but simple.                             */
  regsa[ry]=regsa[sp]=regsa[sp1]=regsa[sp2]=REGSA_NEVER;
  regsa[t1]=regsa[t2]=regsa[t3]=regsa[t4]=REGSA_NEVER;
  regsa[t1t2]=regsa[t3t4]=REGSA_NEVER;
  regscratch[ra]=regscratch[rx]=regscratch[rax]=1;
  if(!GLOBACC)
    regsa[ra]=regsa[rx]=regsa[rax]=REGSA_TEMPS;
  regsa[rx]=0;
  regscratch[sp]=regscratch[sp1]=regscratch[sp2]=regscratch[ry]=0;
  regscratch[t1]=regscratch[t2]=regscratch[t3]=regscratch[t4]=1;
  regscratch[t1t2]=regscratch[t3t4]=1;

  for(i=FIRST_GPR;i<=LAST_GPR-VOL_GPRS;i++){
    regscratch[i]=1;
    if(i&1)
      regscratch[FIRST_PAIR+(i-FIRST_GPR)/2]=1;
  }

  if(large) marray[3]="__MLARGE=1";
  else if(huge){marray[3]="__MHUGE=1";marray[2]="__SIZE_T_LONG=1";}
  else marray[3]="__MNEAR=1";
  if(ptr24) marray[4]="__PTR24=1";

  target_macros=marray;

#if 0
  /* TODO: what ABI do we want for 65816 */
#define BFIRST_GPR (c816?0:FIRST_GPR)
#define BFIRST_GPR1 (c816?0:FIRST_GPR+1)
#define BFIRST_PAIR (c816?0:FIRST_PAIR)
#define BFIRST_PAIR1 (c816?0:FIRST_PAIR+1)
#define BFIRST_BIG (c816?0:FIRST_BIG)
#define BFIRST_BIG1 (c816?0:FIRST_BIG+1)
#define BFIRST_BIG2 (c816?0:FIRST_BIG+2)
#define BFIRST_BIGP (c816?0:FIRST_BIGP)
#else
#define BFIRST_GPR (FIRST_GPR)
#define BFIRST_GPR1 (FIRST_GPR+1)
#define BFIRST_PAIR (FIRST_PAIR)
#define BFIRST_PAIR1 (FIRST_PAIR+1)
#define BFIRST_BIG (FIRST_BIG)
#define BFIRST_BIG1 (FIRST_BIG+1)
#define BFIRST_BIG2 (FIRST_BIG+2)
#define BFIRST_BIGP (FIRST_BIGP)
#endif

  declare_builtin("__mulint8",CHAR,CHAR,BFIRST_GPR,CHAR,BFIRST_GPR1,1,0);
  declare_builtin("__mulint8snes",CHAR,CHAR,ra,CHAR,BFIRST_GPR,1,0);
  declare_builtin("__mulint16",INT,INT,BFIRST_GPR,INT,BFIRST_GPR1,1,0);
  declare_builtin("__mulint16snes",INT,INT,BFIRST_GPR,INT,BFIRST_GPR1,1,0);
  declare_builtin("__muluint16",UNSIGNED|INT,UNSIGNED|INT,BFIRST_GPR,UNSIGNED|INT,BFIRST_GPR1,1,0);
  declare_builtin("__divuint16",UNSIGNED|INT,UNSIGNED|INT,BFIRST_GPR,UNSIGNED|INT,BFIRST_GPR1,1,0);
  declare_builtin("__divuint16snes",UNSIGNED|INT,UNSIGNED|INT,BFIRST_GPR,UNSIGNED|INT,BFIRST_GPR1,1,0);
  declare_builtin("__divint16",INT,INT,BFIRST_GPR,INT,BFIRST_GPR1,1,0);
  declare_builtin("__divint16snes",INT,INT,BFIRST_GPR,INT,BFIRST_GPR1,1,0);
  declare_builtin("__modint16",INT,INT,BFIRST_GPR,INT,BFIRST_GPR1,1,0);
  declare_builtin("__modint16snes",INT,INT,BFIRST_GPR,INT,BFIRST_GPR1,1,0);
  declare_builtin("__moduint16",UNSIGNED|INT,UNSIGNED|INT,BFIRST_GPR,UNSIGNED|INT,BFIRST_GPR1,1,0);
  declare_builtin("__moduint16snes",UNSIGNED|INT,UNSIGNED|INT,BFIRST_GPR,UNSIGNED|INT,BFIRST_GPR1,1,0);
  declare_builtin("__modint16wo",INT,INT,BFIRST_GPR,INT,BFIRST_GPR1,1,0);
  declare_builtin("__divuint16wo",UNSIGNED|INT,UNSIGNED|INT,BFIRST_GPR,UNSIGNED|INT,BFIRST_GPR1,1,0);
  declare_builtin("__divint16wo",INT,INT,BFIRST_GPR,INT,BFIRST_GPR1,1,0);
  declare_builtin("__moduint16wo",UNSIGNED|INT,UNSIGNED|INT,BFIRST_GPR,UNSIGNED|INT,BFIRST_GPR1,1,0);
  declare_builtin("__modint16wo",INT,INT,BFIRST_GPR,INT,BFIRST_GPR1,1,0);

  declare_builtin("__mulint32",LONG,LONG,BFIRST_PAIR1,LONG,BFIRST_PAIR+2,1,0);
  declare_builtin("__mulint32snes",LONG,LONG,BFIRST_PAIR+3,LONG,BFIRST_PAIR+2,1,0);
  declare_builtin("__muluint32",UNSIGNED|LONG,UNSIGNED|LONG,BFIRST_PAIR1,UNSIGNED|LONG,BFIRST_PAIR+2,1,0);
  declare_builtin("__divint32",LONG,LONG,BFIRST_PAIR,LONG,BFIRST_PAIR1,1,0);
  declare_builtin("__divuint32",UNSIGNED|LONG,UNSIGNED|LONG,BFIRST_PAIR,UNSIGNED|LONG,BFIRST_PAIR1,1,0);
  declare_builtin("__modint32",LONG,LONG,BFIRST_PAIR,LONG,BFIRST_PAIR1,1,0);
  declare_builtin("__moduint32",UNSIGNED|LONG,UNSIGNED|LONG,BFIRST_PAIR,UNSIGNED|LONG,BFIRST_PAIR1,1,0);
  declare_builtin("__divint32wo",LONG,LONG,BFIRST_PAIR,LONG,BFIRST_PAIR1,1,0);
  declare_builtin("__divuint32wo",UNSIGNED|LONG,UNSIGNED|LONG,BFIRST_PAIR,UNSIGNED|LONG,BFIRST_PAIR1,1,0);
  declare_builtin("__modint32wo",LONG,LONG,BFIRST_PAIR,LONG,BFIRST_PAIR1,1,0);
  declare_builtin("__moduint32wo",UNSIGNED|LONG,UNSIGNED|LONG,BFIRST_PAIR,UNSIGNED|LONG,BFIRST_PAIR1,1,0);



  declare_builtin("__mulint64",LLONG,LLONG,0,LLONG,0,1,0);
  declare_builtin("__addint64",LLONG,LLONG,0,LLONG,0,1,0);
  declare_builtin("__subint64",LLONG,LLONG,0,LLONG,0,1,0);
  declare_builtin("__andint64",LLONG,LLONG,0,LLONG,0,1,0);
  declare_builtin("__orint64",LLONG,LLONG,0,LLONG,0,1,0);
  declare_builtin("__eorint64",LLONG,LLONG,0,LLONG,0,1,0);
  declare_builtin("__negint64",LLONG,LLONG,0,0,0,1,0);
  declare_builtin("__lslint64",LLONG,LLONG,0,INT,0,1,0);

  declare_builtin("__divint64",LLONG,LLONG,0,LLONG,0,1,0);
  declare_builtin("__divuint64",UNSIGNED|LLONG,UNSIGNED|LLONG,0,UNSIGNED|LLONG,0,1,0);
  declare_builtin("__modint64",LLONG,LLONG,0,LLONG,0,1,0);
  declare_builtin("__moduint64",UNSIGNED|LLONG,UNSIGNED|LLONG,0,UNSIGNED|LLONG,0,1,0);
  declare_builtin("__lsrint64",LLONG,LLONG,0,INT,0,1,0);
  declare_builtin("__lsruint64",UNSIGNED|LLONG,UNSIGNED|LLONG,0,INT,0,1,0);
  declare_builtin("__cmpsint64",INT,LLONG,0,LLONG,0,1,0);
  declare_builtin("__cmpuint64",INT,UNSIGNED|LLONG,0,UNSIGNED|LLONG,0,1,0);

  declare_builtin("__sint32toflt32",FLOAT,LONG,OLDFP?0:(ms4?rax:BFIRST_PAIR),0,0,1,0);
  declare_builtin("__uint32toflt32",FLOAT,UNSIGNED|LONG,OLDFP?0:(ms4?rax:BFIRST_PAIR),0,0,1,0);
  declare_builtin("__flt32tosint32",LONG,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR),0,0,1,0);
  declare_builtin("__flt32touint32",UNSIGNED|LONG,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR),0,0,1,0);
  declare_builtin("__sint16toflt32",FLOAT,INT,ms4?ra:BFIRST_GPR,0,0,1,0);
  declare_builtin("__uint16toflt32",FLOAT,UNSIGNED|INT,ms4?ra:BFIRST_GPR,0,0,1,0);
  declare_builtin("__flt32tosint16",INT,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR),0,0,1,0);
  declare_builtin("__flt32touint16",UNSIGNED|INT,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR),0,0,1,0);

  declare_builtin("__sint32toflt64",DOUBLE,LONG,OLDFP?0:BFIRST_PAIR,0,0,1,0);
  declare_builtin("__uint32toflt64",DOUBLE,UNSIGNED|LONG,OLDFP?0:BFIRST_PAIR,0,0,1,0);
  declare_builtin("__flt64tosint32",LONG,DOUBLE,OLDFP?0:BFIRST_BIGP,0,0,1,0);
  declare_builtin("__flt64touint32",UNSIGNED|LONG,DOUBLE,OLDFP?0:BFIRST_BIGP,0,0,1,0);
  declare_builtin("__sint16toflt64",DOUBLE,INT,BFIRST_GPR,0,0,1,0);
  declare_builtin("__uint16toflt64",DOUBLE,UNSIGNED|INT,BFIRST_GPR,0,0,1,0);
  declare_builtin("__flt64tosint16",INT,DOUBLE,OLDFP?0:BFIRST_BIGP,0,0,1,0);
  declare_builtin("__flt64touint16",UNSIGNED|INT,DOUBLE,OLDFP?0:BFIRST_BIGP,0,0,1,0);

  declare_builtin("__flt64toflt32",FLOAT,DOUBLE,OLDFP?0:BFIRST_BIGP,0,0,1,0);
  declare_builtin("__flt32toflt64",DOUBLE,FLOAT,OLDFP?0:BFIRST_PAIR,0,0,1,0);

  declare_builtin("__addflt32",FLOAT,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR1),FLOAT,OLDFP?0:(ms4?BFIRST_PAIR1:BFIRST_PAIR),1,0);
  declare_builtin("__subflt32",FLOAT,FLOAT,OLDFP?0:BFIRST_PAIR1,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR),1,0);
  declare_builtin("__mulflt32",FLOAT,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR1),FLOAT,OLDFP?0:(ms4?BFIRST_PAIR1:BFIRST_PAIR),1,0);
  declare_builtin("__divflt32",FLOAT,FLOAT,OLDFP?0:BFIRST_PAIR1,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR),1,0);
  declare_builtin("__negflt32",FLOAT,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR),0,0,1,0);
  declare_builtin("__cmpsflt32",INT,FLOAT,OLDFP?0:(ms4?rax:BFIRST_PAIR1),FLOAT,OLDFP?0:(ms4?BFIRST_PAIR1:BFIRST_PAIR),1,0);

  if(NOPEEP) nopeep=1;
  if(CBMASCII) cbmascii=1;
  if(ATASCII) atascii=1;
  if(SC){ jsr="jsr"; rts="\trts\n";}
  if(ACCPARM) accparm=2;
  if(CONSTINDATA) constindata=1;

  jmpinst="bra";

  for(i=0;i<=MAX_TYPE;i++){
    sizetab[i]=l2zm(msizetab[i]);
    align[i]=l2zm(malign[i]);
  }

  return 1;
}

void init_db(FILE *f)
{
}

int freturn(struct Typ *t)
/*  Returns the register in which variables of type t are returned. */
/*  If the value cannot be returned in a register returns 0.        */
/*  A pointer MUST be returned in a register. The code-generator    */
/*  has to simulate a pseudo register if necessary.                 */
{
  int typ=t->flags&NQ;
  if(t->attr&&strstr(t->attr,"__pascal__"))
    return ra;
  if(ISSTRUCT(typ)||ISUNION(typ)||typ==VOID) 
    return 0;
  if(OLDFP&&ISFLOAT(typ)) return FIRST_GPR;
  if(typ==LONG||typ==FLOAT||(ISPOINTER(typ)&&!ISNPOINTER(typ))||(!ieee&&(typ==DOUBLE||typ==LDOUBLE)))
    return rax;
  if(typ==LLONG||(ieee&&(typ==DOUBLE||typ==LDOUBLE)))
    return FIRST_BIGP;
  if(zmleq(szof(t),l2zm(1L)))
    return ra;
  if(zmleq(szof(t),l2zm(2L))) 
    return ra;
  else
    return 0;
}

int reg_pair(int r,struct rpair *p)
/* Returns 0 if the register is no register pair. If r  */
/* is a register pair non-zero will be returned and the */
/* structure pointed to p will be filled with the two   */
/* elements.                                            */
{
  if(r>=FIRST_PAIR&&r<=LAST_PAIR){
    p->r1=(r-FIRST_PAIR)*2+FIRST_GPR;
    p->r2=p->r1+1;
    return 1;
  }else if(r>=FIRST_BIGP&&r<=LAST_BIGP){
    p->r1=(r-FIRST_BIGP)*2+FIRST_BIG;
    p->r2=p->r1+1;
    return 1;
  }else if(r==rax){
    p->r1=ra;
    p->r2=rx;
    return 1;
  }
  return 0;
}

/* estimate the cost-saving if object o from IC p is placed in
   register r */
int cost_savings(struct IC *p,int r,struct obj *o)
{
  int c=p->code,co,isstack=0,isfar=longaddr(o);
  if(o->flags&VAR){
    if(o->v->tattr&ZPAGE) return 0;
    if(ISSTACK(o->v->storage_class)) isstack=1;
  }
  if(indirect(o,0)&&!isstack) co=5; else co=2;
  if(isfar) co+=3;

  /*TODO: adapt this */
  if(o->flags&VKONST){
    if(o!=&p->q1||p->q2.flags!=0) return 0;
    eval_const(&o->v->cobj.val,q1typ(p));
    if(zmeqto(vmax,Z0)) return 0;
    if(r==ra||r==rax) return co;
    if(r==rx&&(c==ASSIGN||c==PUSH)) return co-1;
    return 0;
  }

  if(ISIDX(r)){
    if(r==rx&&(o->flags&DREFOBJ)){
      if((p->typf==(UNSIGNED|CHAR)&&zm2l(p->q2.val.vmax)>1)||(p->typf&NQ)==STRUCT){
	if(o==&p->q1) return co+co+15;
	else return 0;
      }
      return co+co+15;
    }
    if(c==ADD||c==SUB||c==ADDI2P||c==SUBIFP||c==AND||c==OR||c==XOR){
      if(o==&p->q2&&c!=ADDI2P) return co-4;
      if(r==rx&&o==&p->q2&&((p->q1.flags&(VARADR|KONST|VKONST))==0||(p->q1.flags&DREFOBJ)))
	return co-4;
      if((c==ADD||c==SUB)&&o==&p->z&&(p->q2.flags&(KONST|DREFOBJ))==KONST){
	eval_const(&p->q2.val,q2typ(p));
	if(zmeqto(vmax,Z1)&&zumeqto(vumax,ZU1))
	  return co+2;
      }
    }else if(c==ASSIGN||c==CONVERT){
      if(o==&p->q1&&indirect(&p->z,0)) return 1;
      if(o==&p->z&&indirect(&p->q1,0)) return 1;
    }else if(c==COMPARE){
      //if(o==&p->q1&&indirect(&p->q2)) return INT_MIN;
      //if(o==&p->q2&&indirect(&p->q1)) return INT_MIN;
    }else if(c==SETRETURN||c==GETRETURN||c==PUSH){
    }else if(c==TEST){
    }else
      return INT_MIN;
  }

  if(c==ADDI2P&&o==&p->q1&&(p->typf&NU)==CHAR&&(r==rax))
    return INT_MIN;


  if(o->flags&DREFOBJ){
    if(isptr(r))
      return co+co+(isstack?3:10);
    if(r==rax)
      return INT_MIN;
  }
  if(c==SETRETURN&&r==p->z.reg&&!(o->flags&DREFOBJ)) return co+2;
  if(c==GETRETURN&&r==p->q1.reg&&!(o->flags&DREFOBJ)) return co+2;
  if((c==ADD||c==SUB)&&o==&p->z&&p->q1.flags==p->z.flags&&p->q1.v==p->z.v&&(p->q2.flags&(KONST|DREFOBJ))==KONST){
    eval_const(&p->q2.val,q2typ(p));
    if(zmeqto(vmax,Z1)&&zumeqto(vumax,ZU1))
      return co+1;
  }
  if(r==ra)
    return co+2;
  if(ISIDX(r))
    return co+1;
  if(r==rax)
    return co+co+4;
  return co;
}

int regok(int r,int t,int mode)
/*  Returns 0 if register r cannot store variables of   */
/*  type t. If t==POINTER and mode!=0 then it returns   */
/*  non-zero only if the register can store a pointer   */
/*  and dereference a pointer to mode.                  */
{
  if(r==0)
    return 0;
  if(r==rax&&(!(optflags&2)||NORAX))
    return 0;
  if(r==rx&&NOX)
    return 0;
  t&=NQ;
  if(r==rx){
    if(t==POINTER) return 1;
    if(ISSHORT(t)&&(optflags&2)) return 1;
    return 0;
  }
  if(ISCHAR(t))
    if(r==ra||(r>=FIRST_GPR&&r<=LAST_GPR))
      return 1;
  if(ISSHORT(t)){
    if(r==ra){
      if(t==POINTER&&mode<0)
	return 1;
      if(t!=POINTER)
	return 1;
    }
    if(r>=FIRST_GPR&&r<=LAST_GPR)
      return 1;
  }
  if(r==rax||(r>=FIRST_PAIR&&r<=LAST_PAIR)||(r>=FIRST_BIG&&r<=LAST_BIG)){
    if(t==LONG||t==FLOAT||((t==DOUBLE||t==LDOUBLE)&&!ieee))
      return 1;
    if(t>=FPOINTER&&t<=HLPOINTER&&(r!=rax||mode<=0))
      return 1;
  }
  if(r>=FIRST_BIGP&&r<=LAST_BIGP){
    if(t==LLONG||((t==DOUBLE||t==LDOUBLE)&&ieee))
      return 1;
  }
  return 0;
}

int dangerous_IC(struct IC *p)
/*  Returns zero if the IC p can be safely executed     */
/*  without danger of exceptions or similar things.     */
/*  vbcc may generate code in which non-dangerous ICs   */
/*  are sometimes executed although control-flow may    */
/*  never reach them (mainly when moving computations   */
/*  out of loops).                                      */
/*  Typical ICs that generate exceptions on some        */
/*  machines are:                                       */
/*      - accesses via pointers                         */
/*      - division/modulo                               */
/*      - overflow on signed integer/floats             */
{
  int c=p->code;
  if((p->q1.flags&DREFOBJ)||(p->q2.flags&DREFOBJ)||(p->z.flags&DREFOBJ))
    return 1;
  if((c==DIV||c==MOD)&&!isconst(q2))
    return 1;
  return 0;
}

int must_convert(int o,int t,int const_expr)
/*  Returns zero if code for converting np to type t    */
/*  can be omitted.                                     */
/*  On the PowerPC cpu pointers and 32bit               */
/*  integers have the same representation and can use   */
/*  the same registers.                                 */
{
  int op=o&NQ,tp=t&NQ;

  if(op==tp) return 0;
  if(ISCHAR(op)&&ISCHAR(tp)) return 0;
  if(ISSHORT(op)&&ISSHORT(tp)) return 0;
  if(!ieee&&ISFLOAT(op)&&ISFLOAT(tp)) return 0;
  if(op==DOUBLE&&tp==LDOUBLE) return 0;
  if(op==LDOUBLE&&tp==DOUBLE) return 0;
  if(op==FPOINTER&&tp==HPOINTER) return 0;
  if(op==HPOINTER&&tp==FPOINTER) return 0;
  if(op==FLPOINTER&&tp==HLPOINTER) return 0;
  if(op==HLPOINTER&&tp==FLPOINTER) return 0;

  return 1;
}

void gen_ds(FILE *f,zmax size,struct Typ *t)
/*  This function has to create <size> bytes of storage */
/*  initialized with zero.                              */
{
  if(STDSYNTAX)
    emit(f,"\tspace\t%ld\n",zm2l(size));
  else
    emit(f,"\treserve\t%ld\n",zm2l(size));
  newobj=0;
}

void gen_align(FILE *f,zmax align)
/*  This function has to make sure the next data is     */
/*  aligned to multiples of <align> bytes.              */
{
  if(zm2l(align)>1) emit(f,"\talign 1\n");
}

void gen_var_head(FILE *f,struct Var *v)
/*  This function has to create the head of a variable  */
/*  definition, i.e. the label and information for      */
/*  linkage etc.                                        */
{
  char *sec;
  if(v->storage_class==STATIC){
    if(ISFUNC(v->vtyp->flags)) return;
    if(v->tattr&ZPAGE)
      emit(f,"\tzpage\t%s%ld\n",labprefix,zm2l(v->offset));
    set_section(f,v);
    gen_align(f,falign(v->vtyp));
    emit(f,"%s%ld:\n",labprefix,zm2l(v->offset));
    newobj=1;
  }
  if(v->storage_class==EXTERN){
    emit(f,"\t%s\t%s%s\n",(v->flags&NEEDS)?"needs":"global",idprefix,v->identifier);
    if(v->tattr&ZPAGE)
      emit(f,"\tzpage\t%s%s\n",idprefix,v->identifier);
    if(v->flags&(DEFINED|TENTATIVE)){
      set_section(f,v);
      gen_align(f,falign(v->vtyp));
      emit(f,"%s%s:\n",idprefix,v->identifier);
      newobj=1;
    }
  }
}

void gen_dc(FILE *f,int t,struct const_list *p)
/*  This function has to create static storage          */
/*  initialized with const-list p.                      */
{
  if(ISCHAR(t))
    emit(f,"\tdb\t");
  else if(ISFPOINTER(t)||ISHPOINTER(t))
    emit(f,"\taddr\t");
  else if(ISLONG(t)||ISFLOAT(t)||ISFLPOINTER(t)||ISHLPOINTER(t))
    emit(f,"\tdd\t");
  else
    emit(f,"\tdw\t");
  if(!p->tree){
    if(ieee&&ISFLOAT(t)){
      emit_ieee(f,&p->val,t&NQ);
    }else{
      eval_const(&p->val,t&NU);
      if(ISFLOAT(t)) cnv_fp();
      gval.vmax=vmax;
      emitval(f,&gval,MAXINT);
    }
  }else{
    emit_obj(f,&p->tree->o,t&NU);
  }
  emit(f,"\n");newobj=0;
}

/*  The main code-generation routine.                   */
/*  f is the stream the code should be written to.      */
/*  p is a pointer to a doubly linked list of ICs       */
/*  containing the function body to generate code for.  */
/*  v is a pointer to the function.                     */
/*  offset is the size of the stackframe the function   */
/*  needs for local variables.                          */

void gen_code(FILE *f,struct IC *p,struct Var *v,zmax offset)
/*  The main code-generation.                                           */
{
  int c,t,i,msfpcmp=0;
  struct IC *mi;
  FILE *rf=f;
  static char *dbgfile;
  static int dbgline;
  static long pascalret;

  if(vlas){
    fp=LAST_PAIR-2;
    if(!reg_pair(fp,&rp)) ierror(0);
    fp1=rp.r1;
    fp2=rp.r2;
    regused[fp]=1;
    regused[fp1]=1;
    regused[fp2]=1;
   }else{
    fp=sp;
    fp1=fp2=0;
  }
  localsize=offset;
  localsize=(localsize+1)/2*2;
  if(DEBUG&1) printf("gen_code()\n");

  if(!v->fi) v->fi=new_fi();
  v->fi->flags|=ALL_REGS;

  aparm=0;
  for(mi=p;mi;mi=mi->next){
    if(((mi->q1.flags&VAR)&&(mi->q1.v->reg==ra||mi->q1.v->reg==rax))||
       ((mi->q2.flags&VAR)&&(mi->q2.v->reg==ra||mi->q2.v->reg==rax))||
       ((mi->z.flags&VAR)&&(mi->z.v->reg==ra||mi->z.v->reg==rax))){
      aparm=1;
      break;
    }
  }
  
  for(mi=p;mi;mi=mi->next){
    if(mi->code==ADDI2P||mi->code==SUBIFP){
      int t1=mi->typf&NQ,t2=mi->typf2&NQ;
      if((t1==LONG&&t2==HLPOINTER)||
	 ((t1==INT||t1==SHORT)&&t2==POINTER))
	mi->code=mi->code==ADDI2P?ADD:SUB;
    }       
    switch_IC(mi);
  }


  for(pass=0;pass<2;pass++){

    if(DEBUG&1) printf("pass %d\n",pass);

    if(pass==0){
      f=0;
      mi=clone_ic(p);
    }else
      f=rf;

    for(c=1;c<=MAXR;c++) regs[c]=0; /*regsa[c];*/
    maxpushed=0;

    /*FIXME*/
    if(v->tattr&INTERRUPT){
      ret="\trti\n";
      in_isr=1;
    }else{
      ret=rts;
      in_isr=0;
    }

    if(!nopeep) peephole(pass==0?p:mi);

    function_top(f,v,localsize);

    stackoffset=notpopped=dontpop=maxpushed=0;

    yval=NOVAL;

    dbgfile=0;
    dbgline=0;

    for(p=pass==0?p:mi;p;pr(f,p),p=p->next){

      if(DEBUG&1) pric2(stdout,p);

      if(debug_info){
	if(p->file&&p->line){
	  if(p->file!=dbgfile||p->line!=dbgline){
	    dbgfile=p->file;
	    dbgline=p->line;
	    emit(f,"; %d \"%s\"\n",dbgline,dbgfile);
	  }
	}
      }

      c=p->code;t=p->typf;

      if(c==NOP) {p->z.flags=0;continue;}
      if(c==ALLOCREG){
	regs[p->q1.reg]=1;
	if(reg_pair(p->q1.reg,&rp)){
	  regs[rp.r1]=1;
	  regs[rp.r2]=1;
	}
	continue;
      }
      if(c==FREEREG){
	regs[p->q1.reg]=0;
	if(reg_pair(p->q1.reg,&rp)){
	  regs[rp.r1]=0;
	  regs[rp.r2]=0;
	}
	continue;
      }

      if(notpopped&&!dontpop){
	if(c==LABEL||c==COMPARE||c==TEST||(c>=BEQ&&c<=BRA)||(ms4&&c==CALL&&!(p->q1.flags&DREFOBJ)&&!strcmp("__cmpsflt32",p->q1.v->identifier))){
	  if(notpopped!=2&&notpopped!=4&&notpopped!=6&&notpopped!=8){
	    if((c==LABEL||c==BRA)&&p->typf==exit_label){
	      int i=freturn(v->vtyp->next);
	      if(hasretval&&(i==ra||i==rax)){
		pushedacc=ry;
		emit(f,"\ttay\n");
	      }
	    }
	  }
	  fpop=1;
	  incsp(f,notpopped,p);
	  pop(notpopped);
	  notpopped=fpop=0;
	  reload_acc(f);
	}
      }
      if(c==LABEL) {emit(f,"%s%d:\n",labprefix,t);yval=NOVAL;continue;}
      if(c==BRA){
	yval=NOVAL;
	if(t==exit_label&&localsize+rsavesize+rscnt==0)
	  emit(f,ret);
	else
	  emit(f,"\t%s\t%s%d\n",jmpinst,labprefix,t);
	continue;
      }
      if(c>=BEQ&&c<BRA){
	yval=NOVAL;
	continue;
      }

      if(c==MOVETOREG){
	p->code=c=ASSIGN;
	p->typf=t=regtype[p->z.reg]->flags;
	p->q2.val.vmax=sizetab[regtype[p->z.reg]->flags];
      }
      if(c==MOVEFROMREG){
	p->code=c=ASSIGN;
	p->typf=t=regtype[p->q1.reg]->flags;
	p->q2.val.vmax=sizetab[regtype[p->q1.reg]->flags];
      }
      if(c==CONVERT&&ISCHAR(t)&&ISCHAR(p->typf2)){
	p->code=c=ASSIGN;
	p->q2.val.vmax=sizetab[CHAR];
      }
      if(c==CONVERT&&(ISPOINTER(t)||ISPOINTER(p->typf2))&&msizetab[t&NQ]==msizetab[p->typf2&NQ]){
	p->code=c=ASSIGN;
	p->q2.val.vmax=sizetab[t&NQ];
      }
      if(c==CONVERT&&ISSHORT(t)&&ISSHORT(p->typf2)){
	p->code=c=ASSIGN;
	p->q2.val.vmax=sizetab[SHORT];
      }
      if(c==CONVERT&&ISLONG(t)&&ISLONG(p->typf2)){
	p->code=c=ASSIGN;
	p->q2.val.vmax=sizetab[LONG];
      }
      if(c==CONVERT&&ISLLONG(t)&&ISLLONG(p->typf2)){
	p->code=c=ASSIGN;
	p->q2.val.vmax=sizetab[LLONG];
      }
      if(c==CONVERT&&ISFLOAT(t)&&ISFLOAT(p->typf2)){
	p->code=c=ASSIGN;
	p->q2.val.vmax=sizetab[t&NQ];
      }


      /* switch commutative operands if suitable */
      if(c==ADD||c==MULT||c==AND||c==XOR||c==OR||(c==ADDI2P&&ISSHORT(t)&&ISNPOINTER(p->typf2))){
	if((compare_objects(&p->q2,&p->z)&&!isacc(q1))||isacc(q2)){
	  struct obj tmp;
	  tmp=p->q1;
	  p->q1=p->q2;
	  p->q2=tmp;
	}
      }

      if(c==COMPARE&&((p->q1.flags&(KONST|DREFOBJ))==KONST||ISRIDX(q2)||(isacc(q2)&&!ISRIDX(q1)))){
	obj tmp;IC *b;
	tmp=p->q1;
	p->q1=p->q2;
	p->q2=tmp;
	for(b=p->next;b;b=b->next){
	  int bc;
	  if(!b||b->code==LABEL) ierror(0);
	  bc=b->code;
	  if(bc==BGT){b->code=BLT;break;}
	  if(bc==BGE){b->code=BLE;break;}
	  if(bc==BLT){b->code=BGT;break;}
	  if(bc==BLE){b->code=BGE;break;}
	  if(bc==BNE||bc==BEQ) break;
	}
      }

      c=p->code;
      if(c==SUBPFP) c=SUB;
      /*if(c==ADDI2P) c=ADD;*/
      /*if(c==SUBIFP) c=SUB;*/


      if(c==MINUS&&!ISFLOAT(t)){
	if(isacc(q1)&&isacc(z)){
	  emit(f,"\teor\t#65535\n");
	  emit(f,"\tina\n");
	  continue;
	}
	p->code=c=SUB;
	p->q2=p->q1;
	p->q1.flags=KONST;
	p->q1.am=0;
	gval.vmax=Z0;
	eval_const(&gval,MAXINT);
	insert_const(&p->q1.val,t);
      }

      preload(f,p);

      if((c==AND||c==OR)&&(p->q2.flags&(KONST|DREFOBJ))==KONST&&isreg(z)&&isreg(q1)&&p->q1.reg==p->z.reg&&p->z.reg!=rax&&p->z.reg!=ra&&p->z.reg!=rx){
	unsigned long l;
	get_acc(f,p,INT);
	eval_const(&p->q2.val,t);
	l=zum2zul(vumax);
	if(c==AND) l=~l;
	l&=0xffff;
	if(l){
	  if(l==0xffff){
	    if(c==OR)
	      emit(f,"\tlda\t#65535\n\tsta\t%s\n",mregnames[p->z.reg]);
	    else
	      emit(f,"\tstz\t%s\n",mregnames[p->z.reg]);
	  }else{
	    emit(f,"\tlda\t#%lu\n",l);
	    emit(f,"\t%s\t%s\n",c==OR?"tsb":"trb",mregnames[p->z.reg]);
	  }
	}
	if((t&NQ)>=LONG){
	  l=zum2zul(zumrshift(vumax,ul2zum(16ul)));
	  if(c==AND) l=~l;
	  l&=0xffff;
	  if(l!=0){
	    if(l==0xffff){
	      if(c==OR)
		emit(f,"\tlda\t#65535\n\tsta\t%s\n",mregnames[p->z.reg]);
	      else
		emit(f,"\tstz\t%s\n",mregnames[p->z.reg]);
	    }else{
	      if(l!=0xffff||c!=AND) emit(f,"\tlda\t#%lu\n",l&0xffff);
	      emit(f,"\t%s\t%s+2\n",c==OR?"tsb":"trb",mregnames[p->z.reg]);
	    }
	  }
	}
	continue;
      }

      if((c==ADD||c==SUB||c==ADDI2P||c==SUBIFP)&&compare_objects(&p->q1,&p->z)&&((!indirect(&p->q1,0)&&!longaddr(&p->q1))||(isreg(q1)&&(ISIDX(p->q1.reg)||p->q1.reg==rx||p->q1.reg==ra||p->q1.reg==rax)))&&isconst(q2)/*&&!isacc(z)*/){
	long l;
	eval_const(&p->q2.val,q2typ(p));
	l=zm2l(vmax);
	if(c==ADDI2P||c==SUBIFP){
	  if(ISHPOINTER(p->typf2)||ISHLPOINTER(p->typf2)) t=(UNSIGNED|LONG); else t=(UNSIGNED|INT);
	  if(c==ADDI2P) c=ADD; else c=SUB;
	  if((p->typf&NQ)==HPOINTER) l=1000; /* avoid for huge3 => improve later */
	}
	if(c==SUB||c==SUBIFP) l=-l;
	/*TODO: allow larger types */
	if(l<3&&l>-3&&(t&NQ)<=INT){
	  if(l<0){
	    if(!isreg(q1)) get_acc(f,p,CHAR);
	    incmem(f,&p->z,t,SUB,-l);
	  }else
	    incmem(f,&p->z,t,ADD,l);
	  continue;
	}
	if(ISLONG(t)&&((optspeed&&l>0&&l<4)||(l>0&&l<2))){
	  if(l<0){
	    incmem(f,&p->z,t,SUB,-l);
	  }else
	    incmem(f,&p->z,t,ADD,l);
	  continue;
	}
	c=p->code;
      }

      if(c==CONVERT){
	int to=q1typ(p)&NU;
	t&=NU;
	if(ISCHAR(t)){
	  if(!isacc(q1))
	    get_acc(f,p,CHAR);
	  if(!isreg(z)) BMODE();
	  load_lobyte(f,&p->q1,to);
	  store_lobyte(f,&p->z,t);
	  continue;
	}
	if(ISLONG(to)||ISLPOINTER(to)){
	  if(!isacc(z))
	    get_acc(f,p,CHAR);
	  load_lobyte(f,&p->q1,to);
	  store_lobyte(f,&p->z,t);
	  if(zm2l(sizetab[t&NQ])==3){
	    if(!isreg(z)) BMODE();
	    load_byte3(f,&p->q1,CHAR);
	    store_byte3(f,&p->z,CHAR);
	  }
	  continue;
	}
	if(ISSHORT(to)){
	  get_acc(f,p,INT);
	  load_lobyte(f,&p->q1,to);
	  store_lobyte(f,&p->z,t);
	  if(ISPOINTER(t)){
	    if((ISFPOINTER(t)||ISHPOINTER(t))&&!isreg(z)) BMODE();
	    if(isacc(z)){
	      emit(f,"\tldx\t#^__DBR_init\n");
	    }else{
	      emit(f,"\tlda\t#^__DBR_init\n");
	      store_byte3(f,&p->z,t);
	    }
	    WMODE();
	  }else if(to&UNSIGNED){
	    if(isacc(z)){
	      emit(f,"\tldx\t#0\n");
	    }else if(!indirect(&p->z,STZ)){
	      do_byte3(f,"stz",&p->z,t);
	    }else{
	      emit(f,"\tlda\t#0\n");
	      store_byte3(f,&p->z,t);
	    }
	  }else{
	    yval=NOVAL;
	    emit(f,"\tldy\t#0\n");
	    emit(f,"\tcmp\t#0\n");
	    emit(f,"\tbpl\t%s%d\n",labprefix,++label);
	    emit(f,"\tdey\n");
	    emit(f,"%s%d:\n",labprefix,label);
	    if(isacc(z)){
	      emit(f,"\ttyx\n");
	    }else if(indirect(&p->z,STY)){
	      emit(f,"\ttya\n");
	      store_byte3(f,&p->z,t);
	    }else
	      do_byte3(f,"sty",&p->z,t);
	  }
	  continue;
	}
	if(ISCHAR(to)){
	  if(is_volatile_obj(&p->q1)) BMODE();
	  if(!isreg(z)&&(ISFPOINTER(t)||ISHPOINTER(t))) BMODE();
	  if((to&UNSIGNED)||ISPOINTER(t)){
	    char *s;
	    if(isacc(z)){
	      load_lobyte(f,&p->q1,to);
	      emit(f,"\tand\t#255\n");
	      if(zm2l(sizetab[t&NQ])>2) emit(f,"\tldx\t#0\n");
	    }else{
	      get_acc(f,p,CHAR);
	      if(ISFPOINTER(t)||ISHPOINTER(t)){
		if(!indirect(&p->z,STZ)){
		  do_byte3(f,"stz",&p->z,t);
		}else{
		  emit(f,"\tlda\t#0\n");
		  store_byte3(f,&p->z,t);
		}
	      }
	      load_lobyte(f,&p->q1,to);
	      WMODE();emit(f,"\tand\t#255\n");
	      store_lobyte(f,&p->z,t);
	      if(zm2l(sizetab[t&NQ])==4){
		if(!indirect(&p->z,STZ))
		  s="stz";
		else{
		  if(ISLONG(t)) emit(f,"\tlda\t#0\n");
		  s="sta";
		}
		do_byte3(f,s,&p->z,t);
	      }
	    }
	  }else{
	    get_acc(f,p,SHORT);
	    if(is_volatile_obj(&p->q1)) BMODE();
	    load_lobyte(f,&p->q1,to);
	    WMODE();
	    emit(f,"\teor\t#128\n");
	    emit(f,"\tand\t#255\n");
	    emit(f,"\tsec\n");
	    emit(f,"\tsbc\t#128\n");
	    store_lobyte(f,&p->z,t);
	    if(ISLONG(t)){
	      int r;
	      if(!isacc(z)){
		r='y'; 
		yval=NOVAL;
	      }else
		r='x';
	      emit(f,"\tld%c\t#0\n",r);
	      emit(f,"\tcmp\t#0\n");
	      emit(f,"\tbpl\t%s%d\n",labprefix,++label);
	      emit(f,"\tde%c\n",r);
	      emit(f,"%s%d:\n",labprefix,label);
	      if(isacc(z))
		;
	      else if(!indirect(&p->z,STY))
		do_byte3(f,"sty",&p->z,t);
	      else{
		emit(f,"\ttya\n");
		store_byte3(f,&p->z,t);
	      }
	    }
	  }
	  continue;
	}
	if(ISFPOINTER(to)||ISHPOINTER(to)){
	  get_acc(f,p,CHAR);
	  if(zm2l(sizetab[t&NQ])>=3){
	    if(is_volatile_obj(&p->q1)) BMODE();
	    load_byte3(f,&p->q1,to);
	    WMODE();
	    emit(f,"\tand\t#255\n");
	    store_byte3(f,&p->z,t);
	  }
	  if(!compare_objects(&p->q1,&p->z)){
	    if(zm2l(sizetab[t&NQ])==1/*&&!isreg(z)*/) BMODE();
	    load_lobyte(f,&p->q1,to);
	    store_lobyte(f,&p->z,t);
	  }
	  continue;
	}
	pric2(stdout,p);
	ierror(0);
      }

      if(c==KOMPLEMENT){
	get_acc(f,p,CHAR);
	if(ISCHAR(t)&&(!isacc(z)||is_volatile_obj(&p->q1))) BMODE();
	load_lobyte(f,&p->q1,t);
	emit(f,"\teor\t#-1\n");
	store_lobyte(f,&p->z,t);
	if(ISLONG(t)){
	  load_byte3(f,&p->q1,t);
	  emit(f,"\teor\t#-1\n");
	  store_byte3(f,&p->z,t);
	}
	continue;
      }

      if(c==MINUS){
	if(!ms4||!ISFLOAT(t)) ierror(0);
	get_acc(f,p,INT);
	if(!compare_objects(&p->q1,&p->z)){
	  load_byte3(f,&p->q1,t);
	  store_byte3(f,&p->z,t);
	}
	load_lobyte(f,&p->q1,t);
	emit(f,"\teor\t#$8000\n");
	store_lobyte(f,&p->z,t);
	continue;
      }

      if(c==SETRETURN){
	hasretval=1;
	t&=NQ;
	if(isreg(q1)&&p->q1.reg==p->z.reg) continue;
	if(ISLONG(t)||ISFLOAT(t)||(ISPOINTER(t)&&!ISNPOINTER(t))){
	  if(indirect(&p->q1,LDX)){
	    load_byte3(f,&p->q1,t);
	    emit(f,"\ttax\n");
	  }else
	    do_byte3(f,"ldx",&p->q1,t);
	  load_lobyte(f,&p->q1,t);
	  regused[rax]=1;
	  regused[rx]=1;
	  regused[p->z.reg]=1;
	  if(vlas){
	    emit(f,"\tstx\t%s\n",mregnames[t1]);
	    emit(f,"\ttay\n");
	  }
	  continue;
	}
	//get_acc(f,p,t);
	load_acc(f,&p->q1,t);
	regused[ra]=1;
	if(vlas)
	  emit(f,"\ttay\n");
	continue;
      }
      if(c==GETRETURN){
	if(msfpcmp){
	  IC *n;
	  for(n=p->next;n&&n->code==FREEREG;n=n->next);
	  if(n&&n->code==COMPARE) continue;
	  emit(f,"\tand\t#255\n");
	  emit(f,"\txba\n");
	  msfpcmp=0;
	}
	t&=NQ;
	//printf("check pascalret: %ld\n",pascalret);
	if(pascalret){
	  if(pascalret&1) ierror(0);
	  if(pascalret==4){
	    if(isacc(z)){
	      emit(f,"\tpla\n");
	      emit(f,"\tplx\n");
	      pop(4);
	    }else{
	      emit(f,"\tpla\n");pop(2);
	      store_lobyte(f,&p->z,INT);
	      emit(f,"\tpla\n");pop(2);
	      store_byte3(f,&p->z,INT);
	    }
	  }else{
	    do{
	      emit(f,"\tpla\n");pop(2);
	      store_lobyte(f,&p->z,INT);
	      p->z.val.vmax=zmadd(p->z.val.vmax,l2zm(2L));
	      pascalret-=2;
	    }while(pascalret>0);
	  }
	  pascalret=0;
	  continue;
	}
	if(isreg(z)&&p->q1.reg==p->z.reg) continue;
	if(t==LONG||t==LLONG||ISFLOAT(t)||(ISPOINTER(t)&&!ISNPOINTER(t))){
	  long l=zm2l(p->q2.val.vmax);
	  int qr=p->q1.reg;
	  if((p->z.reg&(REG|DREFOBJ))==(REG|DREFOBJ)){
	    if(p->z.reg==qr) ierror(0);
	  }
	  if(qr==rax){
	    store_acc(f,&p->z,t);
	    continue;
	  }
	  emit(f,"\tlda\t%s\n",mregnames[qr]);
	  store_lobyte(f,&p->z,t);
	  emit(f,"\tlda\t%s+2\n",mregnames[qr]);
	  store_byte3(f,&p->z,t);
	  continue;
	}
	if(p->q1.reg)
	  store_acc(f,&p->z,t);
	continue;
      }
      if(c==CALL){
	int reg,pascall;

	/*FIXME*/
#if 0      
	if(stack_valid&&(p->q1.flags&(VAR|DREFOBJ))==VAR&&p->q1.v->fi&&(p->q1.v->fi->flags&ALL_STACK)){
	  if(framesize+zum2ul(p->q1.v->fi->stack1)>stack)
	    stack=framesize+zum2ul(p->q1.v->fi->stack1);
	}else
	  stack_valid=0;
#endif
	if((p->q1.flags&(VAR|DREFOBJ))==VAR&&!strcmp("__va_start",p->q1.v->identifier)){
	  long of=va_offset(v)+localsize+rsavesize+4-stackoffset /*TODO: near*/;
	  emit(f,"\ttsc\n");
	  if(of){
	    emit(f,"\tclc\n");
	    emit(f,"\tadc\t#%ld\n",of);
	  }
	  if(large||huge){
	    emit(f,"\tldx\t#0\n");
	  }
	  continue;
	}
	if((p->q1.flags&VAR)&&p->q1.v->vtyp->next&&fattr(p->q1.v->vtyp->next,"__pascal__")){
	  pascalret=zm2l(szof(p->q1.v->vtyp->next));
	  pascall=1;
	  //printf("set pascalret=%ld\n",pascalret);
#if 0
	  incsp(f,-pascalret);
	  push(pascalret);
#endif
	}else
	  pascall=0;
	if((p->q1.flags&(VAR|DREFOBJ))==VAR&&p->q1.v->fi&&p->q1.v->fi->inline_asm){
	  emit(f,";startinline\n");
	  emit_inline_asm(f,p->q1.v->fi->inline_asm);
	  emit(f,";endinline\n");
	  if(vlas&&!strcmp(p->q1.v->identifier,"__resetvlasp")){
	    int r=freturn(v->vtyp->next);
	    if(r==rax)
	      emit(f,"\tldx\t%s\n",mregnames[t1]);
	    if(r==ra||r==rax)
	      emit(f,"\ttya\n");
	  }
	}else if(p->q1.flags&DREFOBJ){
	  p->q1.flags&=~DREFOBJ;
	  if(!isreg(q1)){
	    load_reg(f,t1,&p->q1,FPOINTER);
	    load_byte3(f,&p->q1,FPOINTER);
	    emit(f,"\tsta\t%s+2\n",mregnames[t1]);
	    p->q1.reg=t1;
	  }
	  emit(f,"\t%s\t%s%d\n",jsr,labprefix,++label);
	  yval=NOVAL;
	  add_cmplist(label,p->q1.reg,JMPIND);
	}else{
	  emit(f,"\t%s\t",jsr);
	  emit_obj(f,&p->q1,t);
	  emit(f,"\n");
	}

	if(!zmeqto(l2zm(0L),p->q2.val.vmax)){
	  notpopped+=zm2l(p->q2.val.vmax);
	  dontpop-=zm2l(p->q2.val.vmax);
	  if(!NODELPOP&&stackoffset==-notpopped){
	    /*  Entfernen der Parameter verzoegern  */
	  }else{
	    long l=zm2l(p->q2.val.vmax);
	    IC *gr;
	    for(gr=p->next;gr&&(gr->code==FREEREG||gr->code==ALLOCREG);gr=gr->next);
	    if(gr->code==GETRETURN&&!regs[ra]&&(gr->z.reg==ra||gr->z.reg==rax))
	      regs[ra]|=8;
	    fpop=1;incsp(f,l,p);fpop=0;
	    pop(l);
	    notpopped-=l;
	  }
	}

	if(pascall){
	  long l=zm2l(p->q2.val.vmax);
	  pop(l-pascalret);
	  notpopped-=l;
	}
	
	if(ms4&&(p->q1.flags&(VAR|DREFOBJ))==VAR&&!strcmp("__cmpsflt32",p->q1.v->identifier))
	  msfpcmp=1;

	if(!calc_regs(p,f!=0)&&v->fi) v->fi->flags&=~ALL_REGS;
	yval=NOVAL;
	continue;
      }
      if(c==ASSIGN||c==PUSH){
	long sz=zm2l(p->q2.val.vmax);
	if(t==0) ierror(0);
	if((p->q1.flags&(KONST|DREFOBJ))==KONST&&(t&NQ)==LLONG){
	  int i;
	  eval_const(&p->q1.val,t);
	  for(i=0;i<8;i++){
	    emit(f,"\tlda\t#%d\n",(int)(zm2l(vmax))&255);
	    vmax=zmrshift(vmax,l2zm(8L));
	    if(c==PUSH||(p->z.flags&DREFOBJ)){
	      sety(f,i+((c==PUSH)?pushed:0));
	      emit(f,"\tsta\t(%s),y\n",(c==PUSH)?mregnames[sp]:mregnames[p->z.reg]);
	    }else{
	      p->z.val.vmax=zmadd(p->z.val.vmax,l2zm((long)i));
	      emit(f,"\tsta\t");
	      emit_lobyte(f,&p->z,t);
	      emit(f,"\n");
	      p->z.val.vmax=zmsub(p->z.val.vmax,l2zm((long)i));
	    }
	  }
	  if(c==PUSH){push(8);dontpop+=8;}
	  continue;
	}
	if((p->q1.flags&VARADR)&&ISFPOINTER(t)){
	  if(c==PUSH){
	    do_byte3(f,"pea",&p->q1,LONG);
	    do_lobyte(f,"pea",&p->q1,LONG);
	    continue;
	  }else{
	    get_acc(f,p,CHAR);
	    emit(f,"\tlda\t#<");
	    emit_obj(f,&p->q1,FPOINTER);
	    emit(f,"\n");
	    store_lobyte(f,&p->z,INT);
	    BMODE();
	    emit(f,"\tlda\t#^(");
	    emit_obj(f,&p->q1,FPOINTER);
	    emit(f,")\n");
	    store_byte3(f,&p->z,FPOINTER);
	    continue;
	  }
	}

	if(sz>4||(sz==3&&t==(UNSIGNED|CHAR))){ /* TODO: sz==3 unten? */
	  enum banktype bsrc,bdst;int dyn=0,px=0,tmp;
	  tmp=longaddr(&p->q1);
	  if(ISHPOINTER(tmp)||ISHLPOINTER(tmp)) dyn=2;
	  if(c!=PUSH&&dyn==0){
	    tmp=longaddr(&p->z);
	    if(ISHPOINTER(tmp)||ISHLPOINTER(tmp)) dyn=2;
	  }
	  if(sz>65535) dyn=2;
	  if(dyn) regs[t1]=regs[t2]=regs[t3]=regs[t4]=8; /* TODO: Problem bei PUSH? */
	  get_acc(f,p,INT);
	  if(c==PUSH){
	    emit(f,"\ttsc\n");
	    emit(f,"\tsec\n");
	    emit(f,"\tsbc\t#%ld\n",sz);
	    emit(f,"\ttcs\n");
	    emit(f,"\tina\n");
	    if(dyn!=2) emit(f,"\ttay\n");
	    push(sz);dontpop+=sz;
	    bdst=stackbank;
	  }else{
	    bdst=get_bt(&p->z);
	  }
	  bsrc=get_bt(&p->q1);

	  if(dyn==2){
	    /* huge copy */
	    if(c==PUSH){
	      emit(f,"\tsta\t%s\n",mregnames[t3]);
	      emit(f,"\tstz\t%s\n",mregnames[t4]);
	    }else{
	      load_address(f,t3,&p->z,t);
	      load_abank(f,&p->z);
	      emit(f,"\tsta\t%s\n",mregnames[t4]);
	    }
	    load_address(f,t1,&p->q1,t);
	    load_abank(f,&p->q1);
	    emit(f,"\tsta\t%s\n",mregnames[t2]);
	    if(sz>65535&&regs[rx]) emit(f,"\tphx\n");
	    if(sz>65535) emit(f,"\tldx\t#%ld\n",(sz>>16)&0xffff);
	    emit(f,"\tldy\t#%ld\n",sz&0xffff);
	    emit(f,"\tjsl\t___hcopy_%s%s\n",(sz&1)?"odd":"even",(sz<=65535)?"_s":"");
	    yval=NOVAL;
	    if(sz>65535&&regs[rx]) emit(f,"\tplx\n");
	    continue;
	  }

	  if(bsrc==fardyn||bdst==fardyn) dyn=1;
	  if(regs[rx]&&!scratch(p->next,rx,1)){
	    emit(f,"\tphx\n");push(2);px=1;
	  }
	  if(dyn){
	    emit(f,"\tpea\t#27392\n");
	    emit(f,"\tpea\t#84\n");
	    push(4);
	  }
	  if(c!=PUSH) load_address(f,ry,&p->z,t);
	  if(dyn){
	    BMODE();
	    load_abank(f,&p->q1);
	    emit(f,"\tsta\t3,s\n");
	    load_abank(f,&p->z);
	    emit(f,"\tsta\t2,s\n");
	  }
	  WMODE();
	  load_address(f,rx,&p->q1,t);

	  if(!dyn&&bdst!=nearbank) {emit(f,"\tphb\n");push(1);}
	  emit(f,"\tlda\t#%ld\n",sz-1);
	  if(!dyn){
	    emit(f,"\tmvn\t");
	  }else{
	    emit(f,"\tjsl\t___fmvn\n");
	    emit(f,"\tpla\n");
	    emit(f,"\tpla\n");
	    pop(4);
	    if(px) {emit(f,"\tplx\n");pop(2);}
	    continue;
	  }
	  if(bsrc==farconst||bsrc==nearbank){
	    emit(f,"#");
	    if(p->q1.flags&KONST){
	      eval_const(&p->q1.val,p->q1.dtyp);
	      emit(f,"%ld",(zm2l(vmax)>>16)&255);
	    }else if(p->q1.flags&DREFOBJ){
	      emit(f,"^__DBR_init");
	    }else{
	      emit(f,"^");
	      nomod=1;emit_obj(f,&p->q1,t);nomod=0;
	    }
	  }else if(bsrc==stackbank)
	    emit(f,"#0");
	  emit(f,",");
	  if(bdst==farconst||bdst==nearbank){
	    emit(f,"#");
	    if(p->z.flags&KONST){
	      eval_const(&p->z.val,p->z.dtyp);
	      emit(f,"%ld",(zm2l(vmax)>>16)&255);
	    }else if(p->z.flags&DREFOBJ){
	      emit(f,"^__DBR_init");
	    }else{
	      emit(f,"^");
	      nomod=1;emit_obj(f,&p->z,t);nomod=0;
	    }
	  }else if(bdst==stackbank)
	    emit(f,"#0");
	  emit(f,"\n");
	  if(bdst!=nearbank) {emit(f,"\tplb\n");pop(1);}
	  if(px) {emit(f,"\tplx\n");pop(2);}
	  continue;
	  
	}
	if(t==(UNSIGNED|CHAR)&&sz!=1) t=INT;
	if(c==PUSH){
	  if(sz==1) BMODE();
	  if((p->q1.flags&(KONST|DREFOBJ))==KONST||(p->q1.flags&VARADR)){
	    if(sz>2){
	      if(sz==3) BMODE();
	      emit(f,"\tpea\t");
	      emit_byte3(f,&p->q1,t);
	      emit(f,"\n");
	      WMODE();
	      push(sz-2);dontpop+=sz-2;
	    }
	    emit(f,"\tpea\t");
	    emit_lobyte(f,&p->q1,t);
	    emit(f,"\n");
	  }else if(isreg(q1)){
	    if(p->q1.reg==ra) emit(f,"\tpha\n");
	    else if(p->q1.reg==rx) emit(f,"\tphx\n");
	    else if(p->q1.reg==rax){
	      if(sz==3){
		emit(f,"\trep\t#16\n");
		emit(f,"\tphx\n");
		emit(f,"\tsep\t#16\n");
		emit(f,"\tpha\n");
	      }else{
		emit(f,"\tphx\n");
		emit(f,"\tpha\n");
	      }
	      push(sz-2);dontpop+=sz-2;
	    }else{
	      if(sz>=3){
		if(sz==3) BMODE();
		emit(f,"\tpei\t(%s+2)\n",mregnames[p->q1.reg]);
		WMODE();
		emit(f,"\tpei\t(%s)\n",mregnames[p->q1.reg]);
		push(sz-2);dontpop+=sz-2;
	      }else
		emit(f,"\tpei\t(%s)\n",mregnames[p->q1.reg]);
	    }
	  }else{
	    get_acc(f,p,t);
	    if(sz>2){
	      if(sz==3) BMODE();
	      load_byte3(f,&p->q1,t);
	      emit(f,"\tpha\n");
	      WMODE();
	      push(sz-2);dontpop+=sz-2;
	    }
	    load_lobyte(f,&p->q1,t);
	    emit(f,"\tpha\n");
	  }
	  push(bmode?1:2);dontpop+=bmode?1:2;
	  continue;
	}
	if(c==ASSIGN){
	  int c2m;unsigned long v;
	  if(isreg(q1)&&p->q1.reg==rx&&!indirect(&p->z,STX)){
	    do_lobyte(f,"stx",&p->z,t);
	    continue;
	  }
	  if(isreg(q1)&&isreg(z)&&p->q1.reg==p->z.reg) continue;
	  if(isacc(q1)){
	    if(p->q1.reg==rax&&indirect(&p->z,STX)) get_acc(f,p,CHAR);
	    store_acc(f,&p->z,t);
	    continue;
	  }
	  if(!indirect(&p->z,0)&&(p->q1.flags&(DREFOBJ|KONST))==KONST){
	    eval_const(&p->q1.val,t);
	    if(ISFLOAT(t)){
	      cnv_fp();
	      v=zum2ul(zm2zum(vmax));
	    }else
	      v=zum2ul(vumax);
	    c2m=1;
	  }else
	    c2m=0;
	  if(!c2m||v!=0)
	    get_acc(f,p,CHAR);
       
	  if(sz==1){
	    if(!isreg(z)||is_volatile_obj(&p->q1)) BMODE();
	    if(c2m&&(v&0xFF)==0){
	      do_lobyte(f,"stz",&p->z,t);
	    }else{
	      load_lobyte(f,&p->q1,t);
	      store_lobyte(f,&p->z,t);
	    }
	  }else{
	    if(sz>2&&isacc(z)){
	      if(indirect(&p->q1,LDX)){
		if(sz==3&&is_volatile_obj(&p->q1)) BMODE();
		load_byte3(f,&p->q1,t);
		emit(f,"\ttax\n");
		WMODE();
	      }else{
		if(sz==3&&is_volatile_obj(&p->q1)) BXMODE();
		do_byte3(f,"ldx",&p->q1,t);
		WXMODE();
	      }
	    }
	    if(c2m&&(v&0xFFFF)==0){
	      do_lobyte(f,"stz",&p->z,t);
	    }else{
	      if(isreg(z)&&p->z.reg==rx&&!indirect(&p->q1,LDX)){
		do_lobyte(f,"ldx",&p->q1,t);
	      }else{
		load_lobyte(f,&p->q1,t);
		store_lobyte(f,&p->z,t);
	      }
	    }
	    if(!isacc(z)){
	      if(sz==4){
		if(c2m&&(v&0xFFFF0000)==0){
		  do_byte3(f,"stz",&p->z,t);
		}else{
		  load_byte3(f,&p->q1,t);
		  store_byte3(f,&p->z,t);
		}
	      }
	      if(sz==3){
		if(!isreg(z)||is_volatile_obj(&p->q1)) BMODE();
		if(c2m&&(v&0xFF0000)==0){
		  do_byte3(f,"stz",&p->z,t);
		}else{
		  load_byte3(f,&p->q1,t);
		  store_byte3(f,&p->z,t);
		}
		WMODE();
	      }
	    }
	  }
	}
	continue;
      }
      if(c==ADDRESS){
	long o=real_offset(&p->q1);
	long sz=zm2l(sizetab[p->typf2&NQ]);
	get_acc(f,p,INT);
	if(fp==sp)
	  emit(f,"\ttsc\n");
	else
	  emit(f,"\tlda\t%s\n",mregnames[fp]);
	if(o==0) ;
	else if(o==1) emit(f,"\tina\n");
	else if(o==2) emit(f,"\tina\n\tina\n");
	else if(o==3) emit(f,"\tina\n\tina\n\tina\n");
	else emit(f,"\tclc\n\tadc\t#%ld\n",o);
	store_lobyte(f,&p->z,t);
	if(sz>2){
	  if(sz==3&&!isreg(z)) BMODE();
	  if(isacc(z)){
	    emit(f,"\tldx\t#0\n");
	  }else if(indirect(&p->z,STZ)){
	    emit(f,"\tlda\t#0\n");
	    store_byte3(f,&p->z,t);
	  }else
	    do_byte3(f,"stz",&p->z,t);
	}
	continue;
      }

      if(c==COMPARE||c==TEST){
	IC *branch=p->next;
	int pacc=0,bc,bout;
	if(ISPOINTER(t)) t|=UNSIGNED;
	while(branch){
	  if(branch->code>=BEQ&&branch->code<BRA)
	    break;
	  if(branch->code!=FREEREG&&branch->code!=ALLOCREG&&branch->code!=NOP)
	    ierror(0);
	  branch=branch->next;
	}
	bc=branch->code;
	bout=branch->typf;
	if(msfpcmp){
	  /*if(!isreg(q1)||p->q1.reg!=ra) {pric2(stdout,p);ierror(0);}*/
	  msfpcmp=0;
	  if(bc==BLT||bc==BLE)
	    emit(f,"\tbmi\t%s%d\n",labprefix,bout);
	  else if(bc==BGT||bc==BGE){
	    if(bc==BGT)
	      emit(f,"\tbeq\t%s%d\n",labprefix,++label);
	    emit(f,"\tbpl\t%s%d\n",labprefix,bout);
	    if(bc==BGT)
	      emit(f,"%s%d:\n",labprefix,label);
	  }
	  if(bc==BEQ||bc==BLE)
	    emit(f,"\tbeq\t%s%d\n",labprefix,bout);
	  if(bc==BNE)
	    emit(f,"\tbne\t%s%d\n",labprefix,bout);
	  continue;
	}
	if(c==TEST){
	  p->q2.flags=KONST;
	  gval.vmax=Z0;
	  eval_const(&gval,MAXINT);
	  insert_const(&p->q2.val,t);
	}
	if((t&NU)==(UNSIGNED|CHAR)&&(bc==BLE||bc==BGT)&&(p->q2.flags&(DREFOBJ|KONST))==KONST){
	  eval_const(&p->q2.val,t);
	  if(!zmeqto(vmax,l2zm(255L))){
	    vmax=zmadd(vmax,Z1);
	    gval.vmax=vmax;
	    eval_const(&gval,t);
	    insert_const(&p->q2.val,t);
	    if(bc==BLE) bc=BLT; else bc=BGE;
	    branch->code=bc;
	  }
	}
	if(((t&NQ)==SHORT||(t&NQ)==INT||(t&NQ)==LONG||ISPOINTER(t))&&(bc==BNE||bc==BEQ)&&isconst(q2)&&!isacc(q1)){
	  eval_const(&p->q2.val,t);
	  if(zmeqto(vmax,Z0)&&zumeqto(vumax,ZU0)){
	    long sz;
	    if(pacc=cmp_get_acc(f,p,branch))
	      bout=++label;
	    load_lobyte(f,&p->q1,t);
	    if((sz=zm2l(sizetab[t&NQ]))>=3){
	      if(sz==3) BMODE();
	      do_byte3(f,"ora",&p->q1,t);
	      WMODE();
	    }
	    if(amreloaded) {emit(f,"\ttay\n");yval=NOVAL;}
	    /* lda might be removed by emit_peephole() and sta does not set flags */
	    if(sz<=2&&!amreloaded) emit(f,"\tcmp\t#0\n");
	    emit(f,"\t%s\t%s%d\n",(bc==BNE)?"bne":"beq",labprefix,bout);
	    if(pacc){
	      reload_acc(f);
	      add_cmplist(bout,branch->typf,pacc);
	    }
	    continue;
	  }
	}
	if(ieee&&ISFLOAT(t)){
	  if(!ieee) ierror(0);
	  t&=NQ;
	  if(regs[LAST_PAIR]) ierror(0);
	  regs[LAST_PAIR]=1;
	  if(regs[ra]||regs[rax])
	    ierror(0);
	  push_address(f,&p->q2,t);
	  BSET(regused,t3);
	  BSET(regused,t4);
	  emit(f,"\t%s\t%s__fload%c\n",jsr,idprefix,(t==FLOAT?'s':'d'));
	  yval=NOVAL;
	  push_address(f,&p->q1,t);
	  emit(f,"\t%s\t%s__fcmp%c\n",jsr,idprefix,(t==FLOAT?'s':'d'));
	  yval=NOVAL;
	  regs[LAST_PAIR]=0;
	  if(bc==BLT||bc==BLE)
	    emit(f,"\tbmi\t%s%d\n",labprefix,bout);
	  else if(bc==BGT|bc==BGE)
	    emit(f,"\tbvs\t%s%d\n",labprefix,bout);
	  if(bc==BEQ||bc==BLE||bc==BGE)
	    emit(f,"\tbeq\t%s%d\n",labprefix,bout);
	  if(bc==BNE)
	    emit(f,"\tbne\t%s%d\n",labprefix,bout);
	  continue;
	}
	if(ISCHAR(t)||ISSHORT(t)){
	  char *s=0;
	  if(isreg(q1)&&ISIDX(p->q1.reg)&&!indirect(&p->q2,CPX)&&(bc==BEQ||bc==BNE||(t&UNSIGNED))){
	    static char buf[4]="cpr";
	    s=buf;s[2]=mregnames[p->q1.reg][0];
	    if(ISCHAR(t)) BMODE();
	  }else{
	    if(pacc=cmp_get_acc(f,p,branch))
	      bout=++label;
	    if(ISCHAR(t)) BMODE();
	    load_acc(f,&p->q1,t);
	    if(bc==BEQ||bc==BNE||(t&UNSIGNED)){
	      s="cmp";
	    }else{
	      if(bc==BLT||bc==BGE)
		emit(f,"\tsec\n");
	      else
		emit(f,"\tclc\n");
	      s="sbc";
	    }
	  }
	  if(c==TEST)
	    emit(f,"\t%s\t#0\n",s);
	  else{
	    amcmpreload=1;
	    do_lobyte(f,s,&p->q2,t);
	    amcmpreload=0;
	  }
	  WMODE();
	  if(bc==BEQ)
	    emit(f,"\tbeq\t%s%d\n",labprefix,bout);
	  else if(bc==BNE)
	    emit(f,"\tbne\t%s%d\n",labprefix,bout);
	  else if(t&UNSIGNED){
	    if(bc==BLT)
	      emit(f,"\tbcc\t%s%d\n",labprefix,bout);
	    else if(bc==BGE)
	      emit(f,"\tbcs\t%s%d\n",labprefix,bout);
	    else if(bc==BLE){
	      emit(f,"\tbcc\t%s%d\n",labprefix,bout);
	      emit(f,"\tbeq\t%s%d\n",labprefix,bout);
	    }else if(bc==BGT){
	      emit(f,";\n\tbeq\t%s%d\n",labprefix,++label);
	      emit(f,"\tbcs\t%s%d\n",labprefix,bout);
	      emit(f,"%s%d:\n",labprefix,label);
	    }else
	      ierror(0);
	  }else{
	    emit(f,"\tbvc\t%s%d\n",labprefix,++label);
	    if(!ISCHAR(t))
	      emit(f,"\teor\t#32768\n");
	    else
	      emit(f,"\teor\t#128\n");
	    emit(f,"%s%d:\n",labprefix,label);
	    WMODE();
	    if(bc==BLT||bc==BLE)
	      emit(f,"\tbmi\t%s%d\n",labprefix,bout);
	    else
	      emit(f,"\tbpl\t%s%d\n",labprefix,bout);
	  }
	  if(pacc){
	    reload_acc(f);
	    add_cmplist(bout,branch->typf,pacc);
	  }
	  continue;
	}else if(bc==BEQ||bc==BNE||(t&UNSIGNED)){
	  int in=0;long sz;
	  if(pacc=cmp_get_acc(f,p,branch))
	    bout=++label;
	  if((sz=zm2l(sizetab[t&NQ]))>=3&&(!ms4||!ISFLOAT(t))){
	    if(isacc(q1)&&p->q1.reg==rax){
	      if(indirect(&p->q2,CPX)){
		int r=get_reg(f,p,INT);
		emit(f,"\tpha\n");push(2);
		load_byte3(f,&p->q2,t);
		emit(f,"\tsta\t%s\n",mregnames[r]);
		emit(f,"\tpla\n");pop(2);
		if(sz==3) BXMODE();
		emit(f,"\tcpx\t%s\n",mregnames[r]);
	      }else{
		if(sz==3) BXMODE();
		if(c==TEST)
		  emit(f,"\tcpx\t#0\n");
		else
		  do_byte3(f,"cpx",&p->q2,t);
	      }
	      if(sz==3) WXMODE();
	    }else{
	      if(sz==3) BMODE();
	      load_byte3(f,&p->q1,t);
	      if(c==TEST)
		emit(f,"\tcmp\t#0\n");
	      else{
		amcmpreload=1;
		do_byte3(f,"cmp",&p->q2,t);
		amcmpreload=0;
	      }
	      WMODE();
	    }
	    if(bc==BEQ)
	      emit(f,"\tbne\t%s%d\n",labprefix,in?in:(in=++label));
	    else if(bc==BNE)
	      emit(f,"\tbne\t%s%d\n",labprefix,bout);
	    else if(bc==BLT||bc==BLE){
	      emit(f,"\tbcc\t%s%d\n",labprefix,bout);
	      emit(f,"\tbne\t%s%d\n",labprefix,in?in:(in=++label));
	    }else if(bc==BGE||bc==BGT){
	      emit(f,"\tbcc\t%s%d\n",labprefix,in?in:(in=++label));	
	      emit(f,"\tbne\t%s%d\n",labprefix,bout);
	    }else
	      ierror(0);	  
	  }
	  load_lobyte(f,&p->q1,t);
	  if(c==TEST){
	    if(ms4&&ISFLOAT(t)){
	      emit(f,"\tand\t#255\n");
	    }else
	      emit(f,"\tcmp\t#0\n");
	  }else{
	    amcmpreload=1;
	    do_lobyte(f,"cmp",&p->q2,t);
	    amcmpreload=0;
	  }
	  if(bc==BEQ)
	    emit(f,"\tbeq\t%s%d\n",labprefix,bout);
	  else if(bc==BNE)
	    emit(f,"\tbne\t%s%d\n",labprefix,bout);
	  else if(bc==BLT)
	    emit(f,"\tbcc\t%s%d\n",labprefix,bout);
	  else if(bc==BGE)
	    emit(f,"\tbcs\t%s%d\n",labprefix,bout);	
	  else if(bc==BLE){
	    emit(f,"\tbcc\t%s%d\n",labprefix,bout);
	    emit(f,"\tbeq\t%s%d\n",labprefix,bout);
	  }else if(bc==BGT){
	    emit(f,"\tbcc\t%s%d\n",labprefix,in);
	    emit(f,"\tbne\t%s%d\n",labprefix,bout);
	  }else
	    ierror(0);
	  if(in)
	    emit(f,"%s%d:\n",labprefix,in);
	  if(pacc){
	    reload_acc(f);
	    add_cmplist(bout,branch->typf,pacc);
	  }
	  continue;
	}else{
	  if(bc==BGT||bc==BLE){
	    obj o;
	    if(isacc(q1)){
	      int r;
	      if(pacc=cmp_get_acc(f,p,branch))
		bout=++label;
	      r=get_reg(f,p,INT);
	      emit(f,"\tsta\t%s\n",mregnames[r]);
	      load_lobyte(f,&p->q2,t);
	      emit(f,"\tcmp\t%s\n",mregnames[r]);
	      emit(f,"\tstx\t%s\n",mregnames[r]);
	      amcmpreload=1;
	      load_byte3(f,&p->q2,t);
	      amcmpreload=0;
	      emit(f,"\tsbc\t%s\n",mregnames[r]);
	      emit(f,"\tbvc\t%s%d\n",labprefix,++label);
	      emit(f,"\teor\t#128\n");
	      emit(f,"%s%d:\n",labprefix,label);
	      if(bc==BGT)
		emit(f,"\tbmi\t%s%d\n",labprefix,bout);
	      else
		emit(f,"\tbpl\t%s%d\n",labprefix,bout);
	      if(pacc){
		reload_acc(f);
		add_cmplist(bout,branch->typf,pacc);
	      }
	      continue;
	    }else{
	      o=p->q1;p->q1=p->q2;p->q2=o;
	      if(bc==BGT) bc=BLT; else bc=BGE;
	    }
	  }
	  if(pacc=cmp_get_acc(f,p,branch))
	    bout=++label;
	  if(ISLONG(t)){
	    load_lobyte(f,&p->q1,t);
	    do_lobyte(f,"cmp",&p->q2,t);
	    amcmpreload=1;
	    load_byte3(f,&p->q1,t);
	    amcmpreload=0;
	    do_byte3(f,"sbc",&p->q2,t);
	  }else{
	    ierror(0);
	    load_lobyte(f,&p->q1,t);
	    do_lobyte(f,"cmp",&p->q2,t);
	    amcmpreload=1;
	    load_hibyte(f,&p->q1,t);
	    amcmpreload=1;
	    do_hibyte(f,"sbc",&p->q2,t);
	    amcmpreload=0;
	  }
	  emit(f,"\tbvc\t%s%d\n",labprefix,++label);
	  emit(f,"\teor\t#%d\n",(c816&&ISLONG(t))?32768:128);
	  emit(f,"%s%d:\n",labprefix,label);
	  if(bc==BLT)
	    emit(f,"\tbmi\t%s%d\n",labprefix,bout);
	  else if(bc==BGE)
	    emit(f,"\tbpl\t%s%d\n",labprefix,bout);
	  else
	    ierror(0);
	  if(pacc){
	    reload_acc(f);
	    add_cmplist(bout,branch->typf,pacc);
	  }
	  continue; 
	}
	ierror(0);
      }


      if((c==ADD||c==SUB)&&ISRIDX(z)&&isconst(q2)){
	eval_const(&p->q2.val,t);
	if(zmeqto(vmax,l2zm(-1L))){ 
	  vmax=Z1; vumax=ZU1; 
	  if(c==ADD) c=SUB; else c=ADD;
	}
	if(zmeqto(vmax,Z1)&&zumeqto(vumax,ZU1)){
	  if(indirect(&p->q1,LDX)){
	    get_acc(f,p,CHAR);
	    load_reg(f,p->z.reg,&p->q1,t);
	  }else
	    do_lobyte(f,"ldx",&p->q1,t);
	  emit(f,"\t%s%s\n",(c==ADD)?"in":"de",mregnames[p->z.reg]);
	  continue;
	}
      }

      if((c==LSHIFT||c==RSHIFT)&&isconst(q2)&&
	 (
	 (isreg(q1)&&isreg(z)&&p->q1.reg==p->z.reg&&p->z.reg!=ra&&p->z.reg!=rax)||
	 (!indirect(&p->q1,0)&&!longaddr(&p->q1)&&compare_objects(&p->q1,&p->z))
	 )
	 ){
	long l;
	eval_const(&p->q2.val,q2typ(p));
	l=zm2l(vmax);
	/*TODO: allow larger types */
	if((l<3||(iszpage(&p->z)&&l<5))&&(t&NQ)<=LONG&&(!c816||c==LSHIFT||(t&UNSIGNED))){
	  if(c==RSHIFT&&(!(t&UNSIGNED)))
	    get_acc(f,p,CHAR);
	  if(isreg(q1)&&p->q1.reg==rx) ierror(0);
	  incmem(f,&p->z,t,c,l);
	  continue;
	}
      }

      if(c==LSHIFT||c==RSHIFT){
	long l=-1,lorg=0,m;int loop=0,r=0,r2=0,outl=0,same=0;
	char *offset="";
	if(isconst(q2)){
	  eval_const(&p->q2.val,q2typ(p));
	  l=zm2l(vmax);
	  loop=0;
	}else
	  loop=1;
	if(l>=0&&optsize){
	  if(c==LSHIFT&&(l&7)>6) 
	    loop=1;
	  else if(c==RSHIFT&&(t&UNSIGNED)&&(l&7)>3)
	    loop=1;
	  else if(c==RSHIFT&&!(t&UNSIGNED)&&(l&7)>2)
	    loop=1;
	}

	if(ISLONG(t)){
	  /* TODO: optimize cases where z can be used */
	  get_acc(f,p,INT);
	  if(l>=16)
	    ;
	  else if(isacc(q1)&&l>=8&&l<16)
	    r2=get_reg(f,p,LONG);
	  else
	    r2=get_reg(f,p,INT);
	  if(c==LSHIFT){
	    if(l>=16){
	      load_lobyte(f,&p->q1,t);
	      if(l>=24){
		emit(f,"\txba\n");
		emit(f,"\tand\t#65280\n");
	      }
#if 0
	      emit(f,"\tsta\t%s\n",mregnames[r2]);
	      emit(f,"\tlda\t#0\n");
#endif
	    }else if(l>=8){
	      if(isacc(q1)){
		emit(f,"\tsta\t%s\n",mregnames[r2]);
		emit(f,"\tstx\t%s+2\n",mregnames[r2]);
		offset="+1";
	      }else{
		load_hibyte(f,&p->q1,t);
		emit(f,"\tsta\t%s\n",mregnames[r2]);
		load_lobyte(f,&p->q1,t);
	      }
	      emit(f,"\txba\n");
	      emit(f,"\tand\t#65280\n");
	    }else{
	      if(isacc(q1)){
		emit(f,"\tstx\t%s\n",mregnames[r2]);
	      }else{
		load_byte3(f,&p->q1,t);
		emit(f,"\tsta\t%s\n",mregnames[r2]);
		load_lobyte(f,&p->q1,t);
	      }
	    }
	  }else{
	    if(l>=24){
	      load_byte3(f,&p->q1,t);
	      emit(f,"\txba\n");
	      if(t&UNSIGNED){
		emit(f,"\tand\t#255\n");
	      }else{
		emit(f,"\tbit\t#128\n");
		emit(f,"\tbeq\t%s%d\n",labprefix,++label);
		emit(f,"\tora\t#65280\n");
		if(isacc(z))
		  emit(f,"\tldx\t#65535\n");
		else
		  sety(f,65535);
		if(l>24) emit(f,"\tsec\n");
		emit(f,"\tbra\t%s%d\n",labprefix,++label);
		emit(f,"%s%d:\n",labprefix,label-1);
		emit(f,"\tand\t#255\n");
		if(isacc(z))
		  emit(f,"\tldx\t#0\n");
		else{
		  yval=m;
		  sety(f,0);
		  yval=NOVAL;
		}
		if(l>24) emit(f,"\tclc\n");
		emit(f,"%s%d:\n",labprefix,label);
	      }
	    }else if(l>=16){
	      long m=yval;
	      load_byte3(f,&p->q1,t);
	      if(!(t&UNSIGNED)){
		emit(f,"\tbpl\t%s%d\n",labprefix,++label);
		if(isacc(z))
		  emit(f,"\tldx\t#65535\n");
		else
		  sety(f,65535);
		if(l>16) emit(f,"\tsec\n");
		emit(f,"\tbra\t%s%d\n",labprefix,++label);
		emit(f,"%s%d:\n",labprefix,label-1);
		if(isacc(z))
		  emit(f,"\tldx\t#0\n");
		else{
		  yval=m;
		  sety(f,0);
		  yval=NOVAL;
		}
		if(l>16) emit(f,"\tclc\n");
		emit(f,"%s%d:\n",labprefix,label);
	      }
	    }else if(l>=8){
	      if(isacc(q1)){
		emit(f,"\tsta\t%s\n",mregnames[r2]);
		emit(f,"\tstx\t%s+2\n",mregnames[r2]);
		emit(f,"\ttxa\n");
		emit(f,"\txba\n");
		offset="+1";
	      }else{
		load_hibyte(f,&p->q1,t);
		emit(f,"\tsta\t%s\n",mregnames[r2]);
		do_byte4(f,"lda",&p->q1,t);
	      }
	      emit(f,"\tand\t#255\n");
	      if(!(t&UNSIGNED)){
		emit(f,"\tbit\t#128\n");
		emit(f,"\tbeq\t%s%d\n",labprefix,++label);
		emit(f,"\teor\t#65280\n");
		emit(f,"%s%d:\n",labprefix,label);
	      }
	    }else{
	      load_lobyte(f,&p->q1,t);
	      emit(f,"\tsta\t%s\n",mregnames[r2]);
	      load_byte3(f,&p->q1,t);
	    }
	  }
	}else{
	  get_acc(f,p,INT);
	  if(ISCHAR(t)/*&&(is_volatile_obj(&p->q1)||c==RSHIFT)*/) BMODE();
	  load_lobyte(f,&p->q1,t);
	  if(c==LSHIFT){
	    if(l>=8) emit(f,"\txba\n\tand\t#65280\n");
	  }else if(t&UNSIGNED){
	    if(l>=8) emit(f,"\txba\n\tand\t#255\n");
	  }else{
	    if(l>=8){label++; emit(f,"\tand\t#65280\n\txba\n\tbpl\t%s%d\n\tclc\n\tadc\t#65280\n%s%d:\n",labprefix,label,labprefix,label);}
	    //if(l>3) lorg=l;
	  }
	}
	m=l;
	if(l>=0) l&=7;
	if(c==RSHIFT&&ISCHAR(t)) BMODE();
	if(loop){
	  if(l>=0)
	    sety(f,l);
	  else{
	    int sm=bmode;
	    if(indirect(&p->q2,LDY)){
	      if(ISCHAR(q2typ(p))) BMODE();
	      emit(f,"\tpha\n");push(bmode?1:2);
	      load_lobyte(f,&p->q2,q2typ(p));
	      if(bmode){emit(f,"\tldy\t#0\n"); BXMODE();}
	      emit(f,"\ttay\n");
	      emit(f,"\tpla\n");pop(bmode?1:2);
	      emit(f,"\tcpy\t#0\n");
	    }else{
	      if(ISCHAR(q2typ(p))){ emit(f,"\tldy\t#0\n"); BXMODE();}
	      emit(f,"\tldy\t");
	      emit_lobyte(f,&p->q2,q2typ(p));
	      emit(f,"\n");
	    }
	    WXMODE();
	    outl=++label;
	    if(sm!=bmode) WMODE();
	    emit(f,"\tbeq\t%s%d\n",labprefix,outl);
	  }
	  emit(f,"%s%d:\n",labprefix,++label);
	}else{
	  if(ISCHAR(t))
	    l&=7;
	  else if(ISSHORT(t))
	    l&=15;
	  else
	    l&=31;
	}
	while(l>0||loop){
	  if(c==LSHIFT){
	    emit(f,"\tasl\n");
	    if(ISLONG(t)&&m<16){
	      emit(f,"\trol\t%s%s\n",mregnames[r2],offset);
	    }
	  }else if(t&UNSIGNED){
	    emit(f,"\tlsr\n");
	    if(ISLONG(t)&&m<16){
	      emit(f,"\tror\t%s%s\n",mregnames[r2],offset);
	    }
	  }else{
	    if(ISLONG(t)&&m<16){
	      emit(f,"\tcmp\t#32768\n");
	      emit(f,"\tror\n");
	      emit(f,"\tror\t%s%s\n",mregnames[r2],offset);
	    }else{
	      if(lorg){
		emit(f,"\tlsr\n");
	      }else{
		if(m<16) emit(f,"\tcmp\t#%d\n",(!bmode)?32768:128);
		emit(f,"\tror\n");
	      }
	    }
	  }
	  if(loop){
	    emit(f,"\tdey\n");
	    emit(f,"\tbne\t%s%d\n",labprefix,label);
	    if(outl) emit(f,"%s%d:\n",labprefix,outl);
	    yval=0;
	    break;
	  }
	  l--;
	}
	if(ISLONG(t)){
	  if(c==LSHIFT){
	    if(m>=16){
	      if(isacc(z)){
		emit(f,"\ttax\n");
		emit(f,"\tlda\t#0\n");
	      }else{
		store_byte3(f,&p->z,t);
		if(indirect(&p->z,STZ)){
		  emit(f,"\tlda\t#0\n");
		  store_lobyte(f,&p->z,t);
		}else
		  do_lobyte(f,"stz",&p->z,t);
	      }
	    }else{
	      store_lobyte(f,&p->z,t);
	      if(isacc(z)){
		emit(f,"\tldx\t%s%s\n",mregnames[r2],offset);
	      }else{
		emit(f,"\tlda\t%s%s\n",mregnames[r2],offset);
		store_byte3(f,&p->z,t);
	      }
	    }
	  }else{
	    if(m>=16){
	      if(isacc(z)){
		if(t&UNSIGNED)
		  emit(f,"\tldx\t#0\n");
	      }else{
		store_lobyte(f,&p->z,t);
		if(indirect(&p->z,(t&UNSIGNED)?STZ:STY)){
		  if(t&UNSIGNED)
		    emit(f,"\tlda\t#0\n");
		  else
		    emit(f,"\ttya\n");
		  store_byte3(f,&p->z,t);
		}else
		  do_byte3(f,(t&UNSIGNED)?"stz":"sty",&p->z,t);
	      }
	    }else{
	      store_byte3(f,&p->z,t);
	      emit(f,"\tlda\t%s%s\n",mregnames[r2],offset);
	      store_lobyte(f,&p->z,t);
	    }
	  }
	}else{
#if 0
	  if(lorg){
	    emit(f,"\teor\t#%d\n",(1<<(lorg-1)));
	    if(lorg!=8) emit(f,"\tand\t#%d\n",(1<<lorg)-1);
	    emit(f,"\tsec\n");
	    emit(f,"\tsbc\t#%d\n",(1<<(lorg-1)));
	  }
#endif
	  store_acc(f,&p->z,t);
	}
	continue;
      }

      if((c>=OR&&c<=AND)||(c>=LSHIFT&&c<=MOD)||c==ADDI2P||c==SUBIFP){
	char *s;int t2=t,pt=p->typf2;
	if(!isacc(z)){
	  /* TODO: check other operations */
	  if((c==ADD||c==SUB||c==AND||c==XOR||c==OR||c==ADDI2P||c==SUBIFP)&&isacc(q1)&&scratch(p->next,ra,1))
	    ;
	  else
	    get_acc(f,p,INT);
	}
	if(c==ADDI2P||c==SUBIFP){
	  if(c==ADDI2P) c=ADD; else c=SUB;
	  if(ISHPOINTER(pt)||ISHLPOINTER(pt)) t=UNSIGNED|LONG; else t=UNSIGNED|INT;
	  if((p->q1.flags&(KONST|DREFOBJ))==KONST){
	    eval_const(&p->q1.val,pt);
	    insert_const(&p->q1.val,t);
	  }
	  if((p->q2.flags&(KONST|DREFOBJ))==KONST){
	    eval_const(&p->q2.val,p->typf);
	    insert_const(&p->q2.val,t);
	  }
	}
	if(c>=OR&&c<=AND)
	  s=logicals[c-OR];
	else
	  s=arithmetics[c-LSHIFT];
      
	if(ISFLOAT(t)){
	  if(!ieee) ierror(0);
	  t&=NQ;
	  if(regs[LAST_PAIR]) ierror(0);
	  get_acc(f,p,INT);
	  regs[LAST_PAIR]=1;
	  push_address(f,&p->q1,t);
	  BSET(regused,t3);
	  BSET(regused,t4);
	  emit(f,"\t%s\t%s__fload%c\n",jsr,idprefix,(t==FLOAT?'s':'d'));
	  yval=NOVAL;
	  push_address(f,&p->q2,t);
	  emit(f,"\t%s\t%s__f%s%c\n",jsr,idprefix,ename[c],(t==FLOAT?'s':'d'));
	  yval=NOVAL;
	  push_address(f,&p->z,t);
	  emit(f,"\t%s\t%s__fstore%c\n",jsr,idprefix,(t==FLOAT?'s':'d'));
	  yval=NOVAL;
	  regs[LAST_PAIR]=0;
	  continue;
	}else if(ISLONG(t)){
	  long l;int cnst=0;
	  if(c==ADD) emit(f,"\tclc\n");
	  if(c==SUB) emit(f,"\tsec\n");
	  if((p->q2.flags&(KONST|DREFOBJ))==KONST){
	    eval_const(&p->q2.val,t);
	    l=zm2l(vmax);
	    cnst=1;
	  }
	  if(cnst){
	    if((c==ADD||c==ADDI2P)&&isacc(z)&&(l&0xffff0000)==0&&!compare_objects(&p->q1,&p->z)){
	      if(indirect(&p->q1,LDX)){
		load_byte3(f,&p->q1,t);
		emit(f,"\ttax\n");
	      }else
		do_byte3(f,"ldx",&p->q1,t);
	    }
	    if(c==AND&&(l&0xffff)==0)  emit(f,"\tlda\t#0\n");
	    else if(cnst&&c==OR&&(l&0xffff)==0xffff) emit(f,"\tlda\t#65535\n");
	    else{
	      load_lobyte(f,&p->q1,t);
	      if(!(cnst&&((c==AND&&(l&0xffff)==0xffff)||(c==OR&&(l&0xffff)==0)||(c==XOR&&(l&0xffff)==0)))) do_lobyte(f,s,&p->q2,t);
	    }
	    if((c==ADD||c==ADDI2P)&&(l&0xffff0000)==0&&(isacc(z)||(compare_objects(&p->q1,&p->z)&&!indirect(&p->z,STX|INC)))){
	      store_lobyte(f,&p->z,t);
	      emit(f,"\tbcc\t%s%d\n",labprefix,++label);
	      if(isacc(z)){
		emit(f,"\tinx\n");
	      }else{
		do_byte3(f,"inc",&p->z,t);
	      }
	      emit(f,"%s%d:\n",labprefix,label);
	      continue;
	    }
	  }else{
	    load_lobyte(f,&p->q1,t);
	    do_lobyte(f,s,&p->q2,t);
	  }
	  if(isacc(z)) {emit(f,"\tpha\n");push(2);}
	  store_lobyte(f,&p->z,t);
	  if(zm2l(sizetab[pt&NQ])==3&&(!isreg(z)||is_volatile_obj(&p->q1))) BMODE();
	  if(cnst){
	    if(cnst&&c==AND&&(l&0xffff0000)==0) emit(f,"\tlda\t#0\n");
	    else if(cnst&&c==OR&&(l&0xffff0000)==0xffff0000) emit(f,"\tlda\t#65535\n");
	    else{
	      load_byte3(f,&p->q1,t);
	      if(!(cnst&&((c==AND&&(l&0xffff0000)==0xffff0000)||(c==OR&&(l&0xffff0000)==0)||(c==XOR&&(l&0xffff0000)==0)))) do_byte3(f,s,&p->q2,t);
	    }
	  }else{
	    if(isacc(q1))
	      emit(f,"\ttxa\n");
	    else
	      load_byte3(f,&p->q1,t);
	    if((ISHPOINTER(pt)||ISHLPOINTER(pt))&&(t2&NQ)<=INT)
	      emit(f,"\t%s\t#0\n",s);
	    else
	      do_byte3(f,s,&p->q2,t);
	  }
	  if(isacc(z)){
	    emit(f,"\ttax\n");
	    emit(f,"\tpla\n");
	    pop(2);
	  }else
	    store_byte3(f,&p->z,t);
	  continue;
	}else if(ISCHAR(t)||ISSHORT(t)){
	  if((ISFPOINTER(pt)||ISFLPOINTER(pt))&&!compare_objects(&p->q1,&p->z)){
	    if(ISFPOINTER(pt)&&(!isreg(z)||is_volatile_obj(&p->q1))) BMODE();
	    if(isacc(z)&&!indirect(&p->q1,LDX)){
	      do_byte3(f,"ldx",&p->q1,t);
	    }else if(isacc(q1)&&!indirect(&p->z,STX)){
	      do_byte3(f,"stx",&p->z,t);
	    }else{
	      if(isacc(q1)) {emit(f,"\tpha\n");push(bmode?1:2);}
	      load_byte3(f,&p->q1,FPOINTER);
	      store_byte3(f,&p->z,FPOINTER);
	      if(isacc(q1)) {emit(f,"\tpla\n");pop(bmode?1:2);}
	    }
	    WMODE();
	  }
	  if(ISCHAR(t)&&(!isacc(z)||is_volatile_ic(p))) BMODE();
	  load_acc(f,&p->q1,t);
	  if((c==ADD||c==SUB)&&(p->q2.flags&(KONST|DREFOBJ))==KONST){
	    eval_const(&p->q2.val,t);
	    if(zmeqto(vmax,Z1)||zmeqto(vmax,l2zm(2L))){
	      if(zmeqto(vmax,l2zm(2L)))
		emit(f,"\t%s\n",c==ADD?"ina":"dea");
	      emit(f,"\t%s\n",c==ADD?"ina":"dea");
	      store_lobyte(f,&p->z,t);
	      continue;
	    }
	  }
	  if(c==ADD) emit(f,"\tclc\n");
	  if(c==SUB) emit(f,"\tsec\n");
	  if(isreg(q2)&&ISIDX(p->q2.reg)){
	    int r=get_reg(f,p,CHAR);
	    emit(f,"\tst%s\t%s\n",mregnames[p->q2.reg],mregnames[r]);
	    p->q2.flags=REG;
	    p->q2.reg=r;
	  }
	  do_lobyte(f,s,&p->q2,t);
	  store_lobyte(f,&p->z,t);
	  if(bmode) WMODE();
	}else{
	  ierror(0);
	}

	continue;
      }
      pric2(stdout,p);
      ierror(0);
    }

    function_bottom(f,v,localsize);
    
    for(c=1;c<=MAXR;c++){
      if(regsa[c]||regused[c]){
	BSET(regs_modified,c);
      }
    }

    if(stack_valid){
      if(!v->fi) v->fi=new_fi();
      v->fi->flags|=ALL_STACK;
      v->fi->stack1=stack;
    }
  }

  free_IC(mi);

  emit(f,"; stacksize=%lu%s\n",zum2ul(stack),stack_valid?"":"+??");
}

int shortcut(int code,int typ)
{
  if(code==COMPARE||(code==MULT&&!ISCHAR(typ))||code==ADD||code==SUB||code==AND||code==OR||code==XOR||code==LSHIFT||code==RSHIFT||code==MINUS||code==KOMPLEMENT||code==NEGATION)
    return 1;

  return 0;
}

int reg_parm(struct reg_handle *m, struct Typ *t,int vararg,struct Typ *d)
{
  int f;

  if(vararg)
    return 0;
  /*if(c816) return 0;*/
  f=t->flags&NQ;
  if(OLDFP&&ISFLOAT(f)) return 0;
  if(d&&fattr(d,"__pascal__"))
    return 0;
  if(d&&fattr(d,"__cc65__")){
    m->regs++;
    printf("arg=%d cnt=%d\n",m->regs,d->exact->count);
    if(m->regs==d->exact->count-1){
      if(ISCHAR(t->flags))
	return ra;
      if(ISSHORT(t->flags))
	return rax;
    }
    return 0;
  }
  if(accparm&&m->regs==0){
    if(ISCHAR(f)||ISSHORT(f)||ISLONG(f)||ISPOINTER(f)||(ms4&&ISFLOAT(f))){
      m->regs=accparm;
      return zm2l(sizetab[f])<=2?ra:rax;
    }
  }
  if(ISCHAR(f)||ISSHORT(f)||ISNPOINTER(f)){
    if(m->regs-accparm>=GPR_ARGS)
      return 0;
    else
      return FIRST_GPR-accparm+m->regs++;
  }
#if 0
  if(f==FPOINTER||f==LONG||f==FLOAT||(!ieee&&(f==DOUBLE||f==LDOUBLE))){
    if(m->regs-accparm>=GPR_ARGS-1)
      return 0;
    else{
      if(m->regs&1) m->regs+=1;
      m->regs+=2;
      return FIRST_PAIR+(m->regs-accparm)/2-1;
    }
  }
#endif
#if 0
  if(f==FPOINTER||f==LONG||f==FLOAT||(!ieee&&(f==DOUBLE||f==LDOUBLE))){
    if(m->bregs>=4)
      return 0;
    else
      return FIRST_BIG+m->bregs++;
  }
#endif
  if(f==LLONG||(ieee&&(f==DOUBLE||f==LDOUBLE))){
    if(m->bregs>=3)
      return 0;
    else{
      if(m->bregs&1)  m->bregs++;
      m->bregs+=2;
      return FIRST_BIGP+m->bregs/2-1;
    }
  }
  return 0;
}

int handle_pragma(const char *s)
{
  static char sec[SECLEN];
  int i;
  if(sscanf(s,"section %127s",sec)==1){
    if(!strcmp(sec,"default"))
      use_sec=0;
    else
      use_sec=sec;
    return 1;
  }
}
void cleanup_cg(FILE *f)
{
  int i;
  struct fpconstlist *p=firstfpc;

  if(f&&p){
    emit(f,rodataname);
    section=RODATA;
  }
  while(p=firstfpc){
    emit(f,"%s%d:\n\tword\t",labprefix,p->label);
    if(ieee)
      emit_ieee(f,&p->val,p->t);
    else{
      int words=zm2l(sizetab[p->t&NQ])/2;
      eval_const(&p->val,p->t);
      if(ISFLOAT(p->t)) cnv_fp();
      for(i=0;i<words;i++){
	emit(f,"%ld",zm2l(vmax)&0xffff);
	if(i<words-1){emit(f,",");vmax=zmrshift(vmax,l2zm(16L));}
      }
      emit(f,"\n");
      /*emit(f,"%ld,%ld\n",zm2l(vmax)&0xffff,zm2l(zmrshift(vmax,l2zm(16L)))&0xffff);*/
    }
    firstfpc=p->next;
    free(p);
  }

  for(i=FIRST_GPR;i<=LAST_GPR;i++)
    emit(f,"\tzpage\t%s\n",mregnames[i]);
  for(i=FIRST_BIG;i<=LAST_BIG;i++)
    emit(f,"\tzpage\t%s\n",mregnames[i]);

}
void cleanup_db(FILE *f)
{
  if(f) section=-1;
}

static char *zops[]={
  "adc","and","asl","bit","eor","lda","ora",
  "tax","txa","tay","tya","sbc"};

static int setszflag(char *op)
{
  int i;
  for(i=0;i<sizeof(zops)/sizeof(zops[0]);i++)
    if(!strcmp(op,zops[i]))
      return 1;
  return 0;
}

static char *zxops[]={
  "tax","txa","ldx","inx","dex"};

static int setszxflag(char *op)
{
  int i;
  for(i=0;i<sizeof(zxops)/sizeof(zxops[0]);i++)
    if(!strcmp(op,zxops[i]))
      return 1;
  return 0;
}

enum peepf { NEEDSAME = 1, REMOVE1ST = 2, REMOVEBOTH = 4, ALLOWVOLATILE = 8, NEEDSIZE = 16};
struct peeps {char *s1,*s2,*r;enum peepf flags;};



int emit_peephole(void)
{
  int entries,i,j;
  char *asmline[EMIT_BUF_DEPTH];
  char buf1[1024],buf2[1024];
  char op1[8],op2[8];
  static char ca[1024],cx[1024],cy[1024];
  static int rm,disabled,a8,x8;

  static const struct peeps elim[]={
    "lda","sta",0,NEEDSAME,
    "ldx","stx",0,NEEDSAME,
    "ldy","sty",0,NEEDSAME,
    "sta","sta",0,NEEDSAME,
    "stx","stx",0,NEEDSAME,
    "sty","sty",0,NEEDSAME,
    "stz","stz",0,NEEDSAME,
    "sta","lda",0,NEEDSAME,
    "stx","ldx",0,NEEDSAME,
    "sty","ldy",0,NEEDSAME,
    "txa","tax",0,ALLOWVOLATILE|NEEDSIZE,
    "tax","txa",0,ALLOWVOLATILE|NEEDSIZE,
    "tay","tya",0,ALLOWVOLATILE|NEEDSIZE,
    "tya","tay",0,ALLOWVOLATILE|NEEDSIZE,
    "tsc","tcs",0,ALLOWVOLATILE,
    "tcs","tsc",0,ALLOWVOLATILE,
    "lda","lda",0,REMOVE1ST,
    "ldx","ldx",0,REMOVE1ST,
    "ldy","ldy",0,REMOVE1ST,
    "lda","pla",0,REMOVE1ST,
    "tya","pla",0,REMOVE1ST|NEEDSIZE,
    "txa","pla",0,REMOVE1ST|NEEDSIZE,
    "tsc","pla",0,REMOVE1ST,
    "ldx","plx",0,REMOVE1ST,
    "ldy","ply",0,REMOVE1ST,
    "lda","txa",0,REMOVE1ST|NEEDSIZE,
    "lda","tya",0,REMOVE1ST|NEEDSIZE,
    "lda","tsc",0,REMOVE1ST,
    "ldx","tax",0,REMOVE1ST|NEEDSIZE,
    "ldx","tyx",0,REMOVE1ST,
    "ldy","tay",0,REMOVE1ST|NEEDSIZE,
    "ldy","txy",0,REMOVE1ST,
    "ldx","tsx",0,REMOVE1ST,
    "tay","ldy",0,REMOVE1ST|ALLOWVOLATILE|NEEDSIZE,
    "txy","ldy",0,REMOVE1ST|ALLOWVOLATILE,
    "tax","ldx",0,REMOVE1ST|ALLOWVOLATILE|NEEDSIZE,
    "tyx","ldx",0,REMOVE1ST|ALLOWVOLATILE,
    "tsx","ldx",0,REMOVE1ST|ALLOWVOLATILE,
    "txa","lda",0,REMOVE1ST|ALLOWVOLATILE|NEEDSIZE,
    "tya","lda",0,REMOVE1ST|ALLOWVOLATILE|NEEDSIZE,
    "rep","sep",0,NEEDSAME|REMOVEBOTH|ALLOWVOLATILE,
    "a16","a8",0,REMOVEBOTH|ALLOWVOLATILE,
    "x16","x8",0,REMOVEBOTH|ALLOWVOLATILE,
    /*    "a8","a16",0,REMOVEBOTH|ALLOWVOLATILE,*/
    "pha","pla",0,REMOVEBOTH|ALLOWVOLATILE,
    "pla","pha","\tlda\t1,s\n",0,
    "lda","ldx","\ttax\n",NEEDSAME|NEEDSIZE,
    "lda","ldy","\ttay\n",NEEDSAME|NEEDSIZE,
    "ldx","lda","\ttxa\n",NEEDSAME|NEEDSIZE,
    "ldy","lda","\ttya\n",NEEDSAME|NEEDSIZE,
    "sta","ldx","\ttax\n",NEEDSAME|NEEDSIZE,
    "sta","ldy","\ttay\n",NEEDSAME|NEEDSIZE,
    "stx","lda","\ttxa\n",NEEDSAME|NEEDSIZE,
    "sty","lda","\ttya\n",NEEDSAME|NEEDSIZE,
  };

  static const char ignmflag[]="inx dex iny dey txy tyx stx ldx sty ldy phx plx phy ply clc sec cpx cpy pea pei per phb plb phd pld phk plk php plp tax tay tcd tcs tdc tsc tsx txs xba xce";

  if(nopeep) return 0;

  i=emit_l;
  if(emit_f==0)
    entries=i-emit_f+1;
  else
    entries=EMIT_BUF_DEPTH;
  asmline[0]=emit_buffer[i];

  if(!strcmp(asmline[0],";startinline\n")) disabled=1;
  if(!strcmp(asmline[0],";endinline\n")) disabled=0;
  if(disabled) return 0;

  buf1[0]=0;op1[0]=0;
  if((j=sscanf(asmline[0]," %6s %999s",op1,buf1))>=1){
    /*printf("a=%s x=%s y=%s z=%s\n",ca,cx,cy,cz);
      printf("\t\t%s %s\n",op1,buf1);*/
    if(!strcmp(op1,"a8")) a8=1;
    else if(!strcmp(op1,"a16")) a8=0;
    else if(!strcmp(op1,"x8")) x8=1;
    else if(!strcmp(op1,"x16")) x8=0;

    if(!strcmp(op1,"lda")){
      if(buf1[0]=='#'){
	if(!rm&&!strcmp(buf1,ca)){remove_asm();return rm=1;}
	if(x8<=a8){
	  if(!rm&&!strcmp(buf1,cx)){strcpy(asmline[0],"\ttxa\n");return rm=1;}
	  if(!rm&&!strcmp(buf1,cy)){strcpy(asmline[0],"\ttya\n");return rm=1;}
	}
	strcpy(ca,buf1);
      }else ca[0]=0;
    }else if(!strcmp(op1,"ldx")){
      if(buf1[0]=='#'){
	if(!rm&&!strcmp(buf1,cx)){remove_asm();return rm=1;}
	if(!rm&&a8<=x8&&!strcmp(buf1,ca)){strcpy(asmline[0],"\ttax\n");return rm=1;}
	strcpy(cx,buf1);
      }else cx[0]=0;
    }else if(!strcmp(op1,"ldy")){
      if(buf1[0]=='#'){
	if(!rm&&!strcmp(buf1,cy)){remove_asm();return rm=1;}
	if(!rm&&a8<=x8&&!strcmp(buf1,ca)){strcpy(asmline[0],"\ttay\n");return rm=1;}
	strcpy(cy,buf1);
      }else cy[0]=0;
    }else{
      static const char clobbernone[]="asw bit clc cld cli clv cmp cpx cpy dec inc nop pea pei pha php phx phy plp sec sed sei sta stz stx sty";
      static const char clobbera[]="adc and asl asr dea eor ina lsr ora pla rol ror sbc txa tya tza tsc a8 a16";
      static const char clobberx[]="dex inx tax tsx tyx x8 x16";
      static const char clobbery[]="dey iny tay txy x8 x16";
      if(asmline[0][0]==';'||strstr(clobbernone,op1)){
      }else if(strstr(clobbera,op1))
	ca[0]=0;
      else if(strstr(clobberx,op1))
	cx[0]=0;
      else if(strstr(clobbery,op1))
	cy[0]=0;
      else
	ca[0]=cx[0]=cy[0]=0;
    }
  }else if(asmline[0][0]!=';'){
    ca[0]=cx[0]=cy[0]=0;
  }

  rm=0;

  if(sscanf(asmline[0]," %6s %999s",op1,buf1)==2&&!strcmp(op1,"and")&&!strcmp(buf1,"#0")){
    strcpy(asmline[0],"\tlda\t#0\n");
    return rm=1;
  }

  if(entries>=2){
    i--;
    if(i<0) i=EMIT_BUF_DEPTH-1;
    asmline[1]=emit_buffer[i];


    if(!strcmp(asmline[0],"; volatile barrier\n")&&!strcmp(asmline[0],asmline[1])){
      remove_asm();
      return rm=1;
    }

    if(sscanf(asmline[1]," %6s %999s",op1,buf1)==2&&!strcmp(op1,"rep")&&!strcmp(buf1,"#32")){
      
      if(sscanf(asmline[0]," %6s",op2)==1&&strstr(ignmflag,op2)){
	strcpy(asmline[1],asmline[0]);
	strcpy(asmline[0],"\trep\t#32\n");
	return rm=1;
      }
    }

    if(sscanf(asmline[1]," %6s",op1)==1&&!strcmp(op1,"a16")){
      
      if(sscanf(asmline[0]," %6s",op2)==1&&strstr(ignmflag,op2)){
	strcpy(asmline[1],asmline[0]);
	strcpy(asmline[0],"\ta16\n");
	return rm=1;
      }
    }

#if 0 /* not needed with new ABI */
    /* TODO: some cases are missed due to unlucky order of arguments */
    if(ms4&&sscanf(asmline[0]," %6s %999s",op1,buf1)==2&&((!strcmp(op1,"sta")&&!strcmp(buf1,"r0"))||(!strcmp(op1,"stx")&&!strcmp(buf1,"r0+2")))){
      if(sscanf(asmline[1]," %6s %999s",op1,buf1)==2&&!strcmp(op1,"jsl")){
	static char *msfuncs[]={
	  ">___addflt32",">___subflt32","___mulflt32","___divflt32",
	  ">___sint32toflt32",">___uint32toflt32",
	  ">___sint16toflt32",">___uint16toflt32",
	  ">_log",">___log_r",">_exp",">___exp_r",">_pow",">___pow_r",
	  ">_sin",">___sin_r",">_cos",">___cos_r",">_tan",">___tan_r",
	  ">_atan","___atan_r","_asin","_acos"
	  ">_sinh",">_cosh",">_tanh",
	  ">_asinh",">_acosh",">_atanh",
	};
	for(i=0;i<sizeof(msfuncs)/sizeof(msfuncs[0]);i++){
	  if(!strcmp(buf1,msfuncs[i])){
	    remove_asm();
	    return rm=1;
	  }
	}
      }
    }
#endif

    if(sscanf(asmline[0]," %6s",op1)==1&&!strcmp(op1,"rts")&&
       sscanf(asmline[1]," %6s %999s",op2,buf2)==2&&!strcmp(op2,"jsr")){
      sprintf(asmline[1],"\tjmp\t%s\n",buf2);
      remove_asm();
      return rm=1;
    }
    if(sscanf(asmline[0]," %6s",op1)==1&&!strcmp(op1,"rtl")&&
       sscanf(asmline[1]," %6s %999s",op2,buf2)==2&&!strcmp(op2,"jsl")){
      sprintf(asmline[1],"\tjml\t%s\n",buf2);
      remove_asm();
      return rm=1;
    }


    for(j=0;j<sizeof(elim)/sizeof(elim[0]);j++){
      if((elim[j].flags&NEEDSIZE)&&a8!=x8) continue;
      if(elim[j].flags&NEEDSAME){
	if(sscanf(asmline[0]," %6s %999s",op2,buf2)==2&&
	   sscanf(asmline[1]," %6s %999s",op1,buf1)==2&&
	   !strcmp(op1,elim[j].s1)&&!strcmp(op2,elim[j].s2)&&
	   !strcmp(buf1,buf2)){
	  if(elim[j].r){
	    strcpy(asmline[0],elim[j].r);
	  }else{
	    if(elim[j].flags&REMOVE1ST)
	      strcpy(asmline[1],asmline[0]);
	    if(elim[j].flags&REMOVEBOTH)
	      remove_asm();
	    remove_asm();
	  }
	  return rm=1;
	}
      }else{
	if(sscanf(asmline[1]," %6s",op1)==1&&
	   sscanf(asmline[0]," %6s",op2)==1&&
	   !strcmp(op1,elim[j].s1)&&!strcmp(op2,elim[j].s2)){
	  if(elim[j].flags&REMOVE1ST)
	    strcpy(asmline[1],asmline[0]);
	  if(elim[j].r)
	    strcpy(asmline[1],elim[j].r);
	  remove_asm();
	  if(elim[j].flags&REMOVEBOTH)
	    remove_asm();
	  return rm=1;
	}
      }
    }


  }

  if(entries>=3){
    i--;
    if(i<0) i=EMIT_BUF_DEPTH-1;
    asmline[2]=emit_buffer[i];
    if(sscanf(asmline[0]," %6s %999s",op1,buf1)==2){
#if 0
      if(!strcmp(op1,"lda")&&buf1[0]=='#'){
	if(sscanf(asmline[1]," %6s %999s",op2,buf2)==2&&
	   !strcmp(op2,"sta")){
	  if(sscanf(asmline[2]," %6s %999s",op2,buf2)==2&&
	     !strcmp(op2,"lda")&&!strcmp(buf1,buf2)){
	    remove_asm();
	    return rm=1;
	  }
	}
      }
#endif
      if(!strcmp(op1,"beq")||!strcmp(op1,"bne")){
	if(sscanf(asmline[1]," %6s %999s",op2,buf2)==2&&
	   !strcmp(op2,"cmp")&&!strcmp(buf2,"#0")){
	  if(sscanf(asmline[2]," %6s",op2)==1&&
	     setszflag(op2)){
	    strcpy(asmline[1],asmline[0]);
	    remove_asm();
	    return rm=1;
	  }
	}
      }
      if(!strcmp(op1,"beq")||!strcmp(op1,"bne")){
	if(sscanf(asmline[1]," %6s %999s",op2,buf2)==2&&
	   !strcmp(op2,"cpx")&&!strcmp(buf2,"#0")){
	  if(sscanf(asmline[2]," %6s",op2)==1&&
	     setszxflag(op2)){
	    strcpy(asmline[1],asmline[0]);
	    remove_asm();
	    return rm=1;
	  }
	}
      }
    }
    if(!strcmp(asmline[1],"; volatile barrier\n")){
      for(j=0;j<sizeof(elim)/sizeof(elim[0]);j++){
	if(!(elim[j].flags&ALLOWVOLATILE)) continue;
	if((elim[j].flags&NEEDSIZE)&&a8!=x8) continue;
	if(elim[j].flags&NEEDSAME){
	  if(sscanf(asmline[0]," %6s %999s",op2,buf2)==2&&
	     sscanf(asmline[2]," %6s %999s",op1,buf1)==2&&
	     !strcmp(op1,elim[j].s1)&&!strcmp(op2,elim[j].s2)&&
	     !strcmp(buf1,buf2)){
	    if(elim[j].r){
	      strcpy(asmline[0],elim[j].r);
	    }else{
	      if(elim[j].flags&REMOVE1ST)
		strcpy(asmline[2],asmline[0]);
	      if(elim[j].flags&REMOVEBOTH){
		strcpy(asmline[2],asmline[1]);
		remove_asm();
	      }
	      remove_asm();
	    }
	    return rm=1;
	  }
	}else{
	  if(sscanf(asmline[2]," %6s",op1)==1&&
	     sscanf(asmline[0]," %6s",op2)==1&&
	     !strcmp(op1,elim[j].s1)&&!strcmp(op2,elim[j].s2)){
	    if(elim[j].flags&REMOVE1ST)
	      strcpy(asmline[2],asmline[0]);
	    remove_asm();
	    if(elim[j].flags&REMOVEBOTH){
	      strcpy(asmline[2],asmline[1]);
	      remove_asm();
	    }
	    return rm=1;
	  }
	}
      }
      
    }
  }
  if(entries>=4){
    i--;
    if(i<0) i=EMIT_BUF_DEPTH-1;
    asmline[3]=emit_buffer[i];
  }
  if(entries>=5){
    i--;
    if(i<0) i=EMIT_BUF_DEPTH-1;
    asmline[4]=emit_buffer[i];
    if(sscanf(asmline[0]," %s %s",op1,buf1)>=1){
      if(!strcmp(op1,"lda")||!strcmp(op1,"pla")||!strcmp(op1,"txa")||!strcmp(op1,"tya")){
	if(sscanf(asmline[1]," %s %s",op1,buf1)>=1&&!strcmp(op1,"pla")&&
	   sscanf(asmline[2]," %s %s",op1,buf1)>=1&&!strcmp(op1,"tay")&&
	   sscanf(asmline[3]," %s %s",op1,buf1)>=1&&!strcmp(op1,"txa")&&
	   sscanf(asmline[4]," %s %s",op1,buf1)>=1&&!strcmp(op1,"pha")){
	  strcpy(asmline[4],asmline[3]);
	  strcpy(asmline[3],asmline[2]);
	  strcpy(asmline[2],asmline[0]);
	  remove_asm();
	  remove_asm();
	  return rm=1;
	}
      }
    }
    if(!strcmp(op1,"beq")||!strcmp(op1,"bne")){
      if(sscanf(asmline[1]," %6s %999s",op1,buf1)==2&&
	 !strcmp(op1,"rep")){
	if(sscanf(asmline[2]," %6s",op1)==1&&
	 !strcmp(op1,"a16")){
	  if(sscanf(asmline[3]," %6s %999s",op2,buf2)==2&&
	     !strcmp(op2,"cmp")&&!strcmp(buf2,"#0")){
	    if(sscanf(asmline[4]," %6s",op2)==1&&
	       setszflag(op2)){
	      strcpy(asmline[3],asmline[2]);
	      strcpy(asmline[2],asmline[1]);
	      strcpy(asmline[1],asmline[0]);
	      remove_asm();
	      return rm=1;
	    }
	  }
	}
      }
    }
  }
  return 0;
}

/* Return name of library function, if this node should be
   implemented via libcall. */
char *use_libcall(int c,int t,int t2)
{
  static char fname[16];
  char *ret=0;

  if(c==COMPARE){
    if((t&NQ)==LLONG||(ISFLOAT(t)&&!ieee)){
      sprintf(fname,"__cmp%s%s%ld",(t&UNSIGNED)?"u":"s",ISFLOAT(t)?"flt":"int",zm2l(sizetab[t&NQ])*8);
      ret=fname;
    }
  }else{
    t&=NU;
    t2&=NU;
    if(ISSHORT(t)&&c!=MULT&&c!=DIV&&c!=MOD&&!ISFLOAT(t2))
      return 0;
    if(ISLONG(t)&&c!=MULT&&c!=DIV&&c!=MOD&&!ISFLOAT(t2))
      return 0;

    if(!ieee&&ISFLOAT(t)) t=FLOAT;
    if(t==LDOUBLE) t=DOUBLE;
    if(t2==LDOUBLE) t2=DOUBLE;
    if(!ieee&&ISFLOAT(t2)) t2=FLOAT;
    if(c==CONVERT){
      if(t==t2) return 0;
      if(t==FLOAT&&t2==DOUBLE) return "__flt64toflt32";
      if(t==DOUBLE&&t2==FLOAT) return "__flt32toflt64";

      if(ISFLOAT(t)){
        sprintf(fname,"__%cint%ldtoflt%d",(t2&UNSIGNED)?'u':'s',zm2l(sizetab[t2&NQ])*8,(t==FLOAT)?32:64);
        ret=fname;
      }
      if(ISFLOAT(t2)){
        sprintf(fname,"__flt%dto%cint%ld",((t2&NU)==FLOAT)?32:64,(t&UNSIGNED)?'u':'s',zm2l(sizetab[t&NQ])*8);
        ret=fname;
      }
    }
    /*if(c==MULT&&(t&NQ)==CHAR&&!m65) return "__mulint8";*/
    if((t&NQ)==SHORT||(t&NQ)==INT||(t&NQ)==LONG||(t&NQ)==LLONG||(!ieee&&ISFLOAT(t))){
      if((c>=LSHIFT&&c<=MOD)||(c>=OR&&c<=AND)||c==KOMPLEMENT||(c==MINUS&&!ms4)){
	if(m65&&ISLONG(t)&&(c==MULT||(c==DIV&&!divbug&&(t&UNSIGNED)))) return 0;
	if(m65&&c==MULT&&ISSHORT(t)) return 0;
        if(t==(UNSIGNED|LLONG)&&(c==MULT||c==DIV||c==MOD||c==RSHIFT)){
          sprintf(fname,"__%suint64",ename[c]);
          ret=fname;
        }else if((t&NQ)==LLONG){
          sprintf(fname,"__%sint64",ename[c]);
          ret=fname;
        }else if(t==(UNSIGNED|LONG)&&(c==DIV||c==MOD||c==RSHIFT)){
          sprintf(fname,"__%suint32",ename[c]);
          ret=fname;
        }else if((t&NQ)==LONG){
          sprintf(fname,"__%sint32%s",ename[c],(snesmuldiv&&c==MULT)?"snes":"");
          ret=fname;
        }else if(t==(UNSIGNED|INT)&&(c==DIV||c==MOD||c==RSHIFT)){
          sprintf(fname,"__%suint16%s",ename[c],(snesmuldiv&&(c==DIV||c==MOD))?"snes":"");
          ret=fname;
        }else if((t&NQ)==INT||(t&NQ)==SHORT){
          sprintf(fname,"__%sint16%s",ename[c],(snesmuldiv&&(c==MULT||c==DIV||c==MOD))?"snes":"");
          ret=fname;
        }else{
          sprintf(fname,"__%s%s%s%ld%s",ename[c],(t&UNSIGNED)?"u":"",ISFLOAT(t)?"flt":"int",zm2l(sizetab[t&NQ])*8,(snesmuldiv&&c==MULT&&(t&NQ)==CHAR)?"snes":"");
          ret=fname;
        }
      }
    }
  }

  if(ret&&divbug&&(c==DIV||c==MOD)&&!ISFLOAT(t)) strcat(ret,"wo");

  return ret;
}

static int pattr(char *p)
{
  if(strstr(p,STR_HUGE4)) return HLPOINTER;
  if(strstr(p,STR_FAR4)) return FLPOINTER;
  if(strstr(p,STR_HUGE3)) return HPOINTER;
  if(strstr(p,STR_FAR3)) return FPOINTER;
  if(strstr(p,STR_NEAR)) return POINTER;
  if(strstr(p,STR_HUGE)) return ptr24?HPOINTER:HLPOINTER;
  if(strstr(p,STR_FAR)) return ptr24?FPOINTER:FLPOINTER;
  return 0;
}

int pointer_varadr(Var *v,int internal)
{
  struct Typ *p=v->vtyp;
  if(!p) ierror(0);
  while(ISARRAY(p->flags)||ISFUNC(p->flags)) p=p->next;
  if(p->attr){
    int t=pattr(p->attr);
    if(t) return t;
  }
  if(internal&&near_threshold){
    if(!isauto(v->storage_class)){
      long sz=zm2l(szof(v->vtyp));
      if(sz&&sz<=near_threshold){
	if(!NONEARCONST||!is_const(v->vtyp))
	  return POINTER;
      }
    }
  }
  return pointer_type(v->vtyp);
}

int pointer_type(struct Typ *p)
{
  struct Typ *merk=p;
  if(!p) ierror(0);
  if(ISFUNC(p->flags)){
    if(ptr24) return FPOINTER; else return FLPOINTER;
  }
  while(ISARRAY(p->flags)||ISFUNC(p->flags)) p=p->next;
  if(p->attr){
    int t=pattr(p->attr);
    if(t) return t;
  }
  if(large)
    return ptr24?FPOINTER:FLPOINTER;
  if(huge)
    return ptr24?HPOINTER:HLPOINTER;
  return POINTER;
}

unsigned char cbmconv(unsigned char x)
{
  static unsigned char ctab[256]={
    0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x14,0x09,0x0D,0x11,0x93,0x0A,0x0E,0x0F,
    0x10,0x0B,0x12,0x13,0x08,0x15,0x16,0x17,0x18,0x19,0x1A,0x1B,0x1C,0x1D,0x1E,0x1F,
    0x20,0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,0x2A,0x2B,0x2C,0x2D,0x2E,0x2F,
    0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B,0x3C,0x3D,0x3E,0x3F,
    0x40,0xC1,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7,0xC8,0xC9,0xCA,0xCB,0xCC,0xCD,0xCE,0xCF,
    0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0xD6,0xD7,0xD8,0xD9,0xDA,0x5B,0xBF,0x5D,0x5E,0xA4,
    0xAD,0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F,
    0x50,0x51,0x52,0x53,0x54,0x55,0x56,0x57,0x58,0x59,0x5A,0xB3,0xDD,0xAB,0xB1,0xDF,
    0x80,0x81,0x82,0x83,0x84,0x85,0x86,0x87,0x88,0x89,0x8A,0x8B,0x8C,0x8D,0x8E,0x8F,
    0x90,0x91,0x92,0x0C,0x94,0x95,0x96,0x97,0x98,0x99,0x9A,0x9B,0x9C,0x9D,0x9E,0x9F,
    0xA0,0xA1,0xA2,0xA3,0x5F,0xA5,0xA6,0xA7,0xA8,0xA9,0xAA,0x7D,0xAC,0x60,0xAE,0xAF,
    0xB0,0x7E,0xB2,0x7B,0xB4,0xB5,0xB6,0xB7,0xB8,0xB9,0xBA,0xBB,0xBC,0xBD,0xBE,0x5C,
    0x60,0x61,0x62,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6A,0x6B,0x6C,0x6D,0x6E,0x6F,
    0x70,0x71,0x72,0x73,0x74,0x75,0x76,0x77,0x78,0x79,0x7A,0x7B,0xDC,0x7C,0xDE,0x7F,
    0xE0,0xE1,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xE8,0xE9,0xEA,0xEB,0xEC,0xED,0xEE,0xEF,
    0xF0,0xF1,0xF2,0xF3,0xF4,0xF5,0xF6,0xF7,0xF8,0xF9,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF
  };

  static unsigned char atab[]={0xfd,8,0x7f,0x9b,11,0x7d};

  if(cbmascii)
    return ctab[x&255];
  else if(atascii&&x>=7&&x<=12)
    return atab[x-7];
  else
    return x;
}

void insert_const(union atyps *p,int t)
/*  Traegt Konstante in entprechendes Feld ein.       */
{
  if(!p) ierror(0);
/*  *p = (union atyps) 0 ; /* rfi: clear unused bits */
  t&=NU;
  if(t==CHAR) {p->vchar=vchar;return;}
  if(t==SHORT) {p->vshort=vshort;return;}
  if(t==INT) {p->vint=vint;return;}
  if(t==LONG) {p->vlong=vlong;return;}
  if(t==LLONG) {p->vllong=vllong;return;}
  if(t==MAXINT) {p->vmax=vmax;return;}
  if(t==(UNSIGNED|CHAR)) {p->vuchar=vuchar;return;}
  if(t==(UNSIGNED|SHORT)) {p->vushort=vushort;return;}
  if(t==(UNSIGNED|INT)) {p->vuint=vuint;return;}
  if(t==(UNSIGNED|LONG)) {p->vulong=vulong;return;}
  if(t==(UNSIGNED|LLONG)) {p->vullong=vullong;return;}
  if(t==(UNSIGNED|MAXINT)) {p->vumax=vumax;return;}
  if(t==FLOAT&&ieee) {p->vfloat=vfloat;return;}
  if(t==DOUBLE||t==FLOAT) {p->vdouble=vdouble;return;}
  if(t==LDOUBLE) {p->vldouble=vldouble;return;}
  if(ISPOINTER(t)){
    if(t==POINTER){
      p->vuint=vuint;return;
    }
    p->vulong=vulong;return;
  }
}

void eval_const(union atyps *p,int t)
/*  Weist bestimmten globalen Variablen Wert einer CEXPR zu.       */
{
  int f=t&NQ;
  if(!p) ierror(0);
  if(f==MAXINT||(f>=CHAR&&f<=LLONG)){
    if(!(t&UNSIGNED)){
      if(f==CHAR) vmax=zc2zm(p->vchar);
      else if(f==SHORT)vmax=zs2zm(p->vshort);
      else if(f==INT)  vmax=zi2zm(p->vint);
      else if(f==LONG) vmax=zl2zm(p->vlong);
      else if(f==LLONG) vmax=zll2zm(p->vllong);
      else if(f==MAXINT) vmax=p->vmax;
      else ierror(0);
      vumax=zm2zum(vmax);
      vldouble=zm2zld(vmax);
    }else{
      if(f==CHAR) vumax=zuc2zum(p->vuchar);
      else if(f==SHORT)vumax=zus2zum(p->vushort);
      else if(f==INT)  vumax=zui2zum(p->vuint);
      else if(f==LONG) vumax=zul2zum(p->vulong);
      else if(f==LLONG) vumax=zull2zum(p->vullong);
      else if(f==MAXINT) vumax=p->vumax;
      else ierror(0);
      vmax=zum2zm(vumax);
      vldouble=zum2zld(vumax);
    }
  }else{
    if(ISPOINTER(f)){
      if(f==POINTER)
	vumax=zui2zum(p->vuint);
      else
	vumax=zul2zum(p->vulong);
      vmax=zum2zm(vumax);vldouble=zum2zld(vumax);
    }else{
      if(f==FLOAT&&ieee) vldouble=zf2zld(p->vfloat);
      else if(f==DOUBLE||f==FLOAT) vldouble=zd2zld(p->vdouble);
      else vldouble=p->vldouble;
      vmax=zld2zm(vldouble);
      vumax=zld2zum(vldouble);
    }
  }
  vfloat=zld2zf(vldouble);
  vdouble=zld2zd(vldouble);
  vuchar=zum2zuc(vumax);
  vushort=zum2zus(vumax);
  vuint=zum2zui(vumax);
  vulong=zum2zul(vumax);
  vullong=zum2zull(vumax);
  vchar=zm2zc(vmax);
  vshort=zm2zs(vmax);
  vint=zm2zi(vmax);
  vlong=zm2zl(vmax);
  vllong=zm2zll(vmax);
}

void printval(FILE *f,union atyps *p,int t)
/*  Gibt atyps aus.                                     */
{
  t&=NU;
  if(t==CHAR){fprintf(f,"C");vmax=zc2zm(p->vchar);printzm(f,vmax);}
  if(t==(UNSIGNED|CHAR)){fprintf(f,"UC");vumax=zuc2zum(p->vuchar);printzum(f,vumax);}
  if(t==SHORT){fprintf(f,"S");vmax=zs2zm(p->vshort);printzm(f,vmax);}
  if(t==(UNSIGNED|SHORT)){fprintf(f,"US");vumax=zus2zum(p->vushort);printzum(f,vumax);}
  if(t==FLOAT){fprintf(f,"F");vldouble=zf2zld(p->vfloat);printzld(f,vldouble);}
  if(t==DOUBLE){fprintf(f,"D");vldouble=zd2zld(p->vdouble);printzld(f,vldouble);}
  if(t==LDOUBLE){fprintf(f,"LD");printzld(f,p->vldouble);}
  if(t==INT){fprintf(f,"I");vmax=zi2zm(p->vint);printzm(f,vmax);}
  if(t==(UNSIGNED|INT)||t==POINTER){fprintf(f,"UI");vumax=zui2zum(p->vuint);printzum(f,vumax);}
  if(t==LONG){fprintf(f,"L");vmax=zl2zm(p->vlong);printzm(f,vmax);}
  if(t==(UNSIGNED|LONG)||t==FPOINTER||t==HPOINTER){fprintf(f,"UL");vumax=zul2zum(p->vulong);printzum(f,vumax);}
  if(t==LLONG){fprintf(f,"LL");vmax=zll2zm(p->vllong);printzm(f,vmax);}
  if(t==(UNSIGNED|LLONG)){fprintf(f,"ULL");vumax=zull2zum(p->vullong);printzum(f,vumax);}
  if(t==MAXINT) printzm(f,p->vmax);
  if(t==(UNSIGNED|MAXINT)) printzum(f,p->vumax);
}

void emitval(FILE *f,union atyps *p,int t)
/*  Gibt atyps aus.                                     */
{
  t&=NU;
  if(t==CHAR){vmax=zc2zm(p->vchar);emitzm(f,vmax);}
  if(t==(UNSIGNED|CHAR)){vumax=zuc2zum(p->vuchar);emitzum(f,vumax);}
  if(t==SHORT){vmax=zs2zm(p->vshort);emitzm(f,vmax);}
  if(t==(UNSIGNED|SHORT)){vumax=zus2zum(p->vushort);emitzum(f,vumax);}
  if(t==FLOAT){vldouble=zf2zld(p->vfloat);emitzld(f,vldouble);}
  if(t==DOUBLE){vldouble=zd2zld(p->vdouble);emitzld(f,vldouble);}
  if(t==LDOUBLE){emitzld(f,p->vldouble);}
  if(t==INT){vmax=zi2zm(p->vint);emitzm(f,vmax);}
  if(t==(UNSIGNED|INT)||t==POINTER){vumax=zui2zum(p->vuint);emitzum(f,vumax);}
  if(t==LONG){vmax=zl2zm(p->vlong);emitzm(f,vmax);}
  if(t==(UNSIGNED|LONG)||t==FPOINTER||t==HPOINTER){vumax=zul2zum(p->vulong);emitzum(f,vumax);}
  if(t==LLONG){vmax=zll2zm(p->vllong);emitzm(f,vmax);}
  if(t==(UNSIGNED|LLONG)){vumax=zull2zum(p->vullong);emitzum(f,vumax);}
  if(t==MAXINT) emitzm(f,p->vmax);
  if(t==(UNSIGNED|MAXINT)) emitzum(f,p->vumax);
}

void conv_typ(struct Typ *p)
/* Erzeugt extended types in einem Typ. */
{
  char *attr;
  while(p){
    if(ISPOINTER(p->flags)){
      p->flags=((p->flags&~NU)|POINTER_TYPE(p->next));
      if(attr=p->next->attr){
        if(strstr(attr,STR_NEAR))
          p->flags=((p->flags&~NU)|POINTER);
        if(strstr(attr,STR_FAR3))
          p->flags=((p->flags&~NU)|FPOINTER);
        if(strstr(attr,STR_HUGE3))
          p->flags=((p->flags&~NU)|HPOINTER);
        if(strstr(attr,STR_FAR4))
          p->flags=((p->flags&~NU)|FLPOINTER);
        if(strstr(attr,STR_HUGE4))
          p->flags=((p->flags&~NU)|HLPOINTER);
        if(strstr(attr,STR_FAR))
          p->flags=((p->flags&~NU)|(ptr24?FPOINTER:FLPOINTER));
        if(strstr(attr,STR_HUGE))
          p->flags=((p->flags&~NU)|(ptr24?HPOINTER:HLPOINTER));

      }
    }
    p=p->next;
  }
}

void add_var_hook_post(Var *v)
{
  if(use_sec&&(v->storage_class==STATIC||v->storage_class==EXTERN)){
    char buf[SECLEN+32];
    sprintf(buf,"section(\"%s\");",use_sec);
    add_attr(&v->vattr,buf);
  }
  /* TODO: far/near/huge pragma */
}

int decide_reverse(zmax v)
{
  if(zmeqto(v,Z1)||zmeqto(v,l2zm(2L)))
    return 1;
  if(optspeed)
    if(zmeqto(v,l2zm(4L))||zmeqto(v,l2zm(8L))||zmeqto(v,l2zm(256L))||zmeqto(v,l2zm(512L)))
      return 1;
  
  return 0;
}

static int is_single_eff_ic(struct IC *p)
{
  struct Var *v,*idx;
  if(p->code!=ADDI2P||(p->typf2&NQ)!=POINTER)
    return 0;
  if(!(p->q2.flags&KONST)){
    if((p->typf&NU)!=(UNSIGNED|CHAR))
      return 0;
    if((p->q2.flags&(VAR|DREFOBJ))!=VAR)
      return 0;
    if(!ISSTACK(p->q2.v->storage_class))
      return 0;
    idx=p->q2.v;
  }else{
    idx=0;
    eval_const(&p->q2.val,p->typf);
    /* TODO: more precise check considering data type useful? */
    if(!zmleq(vumax,l2zm(255L)))
      return 0;
    return 1;
  }
  if(p->q1.flags&DREFOBJ)
    return 0;
  if((p->z.flags&(VAR|DREFOBJ))!=VAR)
    return 0;
  if(p->z.v->storage_class==STATIC||p->z.v->storage_class==EXTERN)
    return 0;
  v=p->z.v;
  for(p=p->next;p;p=p->next){
    int c=p->code;
    if(c==LABEL||(c>=BEQ&&c<=BRA))
      return 1; /* TODO: how elaborate should we test? */
    if((p->q1.flags&VAR)&&p->q1.v==v){
      if(p->q1.flags&DREFOBJ)
        return 1;
      else
        return 0;
    }
    if((p->q2.flags&VAR)&&p->q2.v==v){
      if(p->q2.flags&DREFOBJ)
        return 1;
      else
        return 0;
    }
    if((p->z.flags&VAR)&&p->z.v==v){
      if(p->z.flags&DREFOBJ)
        return 1;
      else
        return 0;
    }
    if((p->z.flags&VAR)&&p->z.v==idx)
      return 0;
  }
  return 0;
}

void mark_eff_ics(void)
{
  struct IC *p;
  for(p=first_ic;p;p=p->next){
    if(is_single_eff_ic(p))
      p->flags|=EFF_IC;
    else
      p->flags&=~EFF_IC;
  }
}
